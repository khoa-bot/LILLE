# row E76K15  instance E-n76-k7  n 75  m 1  K 15  seed 17175
# metric ceil  return_weight 1
# objective 3281.000000  latency_only 2136.000000  valid 1
# cycles 227048  cycle_segments 22634|20743|21243|20162|22430|22330|19326|18935|19194|19279|20772
Route 1 depot 0 3 44 28 4 36 19 69 59 70
Route 2 depot 0 33 51 26 12 56 14
Route 3 depot 0 66 45 7 18 53
Route 4 depot 0 74 47 46 35 68
Route 5 depot 0 5 32 62 22 55
Route 6 depot 0 2 43 31 49 17
Route 7 depot 0 72 0 42 40 41 63
Route 8 depot 0 6 34 52 13 58
Route 9 depot 0 25
Route 10 depot 0 50 15 48 23
Route 11 depot 0 11 71 38 30
Route 12 depot 0 67 1 61 27 21
Route 13 depot 0 57 9 37 64 65 10
Route 14 depot 0 29 73 20 60
Route 15 depot 0 16 39 8 24 54
