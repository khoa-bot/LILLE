# row P19K2  instance P-n19-k2  n 18  m 1  K 2  seed 9256
# metric ceil  return_weight 1
# objective 1108.000000  latency_only 870.000000  valid 1
# cycles 1302875  cycle_segments 116651|115208|115648|114718|113491|117260|117484|116667|122970|127809|124969
Route 1 depot 0 5 17 1 6 4 12 14 8
Route 2 depot 0 0 9 3 10 13 11 2 7 15 16
