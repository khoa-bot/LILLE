# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 1337
# metric ceil  return_weight 1
# objective 1041.000000  latency_only 767.000000  valid 1
# cycles 1299262  cycle_segments 120252|119188|118636|117423|118780|118322|118818|118060|117234|116788|115761
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
