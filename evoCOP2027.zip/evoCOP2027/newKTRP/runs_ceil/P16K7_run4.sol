# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 25094
# metric ceil  return_weight 1
# objective 824.000000  latency_only 427.000000  valid 1
# cycles 1597404  cycle_segments 142948|158167|144220|142680|143661|143131|145477|144536|145681|142557|144346
Route 1 depot 0 6 12 8
Route 2 depot 0 1 7 2
Route 3 depot 0 9 11 14
Route 4 depot 0 5
Route 5 depot 0 3 10
Route 6 depot 0 0
Route 7 depot 0 4 13
