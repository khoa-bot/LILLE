# row E101K14  instance E-n101-k8  n 100  m 1  K 14  seed 25094
# metric ceil  return_weight 1
# objective 4427.000000  latency_only 3174.000000  valid 1
# cycles 201217  cycle_segments 31887|14794|28172|13559|17579|13666|13811|13917|14622|15079|24131
Route 1 depot 0 5 95 98 92 84 60 15 85 37
Route 2 depot 0 11 79 67 28 23
Route 3 depot 0 12 94 96 86 41 42 14
Route 4 depot 0 17 82 7 45 35 48 63
Route 5 depot 0 25 53 54 24 38 3
Route 6 depot 0 26 68 0 69 29 19 65 64
Route 7 depot 0 27 75 76 2 78 77 33 34 70
Route 8 depot 0 30 87 61 9 89 62 31
Route 9 depot 0 49 32 80 8 50
Route 10 depot 0 51 6 81 47 46 18 10
Route 11 depot 0 52 39 20 72 71 73 74 55 22 66
Route 12 depot 0 57 1 56 40 21
Route 13 depot 0 88 59 4 83 16 44
Route 14 depot 0 93 58 91 36 97 99 90 43 13
