# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 17175
# metric ceil  return_weight 1
# objective 824.000000  latency_only 429.000000  valid 1
# cycles 1576424  cycle_segments 140619|138700|139743|140724|142888|146451|145823|146330|144856|144072|146218
Route 1 depot 0 0
Route 2 depot 0 4 13
Route 3 depot 0 3 10
Route 4 depot 0 1 7 2
Route 5 depot 0 9 11 14
Route 6 depot 0 5
Route 7 depot 0 6 8 12
