# row P19K3  instance P-n19-k2  n 18  m 1  K 3  seed 17175
# metric ceil  return_weight 1
# objective 933.000000  latency_only 664.000000  valid 1
# cycles 1549664  cycle_segments 136908|141614|138928|141741|140069|142778|141724|140748|142144|140419|142591
Route 1 depot 0 5 1 6 7 15 16 2
Route 2 depot 0 0 9 11 13 10 3
Route 3 depot 0 17 4 12 14 8
