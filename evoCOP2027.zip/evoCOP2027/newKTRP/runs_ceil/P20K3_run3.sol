# row P20K3  instance P-n20-k2  n 19  m 1  K 3  seed 17175
# metric ceil  return_weight 1
# objective 1015.000000  latency_only 744.000000  valid 1
# cycles 1499082  cycle_segments 135330|135456|135567|133381|136266|138708|137556|137619|136012|134550|138637
Route 1 depot 0 5 1 7 16 17 2
Route 2 depot 0 0 9 11 14 10 3
Route 3 depot 0 18 4 13 15 8 12 6
