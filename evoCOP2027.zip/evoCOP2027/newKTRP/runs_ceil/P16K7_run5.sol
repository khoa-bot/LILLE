# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 33013
# metric ceil  return_weight 1
# objective 824.000000  latency_only 427.000000  valid 1
# cycles 1593302  cycle_segments 146825|143189|147353|142631|145869|144125|144805|145102|144942|145167|143294
Route 1 depot 0 3 10
Route 2 depot 0 0
Route 3 depot 0 9 11 14
Route 4 depot 0 1 7 2
Route 5 depot 0 5
Route 6 depot 0 6 12 8
Route 7 depot 0 4 13
