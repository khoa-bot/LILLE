# row P22K7  instance P-n22-k2  n 21  m 1  K 7  seed 9256
# metric ceil  return_weight 1
# objective 1060.000000  latency_only 625.000000  valid 1
# cycles 1129939  cycle_segments 102728|102534|103279|103137|103407|103919|112777|97630|105630|96946|97952
Route 1 depot 0 5 6 20 8 12
Route 2 depot 0 0
Route 3 depot 0 3 10 14
Route 4 depot 0 19 4 16 13
Route 5 depot 0 9 11 2
Route 6 depot 0 1 7 17 18
Route 7 depot 0 15
