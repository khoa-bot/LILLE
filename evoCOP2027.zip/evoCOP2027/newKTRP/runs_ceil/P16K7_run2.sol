# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 9256
# metric ceil  return_weight 1
# objective 824.000000  latency_only 427.000000  valid 1
# cycles 1563584  cycle_segments 138976|138096|154457|139479|140264|151118|139950|140449|140526|140423|139846
Route 1 depot 0 4 13
Route 2 depot 0 3 10
Route 3 depot 0 0
Route 4 depot 0 1 7 2
Route 5 depot 0 9 11 14
Route 6 depot 0 6 12 8
Route 7 depot 0 5
