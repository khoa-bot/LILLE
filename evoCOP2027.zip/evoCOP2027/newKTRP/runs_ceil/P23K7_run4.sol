# row P23K7  instance P-n23-k8  n 22  m 1  K 7  seed 25094
# metric ceil  return_weight 1
# objective 1045.000000  latency_only 631.000000  valid 1
# cycles 988899  cycle_segments 87955|90400|90820|88595|89904|90717|89886|90335|90209|90844|89234
Route 1 depot 0 20
Route 2 depot 0 19 4 16 13
Route 3 depot 0 1 7 17 18
Route 4 depot 0 3 10 14
Route 5 depot 0 15
Route 6 depot 0 0 9 11 2
Route 7 depot 0 5 6 21 8 12
