# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 33013
# metric ceil  return_weight 1
# objective 1211.000000  latency_only 969.000000  valid 1
# cycles 1252517  cycle_segments 120420|119714|120072|107893|120308|109405|111772|111665|110476|110968|109824
Route 1 depot 0 0 3 10 14 11 2 7 16 17
Route 2 depot 0 5 18 4 13 15 8 12 6 1 9
