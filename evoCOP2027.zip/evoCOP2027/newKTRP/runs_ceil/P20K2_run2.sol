# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 9256
# metric ceil  return_weight 1
# objective 1211.000000  latency_only 969.000000  valid 1
# cycles 1301243  cycle_segments 110825|113055|112054|113964|121346|121867|119874|121829|121699|122878|121852
Route 1 depot 0 0 3 10 14 11 2 7 16 17
Route 2 depot 0 5 18 4 13 15 8 12 6 1 9
