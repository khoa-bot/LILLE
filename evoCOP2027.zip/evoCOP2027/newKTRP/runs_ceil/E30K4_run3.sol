# row E30K4  instance E-n30-k3  n 29  m 1  K 4  seed 17175
# metric ceil  return_weight 1
# objective 2297.000000  latency_only 1695.000000  valid 1
# cycles 829801  cycle_segments 71586|73292|74290|74500|73532|73666|73857|75006|79934|79967|80171
Route 1 depot 0 20 13 7 8 16
Route 2 depot 0 17 22 9 10 11 14 15 12 6
Route 3 depot 0 19 21 2 5 0 3 4 1
Route 4 depot 0 18 25 28 23 24 26 27
