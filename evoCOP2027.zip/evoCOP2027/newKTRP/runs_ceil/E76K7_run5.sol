# row E76K7  instance E-n76-k7  n 75  m 1  K 7  seed 33013
# metric ceil  return_weight 1
# objective 3987.000000  latency_only 3184.000000  valid 1
# cycles 223792  cycle_segments 23152|18897|18709|19611|18700|18728|21790|18820|22742|22341|20302
Route 1 depot 0 3 44 28 4 36 19 69 59 70 35 68 60
Route 2 depot 0 5 32 62 15 48 23 22 55
Route 3 depot 0 16 50 2 43 31 49 17 24 54 30
Route 4 depot 0 25 11 39 8 38 71 57 9 37 64 65 10
Route 5 depot 0 33 51 26 12 56 14 46 20 47 29
Route 6 depot 0 66 45 7 34 6 52 13 58 18 53
Route 7 depot 0 74 67 1 73 27 61 72 0 42 40 41 63 21
