# row E33K4  instance E-n33-k4  n 32  m 1  K 4  seed 1337
# metric ceil  return_weight 1
# objective 3814.000000  latency_only 2907.000000  valid 1
# cycles 690210  cycle_segments 62284|65961|65507|69987|63744|61368|60015|61111|60083|60504|59646
Route 1 depot 0 30 0 13 14 16 24 25
Route 2 depot 0 29 28 27 26 15
Route 3 depot 0 2 4 5 6 8 7 9 31 3
Route 4 depot 0 1 11 10 12 17 18 20 19 21 22 23
