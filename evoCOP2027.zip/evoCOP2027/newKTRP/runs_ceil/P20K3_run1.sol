# row P20K3  instance P-n20-k2  n 19  m 1  K 3  seed 1337
# metric ceil  return_weight 1
# objective 1015.000000  latency_only 744.000000  valid 1
# cycles 1462906  cycle_segments 131989|130805|129812|133406|132035|133842|133468|134756|135175|130993|136625
Route 1 depot 0 5 1 7 16 17 2
Route 2 depot 0 0 9 11 14 10 3
Route 3 depot 0 18 4 13 15 8 12 6
