# row E51K5  instance E-n51-k5  n 50  m 1  K 5  seed 9256
# metric ceil  return_weight 1
# objective 2979.000000  latency_only 2376.000000  valid 1
# cycles 402171  cycle_segments 61298|32658|32548|37868|32457|32699|35444|32452|36060|34217|34470
Route 1 depot 0 45 10 37 8 49 15 1 28 20 33 29
Route 2 depot 0 26 5 47 7 25 6 22 23 42
Route 3 depot 0 31 0 21 30 27 2 19 34 35
Route 4 depot 0 46 3 17 13 24 12 40 18 39 41
Route 5 depot 0 11 16 36 43 14 44 32 38 9 48 4
