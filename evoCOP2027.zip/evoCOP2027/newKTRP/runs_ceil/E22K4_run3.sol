# row E22K4  instance E-n22-k4  n 21  m 1  K 4  seed 17175
# metric ceil  return_weight 1
# objective 1262.000000  latency_only 861.000000  valid 1
# cycles 1711674  cycle_segments 206982|133899|145954|157318|136429|124746|147076|134335|204030|160260|160645
Route 1 depot 0 11 14 17 19
Route 2 depot 0 13 15 16 20 18 12
Route 3 depot 0 8 6 4 1 0
Route 4 depot 0 9 7 5 2 3 10
