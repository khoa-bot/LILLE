# row P19K3  instance P-n19-k2  n 18  m 1  K 3  seed 1337
# metric ceil  return_weight 1
# objective 933.000000  latency_only 664.000000  valid 1
# cycles 1562111  cycle_segments 142999|142440|141707|140226|140923|143995|141658|142617|142195|143628|139723
Route 1 depot 0 5 1 6 7 15 16 2
Route 2 depot 0 0 9 11 13 10 3
Route 3 depot 0 17 4 12 14 8
