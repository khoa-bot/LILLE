# row P23K7  instance P-n23-k8  n 22  m 1  K 7  seed 33013
# metric ceil  return_weight 1
# objective 1045.000000  latency_only 631.000000  valid 1
# cycles 990060  cycle_segments 85950|90921|91538|89462|90271|90131|89415|90488|90226|90356|91302
Route 1 depot 0 5 6 21 8 12
Route 2 depot 0 20
Route 3 depot 0 1 7 17 18
Route 4 depot 0 3 10 14
Route 5 depot 0 19 4 16 13
Route 6 depot 0 0 9 11 2
Route 7 depot 0 15
