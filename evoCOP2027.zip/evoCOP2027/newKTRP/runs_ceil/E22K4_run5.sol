# row E22K4  instance E-n22-k4  n 21  m 1  K 4  seed 33013
# metric ceil  return_weight 1
# objective 1262.000000  latency_only 861.000000  valid 1
# cycles 1803393  cycle_segments 125283|166361|191460|167925|168321|132757|189942|145180|156497|155092|204575
Route 1 depot 0 13 15 16 20 18 12
Route 2 depot 0 8 6 4 1 0
Route 3 depot 0 11 14 17 19
Route 4 depot 0 9 7 5 2 3 10
