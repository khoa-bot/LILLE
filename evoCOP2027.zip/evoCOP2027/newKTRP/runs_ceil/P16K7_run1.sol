# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 1337
# metric ceil  return_weight 1
# objective 824.000000  latency_only 427.000000  valid 1
# cycles 1605938  cycle_segments 150371|149283|151047|151176|152134|148203|150603|144446|136855|132319|139501
Route 1 depot 0 9 11 14
Route 2 depot 0 0
Route 3 depot 0 1 7 2
Route 4 depot 0 6 12 8
Route 5 depot 0 3 10
Route 6 depot 0 5
Route 7 depot 0 4 13
