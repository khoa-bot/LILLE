# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 25094
# metric ceil  return_weight 1
# objective 1211.000000  latency_only 969.000000  valid 1
# cycles 1324675  cycle_segments 121366|120869|119714|118430|122232|122596|119447|120088|120016|119205|120712
Route 1 depot 0 5 18 4 13 15 8 12 6 1 9
Route 2 depot 0 0 3 10 14 11 2 7 16 17
