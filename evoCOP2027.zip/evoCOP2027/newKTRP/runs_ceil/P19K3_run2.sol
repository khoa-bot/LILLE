# row P19K3  instance P-n19-k2  n 18  m 1  K 3  seed 9256
# metric ceil  return_weight 1
# objective 933.000000  latency_only 664.000000  valid 1
# cycles 1516813  cycle_segments 139975|139786|141116|138423|135665|137658|136472|136408|136941|137967|136402
Route 1 depot 0 5 1 6 7 15 16 2
Route 2 depot 0 0 9 11 13 10 3
Route 3 depot 0 17 4 12 14 8
