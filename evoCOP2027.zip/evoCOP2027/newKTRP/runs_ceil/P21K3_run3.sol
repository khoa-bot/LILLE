# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 17175
# metric ceil  return_weight 1
# objective 1041.000000  latency_only 767.000000  valid 1
# cycles 1299436  cycle_segments 116442|116875|120040|117044|118105|117517|120753|119078|117859|118081|117642
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
