# row P19K2  instance P-n19-k2  n 18  m 1  K 2  seed 33013
# metric ceil  return_weight 1
# objective 1108.000000  latency_only 870.000000  valid 1
# cycles 1319880  cycle_segments 123961|123959|124826|125508|122755|119649|115402|115782|116803|114300|116935
Route 1 depot 0 5 17 1 6 4 12 14 8
Route 2 depot 0 0 9 3 10 13 11 2 7 15 16
