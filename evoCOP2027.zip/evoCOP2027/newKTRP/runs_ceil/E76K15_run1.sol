# row E76K15  instance E-n76-k7  n 75  m 1  K 15  seed 1337
# metric ceil  return_weight 1
# objective 3281.000000  latency_only 2140.000000  valid 1
# cycles 242639  cycle_segments 23895|20743|22876|20647|22743|22323|21010|20571|20903|21487|25441
Route 1 depot 0 2 43 31 49 17
Route 2 depot 0 25
Route 3 depot 0 5 32 62 22 55
Route 4 depot 0 6 34 52 13 58
Route 5 depot 0 57 9 37 64 65 10
Route 6 depot 0 11 71 38 30
Route 7 depot 0 16 39 8 24 54
Route 8 depot 0 3 44 28 4 36 19 69 59 70
Route 9 depot 0 74 29 73 20 60
Route 10 depot 0 33 51 26 12 56 14
Route 11 depot 0 50 15 48 23
Route 12 depot 0 66 45 7 18 53
Route 13 depot 0 67 1 61 21 27
Route 14 depot 0 72 0 42 40 41 63
Route 15 depot 0 47 46 35 68
