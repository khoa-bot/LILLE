# row E33K4  instance E-n33-k4  n 32  m 1  K 4  seed 17175
# metric ceil  return_weight 1
# objective 3814.000000  latency_only 2907.000000  valid 1
# cycles 702396  cycle_segments 59645|60028|60172|67507|64445|64391|63292|64462|64900|69360|64194
Route 1 depot 0 1 11 10 12 17 18 20 19 21 22 23
Route 2 depot 0 2 4 6 5 8 7 9 31 3
Route 3 depot 0 30 0 13 14 16 24 25
Route 4 depot 0 29 28 27 26 15
