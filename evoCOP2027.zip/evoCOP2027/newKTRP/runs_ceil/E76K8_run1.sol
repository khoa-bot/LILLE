# row E76K8  instance E-n76-k7  n 75  m 1  K 8  seed 1337
# metric ceil  return_weight 1
# objective 3734.000000  latency_only 2878.000000  valid 1
# cycles 294827  cycle_segments 60909|23250|21050|21463|31184|21206|23277|23320|25143|21032|22993
Route 1 depot 0 3 44 28 4 47 46 35 68 20 60
Route 2 depot 0 50 2 43 31 49 17 23 48 15
Route 3 depot 0 16 39 38 8 24 54 30
Route 4 depot 0 74 67 1 29 73 27 61 21 63
Route 5 depot 0 33 51 26 12 56 14 36 19 69 59 70
Route 6 depot 0 5 32 72 0 42 41 40 55 22 62
Route 7 depot 0 66 45 7 34 6 52 13 18 53
Route 8 depot 0 25 11 71 57 9 37 64 10 65 58
