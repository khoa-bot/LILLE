# row P16K5  instance P-n16-k8  n 15  m 1  K 5  seed 17175
# metric ceil  return_weight 1
# objective 774.000000  latency_only 432.000000  valid 1
# cycles 1991256  cycle_segments 178234|175577|177223|177493|176948|177045|175637|178897|194131|187750|192321
Route 1 depot 0 3 10
Route 2 depot 0 5 6 8 12
Route 3 depot 0 0 9 11 14
Route 4 depot 0 4 13
Route 5 depot 0 1 7 2
