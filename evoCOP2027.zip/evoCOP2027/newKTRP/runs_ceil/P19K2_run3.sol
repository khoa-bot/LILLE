# row P19K2  instance P-n19-k2  n 18  m 1  K 2  seed 17175
# metric ceil  return_weight 1
# objective 1108.000000  latency_only 870.000000  valid 1
# cycles 1376581  cycle_segments 123566|126317|126346|125430|126518|126867|124410|124415|124207|123269|125236
Route 1 depot 0 5 17 1 6 4 12 14 8
Route 2 depot 0 0 9 3 10 13 11 2 7 15 16
