# row P16K5  instance P-n16-k8  n 15  m 1  K 5  seed 25094
# metric ceil  return_weight 1
# objective 774.000000  latency_only 430.000000  valid 1
# cycles 2143359  cycle_segments 191145|209020|193733|188196|205662|190958|199664|184606|204118|187657|188600
Route 1 depot 0 4 13
Route 2 depot 0 0 9 11 14
Route 3 depot 0 1 7 2
Route 4 depot 0 5 6 12 8
Route 5 depot 0 3 10
