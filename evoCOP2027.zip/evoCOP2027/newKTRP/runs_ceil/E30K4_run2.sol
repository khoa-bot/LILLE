# row E30K4  instance E-n30-k3  n 29  m 1  K 4  seed 9256
# metric ceil  return_weight 1
# objective 2297.000000  latency_only 1695.000000  valid 1
# cycles 817139  cycle_segments 73738|74108|72264|72592|72399|74402|80755|73771|74383|74035|74692
Route 1 depot 0 20 13 7 8 16
Route 2 depot 0 17 22 9 10 11 14 15 12 6
Route 3 depot 0 19 21 2 5 0 3 4 1
Route 4 depot 0 18 25 28 23 24 26 27
