# row E76K10  instance E-n76-k7  n 75  m 1  K 10  seed 33013
# metric ceil  return_weight 1
# objective 3441.000000  latency_only 2496.000000  valid 1
# cycles 269416  cycle_segments 33079|22067|24197|28207|26213|24078|22441|20789|22897|20667|24781
Route 1 depot 0 3 44 28 4 36 19 69 59 70
Route 2 depot 0 5 32 72 0 42 40 41 63
Route 3 depot 0 25 11 71 57 9 37 64 65 10
Route 4 depot 0 16 39 38 8 24 54 30
Route 5 depot 0 2 43 31 49 17 23
Route 6 depot 0 33 51 26 14 56 12 53 18
Route 7 depot 0 50 15 62 22 55 48
Route 8 depot 0 66 45 7 34 6 52 13 58
Route 9 depot 0 74 67 1 73 27 61 21 60
Route 10 depot 0 29 47 46 35 68 20
