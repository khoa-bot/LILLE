# row P16K5  instance P-n16-k8  n 15  m 1  K 5  seed 9256
# metric ceil  return_weight 1
# objective 774.000000  latency_only 430.000000  valid 1
# cycles 2039077  cycle_segments 176517|184670|176885|189281|177530|183507|180183|180131|179259|198218|212896
Route 1 depot 0 0 9 11 14
Route 2 depot 0 1 7 2
Route 3 depot 0 3 10
Route 4 depot 0 5 6 12 8
Route 5 depot 0 4 13
