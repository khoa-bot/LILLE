# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 17175
# metric ceil  return_weight 1
# objective 1211.000000  latency_only 969.000000  valid 1
# cycles 1341644  cycle_segments 120393|120618|131852|119940|121766|122236|120104|120851|120783|121048|122053
Route 1 depot 0 5 18 4 13 15 8 12 6 1 9
Route 2 depot 0 0 3 10 14 11 2 7 16 17
