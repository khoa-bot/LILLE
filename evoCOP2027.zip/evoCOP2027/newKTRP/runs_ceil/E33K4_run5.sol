# row E33K4  instance E-n33-k4  n 32  m 1  K 4  seed 33013
# metric ceil  return_weight 1
# objective 3814.000000  latency_only 2907.000000  valid 1
# cycles 707748  cycle_segments 63661|64738|64617|65013|65362|63798|63217|64485|63822|64404|64631
Route 1 depot 0 1 11 10 12 17 18 20 19 21 22 23
Route 2 depot 0 2 4 6 5 8 7 9 31 3
Route 3 depot 0 29 28 27 26 15
Route 4 depot 0 30 0 13 14 16 24 25
