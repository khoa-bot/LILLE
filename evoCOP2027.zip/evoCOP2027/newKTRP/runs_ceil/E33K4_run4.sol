# row E33K4  instance E-n33-k4  n 32  m 1  K 4  seed 25094
# metric ceil  return_weight 1
# objective 3814.000000  latency_only 2907.000000  valid 1
# cycles 707940  cycle_segments 64398|64891|64998|64363|62888|64727|63700|63296|64432|65334|64913
Route 1 depot 0 1 11 10 12 17 18 20 19 21 22 23
Route 2 depot 0 2 4 5 6 8 7 9 31 3
Route 3 depot 0 29 28 27 26 15
Route 4 depot 0 30 0 13 14 16 24 25
