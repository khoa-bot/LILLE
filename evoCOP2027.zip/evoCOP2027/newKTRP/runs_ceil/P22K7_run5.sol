# row P22K7  instance P-n22-k2  n 21  m 1  K 7  seed 33013
# metric ceil  return_weight 1
# objective 1060.000000  latency_only 625.000000  valid 1
# cycles 1129361  cycle_segments 100334|102464|101092|99956|100534|100600|110994|109820|100220|100700|102647
Route 1 depot 0 15
Route 2 depot 0 19 4 16 13
Route 3 depot 0 9 11 2
Route 4 depot 0 5 6 20 8 12
Route 5 depot 0 1 7 17 18
Route 6 depot 0 0
Route 7 depot 0 3 10 14
