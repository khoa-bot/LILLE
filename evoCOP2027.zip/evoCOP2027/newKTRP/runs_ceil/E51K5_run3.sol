# row E51K5  instance E-n51-k5  n 50  m 1  K 5  seed 17175
# metric ceil  return_weight 1
# objective 2979.000000  latency_only 2391.000000  valid 1
# cycles 403374  cycle_segments 46509|33643|33545|33755|33865|34395|37383|37019|37116|36288|39856
Route 1 depot 0 46 3 17 13 24 12 40 18 39 41
Route 2 depot 0 31 0 21 30 27 2 19 34 35
Route 3 depot 0 11 16 36 43 14 44 32 38 9 48 4
Route 4 depot 0 26 47 7 25 6 22 42 23 5
Route 5 depot 0 45 10 37 8 49 15 1 28 20 33 29
