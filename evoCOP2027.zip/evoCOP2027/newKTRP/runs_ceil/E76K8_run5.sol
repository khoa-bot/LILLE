# row E76K8  instance E-n76-k7  n 75  m 1  K 8  seed 33013
# metric ceil  return_weight 1
# objective 3742.000000  latency_only 2912.000000  valid 1
# cycles 240425  cycle_segments 28357|22846|21029|20563|20885|20811|20748|20743|23030|20614|20799
Route 1 depot 0 3 44 28 4 36 19 69 59 70 35 68
Route 2 depot 0 50 15 62 22 55 48 23
Route 3 depot 0 16 2 43 31 49 17 24 54 30
Route 4 depot 0 25 11 39 8 38 71 57 9 37 64
Route 5 depot 0 74 67 1 29 47 46 20 60 27 73
Route 6 depot 0 33 51 26 14 56 12 53 18
Route 7 depot 0 66 45 7 34 6 52 10 65 58 13
Route 8 depot 0 5 32 72 0 42 40 41 63 21 61
