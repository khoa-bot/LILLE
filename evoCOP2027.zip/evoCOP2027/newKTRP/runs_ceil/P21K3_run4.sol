# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 25094
# metric ceil  return_weight 1
# objective 1041.000000  latency_only 767.000000  valid 1
# cycles 1287451  cycle_segments 116701|116085|118218|115048|118780|115829|117782|117506|115645|117406|118451
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
