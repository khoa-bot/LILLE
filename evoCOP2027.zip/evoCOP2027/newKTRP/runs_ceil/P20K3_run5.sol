# row P20K3  instance P-n20-k2  n 19  m 1  K 3  seed 33013
# metric ceil  return_weight 1
# objective 1015.000000  latency_only 739.000000  valid 1
# cycles 1473068  cycle_segments 133509|134591|135322|133483|133814|134942|133697|132273|132082|134434|134921
Route 1 depot 0 5 6 1 7 16 17 2
Route 2 depot 0 0 9 11 14 10 3
Route 3 depot 0 18 4 13 15 8 12
