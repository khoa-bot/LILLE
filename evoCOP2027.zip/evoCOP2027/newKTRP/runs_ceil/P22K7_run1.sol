# row P22K7  instance P-n22-k2  n 21  m 1  K 7  seed 1337
# metric ceil  return_weight 1
# objective 1060.000000  latency_only 625.000000  valid 1
# cycles 1133628  cycle_segments 101776|101640|103216|110999|101508|101935|102041|101855|103178|102853|102627
Route 1 depot 0 15
Route 2 depot 0 5 6 20 8 12
Route 3 depot 0 9 11 2
Route 4 depot 0 19 4 16 13
Route 5 depot 0 0
Route 6 depot 0 1 7 17 18
Route 7 depot 0 3 10 14
