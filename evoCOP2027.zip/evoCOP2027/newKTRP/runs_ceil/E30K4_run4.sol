# row E30K4  instance E-n30-k3  n 29  m 1  K 4  seed 25094
# metric ceil  return_weight 1
# objective 2297.000000  latency_only 1695.000000  valid 1
# cycles 889072  cycle_segments 80206|79828|80937|78972|80316|80215|81253|86269|80620|79930|80526
Route 1 depot 0 20 13 7 8 16
Route 2 depot 0 17 22 9 10 11 14 15 12 6
Route 3 depot 0 19 21 2 5 0 3 4 1
Route 4 depot 0 18 25 28 23 24 26 27
