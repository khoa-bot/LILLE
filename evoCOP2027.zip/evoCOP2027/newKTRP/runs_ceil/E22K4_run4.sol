# row E22K4  instance E-n22-k4  n 21  m 1  K 4  seed 25094
# metric ceil  return_weight 1
# objective 1262.000000  latency_only 861.000000  valid 1
# cycles 1624000  cycle_segments 151782|182049|156444|124170|159703|123640|180143|125685|137692|147182|135510
Route 1 depot 0 8 6 4 1 0
Route 2 depot 0 13 15 16 20 18 12
Route 3 depot 0 11 14 17 19
Route 4 depot 0 9 7 5 2 3 10
