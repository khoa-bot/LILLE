# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 1337
# metric ceil  return_weight 1
# objective 1211.000000  latency_only 969.000000  valid 1
# cycles 1237100  cycle_segments 120936|110980|110888|110937|113467|111912|111292|113285|111172|110355|111876
Route 1 depot 0 0 3 10 14 11 2 7 16 17
Route 2 depot 0 5 18 4 13 15 8 12 6 1 9
