#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    string path=argv[1]; int K=atoi(argv[2]); long long LAM=atoll(argv[3]); string rnd=argv[4]; bool exactK=(string(argv[5])=="exact");
    ifstream in(path); string line; int dim=0; vector<double> xs,ys; bool inc=false;
    while(getline(in,line)){ if(!line.empty()&&line.back()=='\r') line.pop_back();
        if(line.find("DIMENSION")!=string::npos){size_t p=line.find(':');dim=atoi(line.c_str()+p+1);}
        if(line.find("NODE_COORD_SECTION")!=string::npos){inc=true;continue;}
        if(inc){ if(line.find("DEMAND")!=string::npos||line.find("DEPOT")!=string::npos||line.find("EOF")!=string::npos)break;
            istringstream s(line); int id;double x,y; if(s>>id>>x>>y){xs.push_back(x);ys.push_back(y);} } }
    int N=dim,m=N-1; vector<vector<long long>> C(N,vector<long long>(N,0));
    const long long SC=(rnd=="raw")?1000000LL:1LL;
    for(int i=0;i<N;i++)for(int j=0;j<N;j++){double d=hypot(xs[i]-xs[j],ys[i]-ys[j]);
        C[i][j]= rnd=="nearest"?(long long)llround(d): rnd=="floor"?(long long)floor(d): rnd=="ceil"?(long long)ceil(d):(long long)llround(d*1e6);}
    const long long INF=LLONG_MAX/4; int S=1<<m;
    vector<long long> f((size_t)S*m,INF); auto FI=[&](int s,int h){return (size_t)s*m+h;};
    for(int h=0;h<m;h++) f[FI(1<<h,h)]=C[h+1][0]*LAM;      // return arc coefficient = LAM
    for(int s=1;s<S;s++){ int pc=__builtin_popcount(s); if(pc<2)continue; long long coef=(pc-1)+LAM;
        for(int h=0;h<m;h++){ if(!((s>>h)&1))continue; int rest=s^(1<<h); long long best=INF;
            for(int h2=0;h2<m;h2++){ if(!((rest>>h2)&1))continue; long long v=f[FI(rest,h2)]; if(v>=INF)continue;
                long long t=C[h+1][h2+1]*coef+v; if(t<best)best=t;} f[FI(s,h)]=best; } }
    vector<long long> route(S,INF);
    for(int s=1;s<S;s++){ int pc=__builtin_popcount(s); long long coef=pc+LAM, best=INF;
        for(int h=0;h<m;h++){ if(!((s>>h)&1))continue; long long v=f[FI(s,h)]; if(v>=INF)continue;
            long long t=C[0][h+1]*coef+v; if(t<best)best=t;} route[s]=best; }
    vector<long long> prev(S,INF),cur(S,INF); prev[0]=0; long long ans=INF;
    for(int j=1;j<=K;j++){ fill(cur.begin(),cur.end(),INF);
        for(int s=1;s<S;s++){ int low=s&(-s),rem=s^low; long long best=INF;
            for(int t=rem;;t=(t-1)&rem){ int T=t|low; long long a=route[T],b=prev[s^T];
                if(a<INF&&b<INF&&a+b<best)best=a+b; if(t==0)break;} cur[s]=best;}
        if(!exactK) ans=min(ans,cur[S-1]); prev=cur; }
    if(exactK) ans=prev[S-1];
    printf("%-22s K=%-3d lam=%lld %-8s %-8s -> %.4f\n",path.c_str(),K,LAM,rnd.c_str(),exactK?"exactK":"atmostK",(double)ans/SC);
    return 0;}
