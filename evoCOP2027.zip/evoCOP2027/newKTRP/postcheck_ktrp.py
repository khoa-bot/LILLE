#!/usr/bin/env python3
"""
postcheck_ktrp.py -- independent verification of every run this build produced.

Nothing here is shared with main_ga_ktrp.cpp: its own .vrp parser, its own
distance function, and the objective written out LITERALLY as the paper states
it, arc by arc:

        L_k = sum_{i=0..m} (m + 1 - i) * C(v_i, v_{i+1}),   v_{m+1} = v_0

i.e. the first arc is multiplied by m+1, the next by m, ..., and the RETURN arc
by 1.  No algebraic rearrangement, no reuse of the C++ decomposition.  If the
"latency + closed length" form the C++ actually computes were not identical to
this, every row would disagree here.

It also re-verifies each tour from scratch: exactly K routes, every route
non-empty, every customer visited exactly once, no customer missing, no id out
of range, every route anchored at the depot.

    python3 postcheck_ktrp.py [runs_dir]
"""
import math, os, re, sys, glob
from collections import defaultdict

RUNS = sys.argv[1] if len(sys.argv) > 1 else "runs"
ROOT = ".."

def read_vrp(name):
    """Own parser. Returns (depot_xy, [customer_xy ...]) in the build's indexing:
       customer i == TSPLIB node i+2, depot == TSPLIB node 1."""
    for sub in ("P", "E"):
        p = os.path.join(ROOT, sub, name + ".vrp")
        if os.path.exists(p):
            break
    else:
        raise SystemExit("cannot find instance file for " + name)
    dim, coords, insec = None, [], False
    for line in open(p):
        line = line.strip()
        if not line:
            continue
        if line.startswith("DIMENSION"):
            dim = int(line.split(":")[1])
        elif line.startswith("EDGE_WEIGHT_TYPE"):
            if line.split(":")[1].strip() != "EUC_2D":
                raise SystemExit(name + ": not EUC_2D")
        elif line.startswith("NODE_COORD_SECTION"):
            insec = True
        elif insec:
            if line[0].isalpha():
                break
            t = line.split()
            coords.append((float(t[1]), float(t[2])))
    if dim is None or len(coords) != dim:
        raise SystemExit(name + ": DIMENSION %s vs %d coords" % (dim, len(coords)))
    return coords[0], coords[1:]          # depot, customers 0..n-1

def dist(a, b):                            # ceil-rounded Euclidean, as calibrated
    return math.ceil(math.hypot(a[0] - b[0], a[1] - b[1]))

def eq1(depot, cust, route):
    """Literal eq. (1): sum_{i=0..m} (m+1-i) * C(v_i, v_{i+1}), v_{m+1} = v_0."""
    pts = [depot] + [cust[c] for c in route] + [depot]
    m = len(route)
    if m == 0:
        return 0.0
    tot = 0
    for i in range(0, m + 1):              # i = 0 .. m  -> m+1 arcs
        tot += (m + 1 - i) * dist(pts[i], pts[i + 1])
    return float(tot)

def latency_only(depot, cust, route):
    """Depot-exclusive, no return leg -- checks the secondary column."""
    pts = [depot] + [cust[c] for c in route]
    t = L = 0
    for s in range(1, len(pts)):
        t += dist(pts[s - 1], pts[s]); L += t
    return float(L)

files = sorted(glob.glob(os.path.join(RUNS, "*.sol")))
if not files:
    raise SystemExit("no .sol files in " + RUNS)

cache, best, problems, checked = {}, defaultdict(lambda: None), [], 0
for f in files:
    hdr, routes = {}, []
    for line in open(f):
        line = line.rstrip("\n")
        if line.startswith("#"):
            for k, v in re.findall(r"(\w+)\s+(-?[\w.\-]+)", line[1:]):
                hdr[k] = v
        elif line.startswith("Route"):
            t = line.split()
            routes.append((int(t[3]), [int(x) for x in t[4:]]))
    inst, K = hdr["instance"], int(hdr["K"])
    n, claimed = int(hdr["n"]), float(hdr["objective"])
    claimed_lat = float(hdr["latency_only"])
    if inst not in cache:
        cache[inst] = read_vrp(inst)
    depot, cust = cache[inst]

    tag = os.path.basename(f)
    if len(cust) != n:
        problems.append("%s: header n=%d but instance has %d customers" % (tag, n, len(cust)))
        continue

    # ---- tour verification, from scratch ---------------------------------
    seen = defaultdict(int)
    if len(routes) != K:
        problems.append("%s: %d routes, K=%d" % (tag, len(routes), K))
    for ri, (dep, body) in enumerate(routes, 1):
        if dep != 0:
            problems.append("%s: route %d depot id %d (single depot -> must be 0)" % (tag, ri, dep))
        if not body:
            problems.append("%s: route %d is empty" % (tag, ri))
        for c in body:
            if not (0 <= c < n):
                problems.append("%s: route %d has out-of-range customer %d" % (tag, ri, c))
            else:
                seen[c] += 1
    dup = [c for c in seen if seen[c] > 1]
    miss = [c for c in range(n) if seen[c] == 0]
    if dup:
        problems.append("%s: %d customer(s) visited twice, e.g. %s" % (tag, len(dup), dup[:5]))
    if miss:
        problems.append("%s: %d customer(s) never visited, e.g. %s" % (tag, len(miss), miss[:5]))

    # ---- objective recomputation, literal formula -------------------------
    z   = sum(eq1(depot, cust, body)          for _, body in routes)
    lat = sum(latency_only(depot, cust, body) for _, body in routes)
    if abs(z - claimed) > 1e-6:
        problems.append("%s: eq.(1) gives %.4f, dump claims %.4f" % (tag, z, claimed))
    if abs(lat - claimed_lat) > 1e-6:
        problems.append("%s: latency gives %.4f, dump claims %.4f" % (tag, lat, claimed_lat))
    checked += 1

    row = hdr["row"]
    if best[row] is None or z < best[row][0]:
        best[row] = (z, lat, tag)

print("verified %d run dumps over %d instances" % (checked, len(cache)))
print()
print("%-9s %-13s %10s %12s   %s" % ("Row", "instance", "best eq.(1)", "latency", "from"))
for row in sorted(best, key=lambda r: files.index(next(f for f in files if "/" + r + "_" in f or os.path.basename(f).startswith(r + "_")))):
    z, lat, tag = best[row]
    print("%-9s %-13s %10.0f %12.0f   %s" % (row, "", z, lat, tag))
print()
if problems:
    print("!! %d PROBLEM(S):" % len(problems))
    for p in problems[:40]:
        print("   " + p)
    sys.exit(2)
print("all runs: tours valid, eq.(1) objective and depot-exclusive latency both reproduced exactly")
