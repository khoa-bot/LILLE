# row P23K7  instance P-n23-k8  n 22  m 1  K 7  seed 17175
# metric nearest  return_weight 1
# objective 994.000000  latency_only 612.000000  valid 1
# cycles 913282  cycle_segments 84284|84564|85852|81704|84038|84659|83956|70332|86092|83850|83951
Route 1 depot 0 5 6 12 8
Route 2 depot 0 3 10
Route 3 depot 0 20
Route 4 depot 0 15
Route 5 depot 0 19 4 21 16 13
Route 6 depot 0 1 7 17 18 2
Route 7 depot 0 0 9 11 14
