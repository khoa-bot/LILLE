# row P19K2  instance P-n19-k2  n 18  m 1  K 2  seed 33013
# metric nearest  return_weight 1
# objective 1027.000000  latency_only 817.000000  valid 1
# cycles 1320152  cycle_segments 124673|135670|123358|124943|122472|116988|115150|114863|113263|113856|114916
Route 1 depot 0 5 1 6 8 14 12 4 17
Route 2 depot 0 0 9 3 10 13 11 2 7 15 16
