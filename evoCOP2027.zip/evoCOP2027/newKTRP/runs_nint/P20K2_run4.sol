# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 25094
# metric nearest  return_weight 1
# objective 1124.000000  latency_only 898.000000  valid 1
# cycles 1327060  cycle_segments 121939|119090|122029|121055|120303|122365|121687|119443|121554|117734|119861
Route 1 depot 0 5 18 4 13 15 8 12 6 1
Route 2 depot 0 0 9 3 10 14 11 2 7 16 17
