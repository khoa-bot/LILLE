# row P19K3  instance P-n19-k2  n 18  m 1  K 3  seed 17175
# metric nearest  return_weight 1
# objective 876.000000  latency_only 622.000000  valid 1
# cycles 1578057  cycle_segments 134086|136145|140623|137470|137284|152599|139687|138046|144764|171270|146083
Route 1 depot 0 5 1 6 7 15 16 2
Route 2 depot 0 0 9 11 13 10 3
Route 3 depot 0 17 4 12 14 8
