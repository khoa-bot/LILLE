# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 1337
# metric nearest  return_weight 1
# objective 968.000000  latency_only 712.000000  valid 1
# cycles 1297716  cycle_segments 118297|119928|117108|116331|116637|118367|120009|118219|117898|117998|116924
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
