# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 33013
# metric nearest  return_weight 1
# objective 968.000000  latency_only 712.000000  valid 1
# cycles 1301576  cycle_segments 116822|118730|121406|118060|118092|120259|117030|116908|117919|117380|118970
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
