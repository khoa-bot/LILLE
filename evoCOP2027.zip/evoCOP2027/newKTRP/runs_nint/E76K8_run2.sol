# row E76K8  instance E-n76-k7  n 75  m 1  K 8  seed 9256
# metric nearest  return_weight 1
# objective 3454.000000  latency_only 2669.000000  valid 1
# cycles 306970  cycle_segments 26511|49436|36831|19623|26019|19336|19368|31425|21591|33848|22982
Route 1 depot 0 3 44 28 4 36 19 69 59 70 35 68 60
Route 2 depot 0 5 32 72 0 42 40 41 63 21
Route 3 depot 0 16 2 43 31 49 17 54 24
Route 4 depot 0 25 11 39 8 38 71 57 9 30
Route 5 depot 0 33 51 26 14 56 12 53 18 13 58
Route 6 depot 0 50 15 62 22 55 48 23
Route 7 depot 0 66 45 7 34 6 52 10 65 64 37
Route 8 depot 0 74 67 1 61 27 73 20 46 47 29
