# row E51K5  instance E-n51-k5  n 50  m 1  K 5  seed 1337
# metric nearest  return_weight 1
# objective 2773.000000  latency_only 2211.000000  valid 1
# cycles 471215  cycle_segments 68759|35693|46816|41604|47146|38247|44284|32496|38483|32895|44792
Route 1 depot 0 11 16 36 43 14 44 32 9 48 4
Route 2 depot 0 31 0 21 30 27 2 35 34 19 1
Route 3 depot 0 26 5 47 7 25 6 22 23 42
Route 4 depot 0 45 10 37 8 49 15 28 20 33 29 38
Route 5 depot 0 46 3 17 13 24 12 40 18 39 41
