# row P20K3  instance P-n20-k2  n 19  m 1  K 3  seed 33013
# metric nearest  return_weight 1
# objective 950.000000  latency_only 696.000000  valid 1
# cycles 1448723  cycle_segments 130840|133135|133340|131150|131634|131614|132507|132108|132171|129067|131157
Route 1 depot 0 5 1 7 16 17 2
Route 2 depot 0 0 9 11 14 10 3
Route 3 depot 0 18 4 13 15 8 12 6
