# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 25094
# metric nearest  return_weight 1
# objective 968.000000  latency_only 712.000000  valid 1
# cycles 1337823  cycle_segments 126992|127928|128011|124074|118291|119825|120611|116848|118108|118035|119100
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
