# row E30K4  instance E-n30-k3  n 29  m 1  K 4  seed 25094
# metric nearest  return_weight 1
# objective 2222.000000  latency_only 1646.000000  valid 1
# cycles 841035  cycle_segments 71163|72427|72980|71319|75246|78672|86006|77628|76739|75888|82967
Route 1 depot 0 22 9 10 11 8 16 7 13 20
Route 2 depot 0 17 14 15 12 6
Route 3 depot 0 19 21 2 5 23 0 3 4 1
Route 4 depot 0 18 25 28 24 26 27
