# row P19K2  instance P-n19-k2  n 18  m 1  K 2  seed 25094
# metric nearest  return_weight 1
# objective 1027.000000  latency_only 817.000000  valid 1
# cycles 1373185  cycle_segments 125129|126205|126214|124926|124861|126780|120518|125961|124243|122586|125762
Route 1 depot 0 5 1 6 8 14 12 4 17
Route 2 depot 0 0 9 3 10 13 11 2 7 15 16
