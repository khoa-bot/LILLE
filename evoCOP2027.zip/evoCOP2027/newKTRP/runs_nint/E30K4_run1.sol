# row E30K4  instance E-n30-k3  n 29  m 1  K 4  seed 1337
# metric nearest  return_weight 1
# objective 2222.000000  latency_only 1646.000000  valid 1
# cycles 853559  cycle_segments 77342|77696|76873|90520|77453|78079|82278|77008|72996|71249|72065
Route 1 depot 0 17 22 9 10 11 8 16 7 13 20
Route 2 depot 0 14 15 12 6
Route 3 depot 0 19 21 2 5 23 0 3 4 1
Route 4 depot 0 18 25 28 24 26 27
