# row E22K4  instance E-n22-k4  n 21  m 1  K 4  seed 17175
# metric nearest  return_weight 1
# objective 1194.000000  latency_only 809.000000  valid 1
# cycles 1854122  cycle_segments 147624|211290|137993|175075|189324|175857|228730|195036|128311|128474|136408
Route 1 depot 0 13 15 16 19 17 14
Route 2 depot 0 12 18 20
Route 3 depot 0 11 8 6 4 1 0
Route 4 depot 0 9 7 5 2 3 10
