# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 33013
# metric nearest  return_weight 1
# objective 1124.000000  latency_only 898.000000  valid 1
# cycles 1245772  cycle_segments 121521|120978|113254|111376|111269|113081|112462|109482|109861|110944|111544
Route 1 depot 0 5 18 4 13 15 8 12 6 1
Route 2 depot 0 0 9 3 10 14 11 2 7 16 17
