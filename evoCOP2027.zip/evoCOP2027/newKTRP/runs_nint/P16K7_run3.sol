# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 17175
# metric nearest  return_weight 1
# objective 788.000000  latency_only 406.000000  valid 1
# cycles 1709897  cycle_segments 134652|169802|133138|168232|156481|132924|131690|178908|154951|169702|179417
Route 1 depot 0 6 12 8
Route 2 depot 0 1 7 2
Route 3 depot 0 3 10
Route 4 depot 0 4 13
Route 5 depot 0 5
Route 6 depot 0 0
Route 7 depot 0 9 11 14
