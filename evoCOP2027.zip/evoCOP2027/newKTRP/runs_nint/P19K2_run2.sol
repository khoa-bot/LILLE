# row P19K2  instance P-n19-k2  n 18  m 1  K 2  seed 9256
# metric nearest  return_weight 1
# objective 1027.000000  latency_only 817.000000  valid 1
# cycles 1265936  cycle_segments 114587|115610|116670|115493|114249|116181|116502|114350|113258|114017|115019
Route 1 depot 0 5 1 6 8 14 12 4 17
Route 2 depot 0 0 9 3 10 13 11 2 7 15 16
