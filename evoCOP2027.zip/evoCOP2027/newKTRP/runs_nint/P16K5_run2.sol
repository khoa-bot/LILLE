# row P16K5  instance P-n16-k8  n 15  m 1  K 5  seed 9256
# metric nearest  return_weight 1
# objective 736.000000  latency_only 406.000000  valid 1
# cycles 2917996  cycle_segments 188549|378719|193850|196075|234177|246005|371379|195464|354651|214699|344428
Route 1 depot 0 5 6 12 8
Route 2 depot 0 3 10
Route 3 depot 0 1 7 2
Route 4 depot 0 0 9 11 14
Route 5 depot 0 4 13
