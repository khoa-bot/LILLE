# row E30K4  instance E-n30-k3  n 29  m 1  K 4  seed 9256
# metric nearest  return_weight 1
# objective 2222.000000  latency_only 1643.000000  valid 1
# cycles 791573  cycle_segments 72635|71660|71490|72219|68156|72940|72748|72055|72721|72655|72294
Route 1 depot 0 17 22 9 10 11 8 16 7 13 20
Route 2 depot 0 14 15 12 6
Route 3 depot 0 18 25 28 24 23 26 27
Route 4 depot 0 19 21 2 5 0 3 4 1
