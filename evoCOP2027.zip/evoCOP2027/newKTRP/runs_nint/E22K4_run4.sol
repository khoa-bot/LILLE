# row E22K4  instance E-n22-k4  n 21  m 1  K 4  seed 25094
# metric nearest  return_weight 1
# objective 1194.000000  latency_only 809.000000  valid 1
# cycles 1717310  cycle_segments 161292|137834|127733|136884|124531|137435|203737|238958|126379|195611|126916
Route 1 depot 0 9 7 5 2 3 10
Route 2 depot 0 11 8 6 4 1 0
Route 3 depot 0 13 15 16 19 17 14
Route 4 depot 0 12 18 20
