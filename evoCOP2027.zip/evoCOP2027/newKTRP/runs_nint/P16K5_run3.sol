# row P16K5  instance P-n16-k8  n 15  m 1  K 5  seed 17175
# metric nearest  return_weight 1
# objective 736.000000  latency_only 406.000000  valid 1
# cycles 2095380  cycle_segments 228714|196493|213394|173790|196868|177106|178334|179059|179446|177805|194371
Route 1 depot 0 1 7 2
Route 2 depot 0 4 13
Route 3 depot 0 0 9 11 14
Route 4 depot 0 3 10
Route 5 depot 0 5 6 12 8
