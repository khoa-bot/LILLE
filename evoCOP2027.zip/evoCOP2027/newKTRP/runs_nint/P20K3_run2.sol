# row P20K3  instance P-n20-k2  n 19  m 1  K 3  seed 9256
# metric nearest  return_weight 1
# objective 950.000000  latency_only 696.000000  valid 1
# cycles 1534783  cycle_segments 131143|134129|133790|141352|131092|134152|139356|144696|143198|157449|144426
Route 1 depot 0 5 1 7 16 17 2
Route 2 depot 0 0 9 11 14 10 3
Route 3 depot 0 18 4 13 15 8 12 6
