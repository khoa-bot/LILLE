# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 25094
# metric nearest  return_weight 1
# objective 788.000000  latency_only 408.000000  valid 1
# cycles 1996452  cycle_segments 154936|220771|192037|132382|241663|180599|244778|143176|156212|156823|173075
Route 1 depot 0 5
Route 2 depot 0 1 7 2
Route 3 depot 0 3 10
Route 4 depot 0 4 13
Route 5 depot 0 6 8 12
Route 6 depot 0 0
Route 7 depot 0 9 11 14
