# row E76K10  instance E-n76-k7  n 75  m 1  K 10  seed 9256
# metric nearest  return_weight 1
# objective 3179.000000  latency_only 2287.000000  valid 1
# cycles 253665  cycle_segments 22507|21558|24411|24532|22811|24721|22637|22520|22418|22753|22797
Route 1 depot 0 25 6 52 10 65 64 37
Route 2 depot 0 5 32 72 0 42 40 41 63
Route 3 depot 0 11 39 8 38 71 57 9 30
Route 4 depot 0 3 44 28 4 36 19 69 59 70
Route 5 depot 0 16 2 43 31 49 17 24 54
Route 6 depot 0 74 29 47 46 35 68 20
Route 7 depot 0 66 45 7 34 18 13 58
Route 8 depot 0 50 15 62 22 55 48 23
Route 9 depot 0 33 51 26 12 53 56 14
Route 10 depot 0 67 1 73 27 61 21 60
