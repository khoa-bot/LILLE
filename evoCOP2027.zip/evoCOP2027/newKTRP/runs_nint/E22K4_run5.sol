# row E22K4  instance E-n22-k4  n 21  m 1  K 4  seed 33013
# metric nearest  return_weight 1
# objective 1194.000000  latency_only 809.000000  valid 1
# cycles 1534317  cycle_segments 135009|147249|160078|122199|124577|123942|131944|145121|136915|135001|172282
Route 1 depot 0 9 7 5 2 3 10
Route 2 depot 0 11 8 6 4 1 0
Route 3 depot 0 12 18 20
Route 4 depot 0 13 15 16 19 17 14
