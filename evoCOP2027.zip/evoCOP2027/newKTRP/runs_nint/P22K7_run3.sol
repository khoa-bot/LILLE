# row P22K7  instance P-n22-k2  n 21  m 1  K 7  seed 17175
# metric nearest  return_weight 1
# objective 1012.000000  latency_only 611.000000  valid 1
# cycles 1016510  cycle_segments 91826|90638|92952|92567|91915|93860|93219|92142|91686|93164|92541
Route 1 depot 0 19 4 13 16
Route 2 depot 0 15
Route 3 depot 0 0 9 11 14
Route 4 depot 0 5
Route 5 depot 0 6 20 8 12
Route 6 depot 0 1 7 17 18 2
Route 7 depot 0 3 10
