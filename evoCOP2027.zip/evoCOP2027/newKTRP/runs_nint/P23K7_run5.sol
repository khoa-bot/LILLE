# row P23K7  instance P-n23-k8  n 22  m 1  K 7  seed 33013
# metric nearest  return_weight 1
# objective 994.000000  latency_only 613.000000  valid 1
# cycles 996187  cycle_segments 89318|90013|90872|91125|89986|91252|92369|90581|90911|90401|89359
Route 1 depot 0 5 6 21 8 12
Route 2 depot 0 3 10
Route 3 depot 0 19 4 13 16
Route 4 depot 0 0 9 11 14
Route 5 depot 0 20
Route 6 depot 0 1 7 17 18 2
Route 7 depot 0 15
