# row P22K7  instance P-n22-k2  n 21  m 1  K 7  seed 33013
# metric nearest  return_weight 1
# objective 1012.000000  latency_only 611.000000  valid 1
# cycles 1090986  cycle_segments 91733|94372|101772|99828|99983|101559|101466|100181|99571|100886|99635
Route 1 depot 0 0 9 11 14
Route 2 depot 0 19 4 13 16
Route 3 depot 0 3 10
Route 4 depot 0 6 20 8 12
Route 5 depot 0 1 7 17 18 2
Route 6 depot 0 15
Route 7 depot 0 5
