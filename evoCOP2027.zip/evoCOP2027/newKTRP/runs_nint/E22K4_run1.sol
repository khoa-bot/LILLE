# row E22K4  instance E-n22-k4  n 21  m 1  K 4  seed 1337
# metric nearest  return_weight 1
# objective 1194.000000  latency_only 809.000000  valid 1
# cycles 1742723  cycle_segments 136777|149333|149748|148569|126220|196968|172256|201077|173597|136593|151585
Route 1 depot 0 9 7 5 2 3 10
Route 2 depot 0 13 15 16 19 17 14
Route 3 depot 0 11 8 6 4 1 0
Route 4 depot 0 12 18 20
