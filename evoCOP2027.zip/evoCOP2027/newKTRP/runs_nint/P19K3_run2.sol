# row P19K3  instance P-n19-k2  n 18  m 1  K 3  seed 9256
# metric nearest  return_weight 1
# objective 876.000000  latency_only 622.000000  valid 1
# cycles 1539267  cycle_segments 136192|137329|139929|138531|135834|150747|138867|138145|137386|149975|136332
Route 1 depot 0 5 1 6 7 15 16 2
Route 2 depot 0 0 9 11 13 10 3
Route 3 depot 0 17 4 12 14 8
