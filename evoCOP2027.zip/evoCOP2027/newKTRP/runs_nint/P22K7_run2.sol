# row P22K7  instance P-n22-k2  n 21  m 1  K 7  seed 9256
# metric nearest  return_weight 1
# objective 1012.000000  latency_only 611.000000  valid 1
# cycles 1068871  cycle_segments 100515|101493|101848|100097|100704|101202|94804|92036|92572|92217|91383
Route 1 depot 0 1 7 17 18 2
Route 2 depot 0 15
Route 3 depot 0 3 10
Route 4 depot 0 5
Route 5 depot 0 6 20 8 12
Route 6 depot 0 0 9 11 14
Route 7 depot 0 19 4 13 16
