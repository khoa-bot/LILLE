# row E101K14  instance E-n101-k8  n 100  m 1  K 14  seed 1337
# metric nearest  return_weight 1
# objective 4074.000000  latency_only 2900.000000  valid 1
# cycles 157201  cycle_segments 23873|13290|13220|12943|14215|12852|12844|12866|12846|13948|14304
Route 1 depot 0 5 95 98 58 92 84 60 15 85 37
Route 2 depot 0 11 79 67 28 23
Route 3 depot 0 12 96 86 41 42 14
Route 4 depot 0 17 82 7 81
Route 5 depot 0 25 53 54 24 38 3
Route 6 depot 0 26 68 0 69 29 31 89 62 9
Route 7 depot 0 27 75 76 2 78 77 33 34 70 64
Route 8 depot 0 30 87 61 10 18
Route 9 depot 0 52 39 20 72 71 73 74 55 22 66
Route 10 depot 0 49 32 80 8 50 19 65
Route 11 depot 0 51 6 47 46 35 48 63
Route 12 depot 0 57 1 56 40 21
Route 13 depot 0 88 59 4 83 16 44 45
Route 14 depot 0 93 94 91 97 36 99 90 43 13
