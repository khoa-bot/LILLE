# row E76K8  instance E-n76-k7  n 75  m 1  K 8  seed 25094
# metric nearest  return_weight 1
# objective 3454.000000  latency_only 2663.000000  valid 1
# cycles 284577  cycle_segments 34191|21070|28459|19862|22777|24819|20977|30345|24652|26774|30651
Route 1 depot 0 3 44 28 4 36 19 69 59 70 35 68 60
Route 2 depot 0 5 32 72 0 42 40 41 63 21
Route 3 depot 0 16 2 43 31 49 17 24 54
Route 4 depot 0 25 11 39 8 38 71 57 9 30
Route 5 depot 0 45 7 34 6 52 10 65 64 37
Route 6 depot 0 50 15 62 22 55 48 23
Route 7 depot 0 66 33 51 26 14 56 12 53 18 13 58
Route 8 depot 0 74 67 1 61 27 73 20 46 47 29
