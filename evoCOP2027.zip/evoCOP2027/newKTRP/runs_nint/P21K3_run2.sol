# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 9256
# metric nearest  return_weight 1
# objective 968.000000  latency_only 712.000000  valid 1
# cycles 1360091  cycle_segments 114581|119073|124279|123885|126532|128007|118992|125651|125891|126985|126215
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
