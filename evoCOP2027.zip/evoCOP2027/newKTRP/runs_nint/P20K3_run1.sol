# row P20K3  instance P-n20-k2  n 19  m 1  K 3  seed 1337
# metric nearest  return_weight 1
# objective 950.000000  latency_only 696.000000  valid 1
# cycles 1456566  cycle_segments 130752|132375|134173|132098|132344|133998|132907|132353|130605|133102|131859
Route 1 depot 0 5 1 7 16 17 2
Route 2 depot 0 0 9 11 14 10 3
Route 3 depot 0 18 4 13 15 8 12 6
