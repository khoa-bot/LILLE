# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 17175
# metric nearest  return_weight 1
# objective 1124.000000  latency_only 898.000000  valid 1
# cycles 1328086  cycle_segments 120466|120772|122522|120225|121081|120988|120153|120122|119983|120395|121379
Route 1 depot 0 5 18 4 13 15 8 12 6 1
Route 2 depot 0 0 9 3 10 14 11 2 7 16 17
