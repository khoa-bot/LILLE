# row P20K3  instance P-n20-k2  n 19  m 1  K 3  seed 17175
# metric nearest  return_weight 1
# objective 950.000000  latency_only 696.000000  valid 1
# cycles 1582248  cycle_segments 141637|143835|144051|140580|141379|145263|142717|141303|155984|142990|142509
Route 1 depot 0 5 1 7 16 17 2
Route 2 depot 0 0 9 11 14 10 3
Route 3 depot 0 18 4 13 15 8 12 6
