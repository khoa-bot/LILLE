# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 9256
# metric nearest  return_weight 1
# objective 788.000000  latency_only 406.000000  valid 1
# cycles 1680531  cycle_segments 146527|147776|162218|169511|154320|183027|135102|156955|133763|158400|132932
Route 1 depot 0 0
Route 2 depot 0 3 10
Route 3 depot 0 4 13
Route 4 depot 0 1 7 2
Route 5 depot 0 9 11 14
Route 6 depot 0 6 12 8
Route 7 depot 0 5
