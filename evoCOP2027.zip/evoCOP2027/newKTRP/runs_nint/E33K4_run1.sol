# row E33K4  instance E-n33-k4  n 32  m 1  K 4  seed 1337
# metric nearest  return_weight 1
# objective 3706.000000  latency_only 2913.000000  valid 1
# cycles 669721  cycle_segments 65796|61009|76768|58535|65500|60412|56095|55246|59892|55331|55137
Route 1 depot 0 2 4 5 6 7 8 9 17 18 20 19 21 22 23
Route 2 depot 0 3
Route 3 depot 0 1 11 10 31 12 0 29
Route 4 depot 0 30 13 14 16 24 25 26 27 15 28
