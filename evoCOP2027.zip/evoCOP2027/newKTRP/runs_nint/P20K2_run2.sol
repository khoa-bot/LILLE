# row P20K2  instance P-n20-k2  n 19  m 1  K 2  seed 9256
# metric nearest  return_weight 1
# objective 1124.000000  latency_only 898.000000  valid 1
# cycles 1226650  cycle_segments 111127|107683|112053|112293|110525|110362|112199|111738|110599|111496|116575
Route 1 depot 0 5 18 4 13 15 8 12 6 1
Route 2 depot 0 0 9 3 10 14 11 2 7 16 17
