# row E76K7  instance E-n76-k7  n 75  m 1  K 7  seed 33013
# metric nearest  return_weight 1
# objective 3677.000000  latency_only 2914.000000  valid 1
# cycles 290851  cycle_segments 23012|19954|19945|21405|21679|53512|19172|25168|23485|25558|37961
Route 1 depot 0 3 44 28 4 36 19 69 59 70 35 68 60
Route 2 depot 0 5 32 72 0 42 41 40 55 22 62
Route 3 depot 0 25 11 39 8 38 71 57 9 30 24 54
Route 4 depot 0 16 50 2 43 31 49 17 23 48 15
Route 5 depot 0 66 45 7 34 6 52 10 65 64 37
Route 6 depot 0 33 51 26 14 56 12 53 18 13 58
Route 7 depot 0 74 67 1 29 47 46 20 73 27 61 21 63
