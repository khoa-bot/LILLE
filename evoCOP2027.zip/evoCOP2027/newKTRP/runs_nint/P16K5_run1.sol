# row P16K5  instance P-n16-k8  n 15  m 1  K 5  seed 1337
# metric nearest  return_weight 1
# objective 736.000000  latency_only 406.000000  valid 1
# cycles 2072384  cycle_segments 176587|181052|180223|178460|185837|188571|208448|192888|192318|191565|196435
Route 1 depot 0 0 9 11 14
Route 2 depot 0 5 6 12 8
Route 3 depot 0 3 10
Route 4 depot 0 1 7 2
Route 5 depot 0 4 13
