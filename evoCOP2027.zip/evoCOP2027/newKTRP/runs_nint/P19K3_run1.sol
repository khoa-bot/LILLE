# row P19K3  instance P-n19-k2  n 18  m 1  K 3  seed 1337
# metric nearest  return_weight 1
# objective 876.000000  latency_only 622.000000  valid 1
# cycles 1518928  cycle_segments 150592|139259|139386|132430|133280|139262|139431|136496|135751|136772|136269
Route 1 depot 0 5 1 6 7 15 16 2
Route 2 depot 0 0 9 11 13 10 3
Route 3 depot 0 17 4 12 14 8
