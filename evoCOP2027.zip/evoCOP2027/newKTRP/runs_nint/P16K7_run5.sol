# row P16K7  instance P-n16-k8  n 15  m 1  K 7  seed 33013
# metric nearest  return_weight 1
# objective 788.000000  latency_only 406.000000  valid 1
# cycles 1797031  cycle_segments 141959|159396|172260|194721|186001|197498|169872|142645|144355|143623|144701
Route 1 depot 0 3 10
Route 2 depot 0 0
Route 3 depot 0 1 7 2
Route 4 depot 0 9 11 14
Route 5 depot 0 5
Route 6 depot 0 6 12 8
Route 7 depot 0 4 13
