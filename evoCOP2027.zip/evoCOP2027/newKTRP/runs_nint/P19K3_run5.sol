# row P19K3  instance P-n19-k2  n 18  m 1  K 3  seed 33013
# metric nearest  return_weight 1
# objective 876.000000  latency_only 622.000000  valid 1
# cycles 1621239  cycle_segments 144680|146058|147004|143700|143393|159491|144603|143800|144982|157577|145951
Route 1 depot 0 5 1 6 7 15 16 2
Route 2 depot 0 0 9 11 13 10 3
Route 3 depot 0 17 4 12 14 8
