# row P21K3  instance P-n21-k2  n 20  m 1  K 3  seed 17175
# metric nearest  return_weight 1
# objective 968.000000  latency_only 712.000000  valid 1
# cycles 1385286  cycle_segments 126239|127100|126397|124878|119272|128021|127036|126865|126124|126352|127002
Route 1 depot 0 15 1 12 7 17 18 2
Route 2 depot 0 5 19 4 13 16 8 6
Route 3 depot 0 0 9 11 14 10 3
