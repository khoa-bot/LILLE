# row P16K5  instance P-n16-k8  n 15  m 1  K 5  seed 25094
# metric nearest  return_weight 1
# objective 736.000000  latency_only 408.000000  valid 1
# cycles 2053801  cycle_segments 214884|198834|178875|200718|182984|181233|177702|178130|180186|180305|179950
Route 1 depot 0 0 9 11 14
Route 2 depot 0 1 7 2
Route 3 depot 0 3 10
Route 4 depot 0 5 6 8 12
Route 5 depot 0 4 13
