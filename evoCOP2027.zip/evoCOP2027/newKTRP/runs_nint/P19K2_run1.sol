# row P19K2  instance P-n19-k2  n 18  m 1  K 2  seed 1337
# metric nearest  return_weight 1
# objective 1027.000000  latency_only 817.000000  valid 1
# cycles 1266083  cycle_segments 120039|115180|117031|113314|114600|113781|115134|113965|115570|113960|113509
Route 1 depot 0 5 1 6 8 14 12 4 17
Route 2 depot 0 0 9 3 10 13 11 2 7 15 16
