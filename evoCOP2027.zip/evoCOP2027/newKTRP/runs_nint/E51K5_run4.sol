# row E51K5  instance E-n51-k5  n 50  m 1  K 5  seed 25094
# metric nearest  return_weight 1
# objective 2773.000000  latency_only 2211.000000  valid 1
# cycles 432237  cycle_segments 80023|35476|34821|32951|32636|32104|39988|32248|40804|38608|32578
Route 1 depot 0 26 5 47 7 25 6 22 23 42
Route 2 depot 0 31 0 21 30 27 2 35 34 19 1
Route 3 depot 0 45 10 37 8 49 15 28 20 33 29 38
Route 4 depot 0 11 16 36 43 14 44 32 9 48 4
Route 5 depot 0 46 3 17 13 24 12 40 18 39 41
