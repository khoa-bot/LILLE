# newKTRP — KTRPGAenhanced with the paper's dEAX and per-segment cycle counts

Derived from `../KTRPGAenhanced`. **Two changes, nothing else.** The claim is
mechanical, not editorial: an inverse patch reverses both changes and the result
is **byte-identical** to `../KTRPGAenhanced/main_ga_ktrp_ceill.cpp`.

| file | differs from `main_ga_ktrp_ceill.cpp` only in |
|---|---|
| `main_ga_ktrp_ceill.cpp` | — (the base; all logic lives here) |
| `main_ga_ktrp_nint.cpp` | `METRIC`, `CSV_PATH`, `RUN_DIR` |
| `exact_ktrp.cpp`, `postcheck_ktrp.py` | unchanged copies |

The ceil↔nint diff is the same three lines, in the same places, as in
`../KTRPGAenhanced`.

    bash run.sh          # builds both, creates runs_ceil/ runs_nint/, runs them
    # or, by hand:
    g++ -std=c++17 -O3 -o main_ga_ktrp_ceill main_ga_ktrp_ceill.cpp
    mkdir -p runs_ceil && ./main_ga_ktrp_ceill

---

## Change 1 — per-segment cycle counts (reporting only)

`RunStats::cycleSegments` records how many ROAR cycles ran in each stretch
between perturbation kicks. Entry *i* is the count completed **before kick
*i*+1 fired**; the last entry is the stretch after the final kick. So

    cycleSegments.size() == perturbations + 1
    sum(cycleSegments)   == cycles

both hold on every run, always. Reported in three places:

* console, after the total: `cycles 1996780  cycseg [176683|176986|...|177777]`
* a new CSV column **`CycleSegments`**, immediately after `Cycles`, pipe-separated
  so the whole list sits in one field
* the `.sol` dump, as a new `#` header line: `# cycles N  cycle_segments a|b|c`

Nothing in the search reads this back — no branch, no RNG draw, no allocation
inside the hot loop — so a run's trajectory is bit-for-bit what it was before.
The `.sol` field is a `#` comment, which both the C++ round-trip re-coster and
`postcheck_ktrp.py` skip, so neither verifier is affected.

## Change 2 — dEAX is now the paper's crossover, literally

The previous build partitioned the **undirected** symmetric difference into
AB-sequences and recovered orientation afterwards by reading each route both
ways and keeping the cheaper one. That is gone. dEAX is now the **directed**
construction of Zou, Hao & Wu (IEEE TEVC 2024) §III-B, step by step:

| paper, §III-B | here |
|---|---|
| `G_AB = (E_A ∪ E_B) \ (E_A ∩ E_B)` | step 1, over **directed arcs** |
| partition into AB-cycles: random start node, random incident edge, then A- and B-edges alternately linked **"with different directions"** until a cycle closes; remove it; repeat until `G_AB` is empty | step 2 — the walk carries `(tag, dir)` and **both flip every step**, so at each node of a cycle the two incident arcs are both heads or both tails |
| E-set by the **block strategy**: one random AB-cycle plus every AB-cycle sharing ≥1 node with it | step 3 |
| intermediate `= E_A \ (E-set ∩ E_A) ∪ (E-set ∩ E_B)`, `E_A` the base | step 4 |
| sub-tours spliced into the route with the **fewest nodes** by 2-opt\*: delete one arc from each, add two arcs **with the same directions as the deleted ones**, every other direction unchanged, all combinations tried, minimum (added − deleted) taken, repeat until none left | step 6 |
| multiple depots: treat **all depots as one node** while walking; start from the arcs leaving the depot and, on reaching a node linked to a *different* depot, delete that arc and close the route at the depot it started from | `DEPV = inst.n`; a route is opened by the real depot of its departing arc and closed there (single-depot here, but the code path is the shared one) |

Three pieces of the old construction are therefore **deleted**, not disabled:

* `orientRoute()` — the post-hoc cheaper-reading pass. Reversal is exactly what
  the "d" in dEAX exists to avoid; the offspring now keeps the directions the
  construction produced.
* the reversed 2-opt\* variant (`bRev`) — the paper keeps the directions of the
  two deleted arcs.
* the undirected multiset bookkeeping (`GAOcc` occurrence lists inside dEAX) — a
  directed arc occurs at most once per parent, so plain sets suffice.

### Why the directed form is also the safe one

In any solution a customer has exactly one predecessor and one successor, and
the depot has *K* of each, so in `G_AB`

    in_A(v) = in_B(v)   and   out_A(v) = out_B(v)   for every v

— an arc survives the intersection in A exactly when its counterpart survives in
B. Hence the alternating walk can always continue, and `E_A XOR (a union of
complete AB-cycles)` preserves every in- and out-degree exactly. The
intermediate solution is therefore **always** a disjoint union of *K* depot
cycles plus zero or more customer-only sub-tours. The "open walk" and "broken
depot degree" failures the undirected version had to guard against cannot arise.
Measured: **0 infeasible offspring** over ~20 000 crossovers in the smoke run
below, versus a construction that previously needed those escape hatches.

Every remaining failure path still returns parent A, so a crossover that cannot
complete degrades to "no crossover this time".

### The one configuration constant added

    constexpr bool GA_ESET_DEPOT_IS_SHARED_NODE = true;   // section 4b

The paper says the E-set takes "the AB-cycles that **share at least one node**
with the chosen cycle". `true` is that sentence read literally — the collapsed
depot counts as a shared node like any other — and is the default. `false`
excludes the depot from the sharing test only, and is there because the depot
sits in nearly every AB-cycle, so counting it tends to pull the whole partition
into the E-set and push the offspring towards parent B. It is an ablation knob;
it changes nothing else.

### What was deliberately *not* touched

The archive and its admission rule `Dis(S_a,S_b) = |E_a| − |E_a ∩ E_b| > τ·|E|`
still use the **undirected** edge multiset (`gaOccurrences` / `edgeMultiset`).
That is the population surrogate, not the crossover, so it is out of scope here
and is left exactly as it was. Same for the ejection-chain mutation,
`GA_EVERY_CYCLES`, the install policy, ROAR's ruin-and-recreate, the four
restricted neighbourhoods, the delta algebra, the objective and its `Ceil` /
`RETURN_WEIGHT = 1` calibration, the perturbation, the epoch/patience
termination, the readers, the reference tables and every hyperparameter.

---

## Verification performed

1. **Inverse patch.** Reversing both changes reproduces
   `../KTRPGAenhanced/main_ga_ktrp_ceill.cpp` byte-for-byte.
2. **Variant structure.** The `ceill → nint` diff here is identical, modulo line
   numbers, to the one in `../KTRPGAenhanced`.
3. **Compilation.** Every file builds clean under
   `g++ -std=c++17 -O3 -Wall -Wextra` — no warnings.
4. **Segment arithmetic.** Over every run of a full 20-row smoke benchmark,
   `sum(CycleSegments) == Cycles` and `len(CycleSegments) == Perturbations + 1`.
5. **Crossover health.** `0 infeasible`, `0 worse` offspring; fall-backs at the
   same rate as the old build (identical parents, not a construction failure).
6. **No quality regression.** 20 rows, one seed, a 2.0 s budget (1/50th of the
   real one) — identical objective on 19 of 20 rows, +2 on `E76K7`; mean gap
   against the paper's reference −1.710 % (new) vs −1.713 % (old).

Point 6 is a smoke test, not a result. Run the real budget before quoting
anything.
