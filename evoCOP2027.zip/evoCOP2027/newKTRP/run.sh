#!/bin/bash
set -e # Stop execution if any command fails

# Compiler and optimization flags
CXX=g++
CXXFLAGS="-O3 -std=c++17"

# List of source files without extension
PROGRAMS=(
    "main_ga_ktrp_ceil"
    "main_ga_ktrp_nint"
    "main_ga_ktrp_ceil_only2opt"
    "main_ga_ktrp_nint_only2opt"
)

echo "================ Compiling Programs ================"
for prog in "${PROGRAMS[@]}"; do
    echo "Compiling ${prog}.cpp with -O3..."
    $CXX $CXXFLAGS "${prog}.cpp" -o "${prog}"
done

mkdir -p runs_ceil runs_nint

echo ""
echo "================ Running Programs ================"
for prog in "${PROGRAMS[@]}"; do
    echo "----------------------------------------"
    echo "Executing: ./${prog}"
    echo "----------------------------------------"
    ./"${prog}"
    echo ""
done

echo "All executions finished successfully."
