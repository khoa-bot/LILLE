// ############################################################################
//  DERIVED BUILD -- two changes over the KTRPGAenhanced counterpart, nothing else.
//
//  (1) REPORTING ONLY.  PER-SEGMENT CYCLE COUNTS.
//      RunStats::cycleSegments records how many ROAR cycles ran in each stretch
//      between perturbation kicks: entry i is the count before kick i+1 fired,
//      and the last entry is the stretch after the final kick.  So
//          cycleSegments.size() == perturbations + 1
//          sum(cycleSegments)   == cycles
//      always.  It is reported on the per-run console line ("cycseg [...]"), in
//      a new CSV column `CycleSegments` (pipe-separated, one field), and in the
//      per-run .sol dump.  Nothing in the search reads it back, so the search
//      trajectory is bit-for-bit what it was before this change.
//
//  (2) ALGORITHMIC.  dEAX IS NOW THE PAPER'S CROSSOVER, LITERALLY.
//      The previous build partitioned the UNDIRECTED symmetric difference into
//      AB-sequences and recovered orientation afterwards by reading each route
//      both ways.  That is gone.  dEAX is now the DIRECTED construction of
//      Zou, Hao & Wu, IEEE TEVC 2024, Section III-B, step by step: a directed
//      joint graph, an alternating walk whose A- and B-arcs are linked "with
//      different directions", the block-strategy E-set, the directed XOR with
//      E_A as the base, and direction-preserving 2-opt* splicing of sub-tours
//      into the route with the fewest nodes.  See the dEAX header comment for
//      the step-by-step correspondence.  Consequences:
//        - orientRoute() is gone; the offspring keeps the directions the
//          construction produced, which is what "d" in dEAX means.
//        - the reversed 2-opt* variant is gone; the paper keeps the directions
//          of the two deleted arcs.
//        - the undirected multiset bookkeeping is gone; a directed arc occurs
//          at most once per parent.
//
//      Everything around the crossover is untouched: the archive and its
//      admission rule, the ejection-chain mutation, GA_EVERY_CYCLES, the
//      install policy, ROAR's ruin-and-recreate, the four restricted
//      neighbourhoods, the delta algebra, the objective, the perturbation, the
//      termination rule, the readers, the reference tables and every
//      hyperparameter.
// ############################################################################



#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Option enumerations (declared first so the configuration block can use them)
// ---------------------------------------------------------------------------

// Travel-time rule.  Raw (unrounded Euclidean) is what reproduces the
// published MDk-TRP values; the others are the TSPLIB rules kept from ROAR.
enum class Rounding { Raw, Nearest, Floor, Ceil };

// Fleet size source: Bruni et al. Tables 1 and 5 (Standard) or 6 and 7 (Reduced).
enum class FleetSetting { Standard, Reduced };

// Nearest-neighbour seeding sweep order.
enum class SeedMode { RoundRobin, Sequential };

// Depot siting.  Only the TOTAL fleet size k is constrained by the MDk-TRP
// model, so how many vehicles sit at each depot is a decision variable.
enum class DepotMode { Relocate, Fixed };

// The four restricted neighbourhoods.
enum class Neighborhood { Restricted2Opt, RestrictedSwap, Restricted2OrOpt, Restricted3OrOpt };

// One line of the benchmark plan.
//
//  There is no fleet "setting" for the k-TRP benchmark: the paper states K per
//  row, and that K has nothing to do with the k in the CVRPLIB file name (which
//  is the minimum truck count for the CAPACITATED instance and is irrelevant
//  once the capacity constraint is dropped).  Several rows therefore share one
//  instance file at different K -- E-n76 alone is used five times -- so the
//  reference value travels with the ROW, not with the instance name.
struct BenchEntry {
    const char* file;        // file name inside cfg::DATASET_DIR
    const char* label;       // the paper's row name, e.g. "E76K10"
    int         K;           // number of repairmen = number of routes
    double      ref;         // Co-MARL-ATS best value (paper, Table 4)
    double      prevBest;    // the paper's "Best Known" column, -1 if none
};

// ===========================================================================
// ===========================================================================
//                            C O N F I G U R A T I O N
//
//   Everything tunable lives here.  Edit, rebuild, run.  Nothing is read from
//   the command line.
// ===========================================================================
// ===========================================================================

namespace cfg {

// ---------------------------------------------------------------------------
// 1.  DATASETS  --  the 20 rows of Jmal, Haddar & Chabchoub (EvoCOP 2026)
//
//   DATASET_DIR is prefixed to every file name.  The CVRPLIB P and E sets live
//   one level up, in ../P and ../E.
//
//   INSTANCE MAPPING.  The paper names rows <set><n><K>, where n is DIMENSION
//   (depot included) and K is the paper's repairman count.  Resolving them:
//
//     P16  -> P/P-n16-k8    (15 customers)   K = 5, 7
//     P19  -> P/P-n19-k2    (18 customers)   K = 2, 3
//     P20  -> P/P-n20-k2    (19 customers)   K = 2, 3
//     P21  -> P/P-n21-k2    (20 customers)   K = 3
//     P22  -> P/P-n22-k2    (21 customers)   K = 7
//     P23  -> P/P-n23-k8    (22 customers)   K = 7
//     E22  -> E/E-n22-k4    (21 customers)   K = 4
//     E30  -> E/E-n30-k3    (29 customers)   K = 4
//     E33  -> E/E-n33-k4    (32 customers)   K = 4
//     E51  -> E/E-n51-k5    (50 customers)   K = 5
//     E76  -> E/E-n76-k7    (75 customers)   K = 7, 8, 10, 14, 15
//     E101 -> E/E-n101-k8   (100 customers)  K = 8, 14
//
//   Two of these need a note.
//
//   (a) E-n76-k7, -k8, -k10 and -k14 are BYTE-IDENTICAL in their coordinate
//       sections (verified by hashing the NODE_COORD_SECTION of each), as are
//       E-n101-k8 and E-n101-k14.  They differ only in CAPACITY, which this
//       problem does not have.  So each family is ONE instance, entered once
//       and run at every K the paper reports -- and E76K15, which has no
//       CVRPLIB file of its own, is simply E-n76 at K = 15.
//
//   (b) "P22K7" is ambiguous in the paper: two P-n22 files exist, and
//       P-n22-k8's coordinates are identical to E-n22-k4's, which the paper
//       already lists separately as E22K4.  P-n22-k2 is used here, which gives
//       one distinct instance per n across the P set and keeps P22K7 a
//       different instance from E22K4.
//
//   REFERENCE VALUES.  `ref` is the paper's own Co-MARL-ATS best value
//   (Table 4), which is what Gap% is measured against.  `prevBest` carries the
//   paper's "Best Known" column (the QPSO / k-means / CLARANS record it was
//   compared to) for context only; it does not enter any gap.
// ---------------------------------------------------------------------------

constexpr const char* DATASET_DIR = "..";

constexpr BenchEntry DATASETS[] = {
    //  file                label      K       ref   prevBest
    // ---- small instances (paper Table 4, upper block) --------------------
    { "P/P-n16-k8.vrp",    "P16K5",    5,     785.0,    785.0 },
    { "P/P-n16-k8.vrp",    "P16K7",    7,     847.0,    847.0 },
    { "P/P-n19-k2.vrp",    "P19K3",    3,     933.0,    933.0 },
    { "P/P-n19-k2.vrp",    "P19K2",    2,    1110.0,   1110.0 },
    { "P/P-n20-k2.vrp",    "P20K2",    2,    1211.0,   1211.0 },
    { "P/P-n20-k2.vrp",    "P20K3",    3,    1015.0,   1015.0 },
    { "P/P-n21-k2.vrp",    "P21K3",    3,    1049.0,   1049.0 },
    { "E/E-n22-k4.vrp",    "E22K4",    4,    1269.0,   1269.0 },
    { "P/P-n22-k2.vrp",    "P22K7",    7,    1105.0,   1105.0 },
    { "P/P-n23-k8.vrp",    "P23K7",    7,    1098.0,   1098.0 },
    // ---- large instances (paper Table 4, lower block) --------------------
    //      ref < prevBest on eight of these: the paper's new BKS claims.
    { "E/E-n30-k3.vrp",    "E30K4",    4,    2329.0,   2610.0 },
    { "E/E-n33-k4.vrp",    "E33K4",    4,    3882.0,   3897.0 },
    { "E/E-n51-k5.vrp",    "E51K5",    5,    2998.0,   2998.0 },
    { "E/E-n76-k7.vrp",    "E76K7",    7,    4263.0,   4500.0 },
    { "E/E-n76-k7.vrp",    "E76K8",    8,    3959.0,   4473.0 },
    { "E/E-n76-k7.vrp",    "E76K10",  10,    3668.0,   4058.0 },
    { "E/E-n76-k7.vrp",    "E76K14",  14,    3482.0,   3586.0 },
    { "E/E-n76-k7.vrp",    "E76K15",  15,    3420.0,   3511.0 },
    { "E/E-n101-k8.vrp",   "E101K8",   8,    4511.0,   4511.0 },
    { "E/E-n101-k8.vrp",   "E101K14", 14,    4753.0,   5048.0 },
};

// ---------------------------------------------------------------------------
// 2.  SEARCH HYPERPARAMETERS
// ---------------------------------------------------------------------------

// Ruin.  N_remove ~ U{1, N_max} with
//     N_max = clamp( max(MIN_REMOVE, ALPHA*n), 1, min(n-1, REMOVAL_CAP) ).
constexpr double ALPHA       = 0.5;   // destruction level            (ROAR: 0.2)
constexpr int    REMOVAL_CAP = 300;   // C_limit                      (ROAR: 300)
constexpr int    MIN_REMOVE  = 5;     // floor on the removal budget; see note
                                      // in roarSearch().  Binds only when
                                      // ALPHA*n < MIN_REMOVE, i.e. n < 25 here.

// Termination.  A run stops at the wall-clock budget, or after PATIENCE
// consecutive epochs without a strict improvement, whichever comes first.
constexpr int    PATIENCE      = 10;    // non-improving epochs        (ROAR: 10)
constexpr double EPOCH_SECONDS = -1.0;  // <= 0 -> ROAR E(N), eq. (10)
constexpr double TIME_BUDGET   = -1.0;  // <= 0 -> ROAR T(N), eq. (11) (100 s here)

// ---------------------------------------------------------------------------
// 2b. PERTURBATION  (the one addition over newROAR+)
//
//   Convergence -- PATIENCE consecutive epochs without a strict improvement --
//   no longer ends the run while perturbation budget is left.  It fires a
//   kick instead:  PERTURB_T blind random 2-opt moves inside every tour,
//   then PERTURB_K blind random cross-exchanges (tail swaps) between tours.
//   Patience and the epoch baseline are reset and the ROAR cycle resumes.
//   The run ends on the (PERTURB_V + 1)-th convergence, or at the wall-clock
//   budget above, whichever comes first.
//
//   PERTURB_V = 0 reproduces newROAR+ exactly.
// ---------------------------------------------------------------------------

constexpr int PERTURB_T = 5;   // t -- random 2-opt moves applied to EACH tour
constexpr int PERTURB_K = 4;   // k -- random cross-exchanges AMONG the tours.
                               //      Spelled PERTURB_K because plain k already
                               //      denotes the fleet size in the MDk-TRP.
constexpr int PERTURB_V = 10;   // v -- perturbations allowed per run; the run
                               //      stops at the convergence that follows
                               //      the v-th kick.

// ---------------------------------------------------------------------------
// 4b.  THE IN-SEARCH CROSSOVER LAYER
//
//   A population layer in the style of TIEA (Zou, Hao & Wu, IEEE TEVC 2024),
//   fired INSIDE the ROAR search rather than around it.
//
//   The archive lives for the WHOLE run, fed by every solution the search
//   accepts.  Every GA_EVERY_CYCLES ruin-and-recreate cycles the incumbent is
//   crossed by dEAX with a random archive member; the offspring is mutated by
//   an ejection chain, repaired, and -- by default -- INSTALLED AS THE CURRENT
//   SOLUTION whether or not it is better.  That makes the crossover a third
//   kind of kick: where perturb() moves the incumbent blindly, this moves it
//   toward material that worked elsewhere in the run.  The global best is
//   tracked separately and can never be lost, exactly as with a perturbation.
//
//   There are no generations, no budget to split and no reseeding, so this
//   build uses ONE run, ONE budget and PERTURB_V kicks -- it is directly
//   comparable to ROARMDkTRP_perturbation/main_pr.cpp with identical settings.
//
//   GA_EVERY_CYCLES = 0 or GA_ARCHIVE_U = 0 reduces this build EXACTLY to that
//   original.
//
//   MEASURED on the single-depot CCVRP sibling (GACCVRP/main_manyga.cpp), at
//   identical budget, kicks and seeds: mean gap 0.69% -> 0.15% over CMT3/5/11.
//   Small sample, but like-for-like.
//
//   SIZING g.  One crossover costs about a local-search sweep -- cheap next to
//   GA_EVERY_CYCLES cycles, but it discards the incumbent's current line of
//   descent.  A few thousand cycles fires it tens to hundreds of times per run;
//   a few hundred will interfere with the loop's own progress.
// ---------------------------------------------------------------------------

// g -- fire the crossover every this many ROAR cycles.  0 disables it.
constexpr long long GA_EVERY_CYCLES = 1000;

// u -- how many distinct solutions the archive keeps.  NOT reset during the
// run: it holds the u best distinct solutions seen so far.  0 disables.
constexpr int    GA_ARCHIVE_U   = 2;

// A candidate joins the archive only if its distance -- the number of
// non-common edges -- from EVERY member exceeds GA_DIVERSITY_TAU * |E|.
constexpr double GA_DIVERSITY_TAU = 0.1;

// Ejection-chain mutation on the offspring.
constexpr double GA_MUTATION_P    = 0.3;   // TIEA's m_p
constexpr int    GA_MUTATION_LEN  = 2;     // TIEA's m_l

// E-set block strategy (paper, Section III-B): "randomly selecting an
// AB-cycle, and then selecting the AB-cycles that share at least one node with
// the chosen cycle".
//
// TRUE is that sentence read LITERALLY: the collapsed depot counts as a shared
// node like any other, which is the paper's own wording and the default here.
// FALSE excludes it from the sharing test only.  Worth an ablation rather than
// a silent choice: the depot sits in nearly every AB-cycle, so counting it
// tends to pull the whole partition into the E-set, which pushes the offspring
// towards parent B.  It changes NOTHING else about the construction.
constexpr bool   GA_ESET_DEPOT_IS_SHARED_NODE = true;

// TRUE  : parent A is the global best found so far (intensifying).
// FALSE : parent A is the current incumbent -- more diversifying.
constexpr bool   GA_PARENT_A_IS_BEST = true;

// TRUE  : install the offspring only when it beats the current incumbent.
// FALSE : install it unconditionally, like a perturbation kick.  Default.
constexpr bool   GA_ONLY_IF_BETTER = false;

// Should an installed offspring touch the epoch/patience machinery the way a
// perturbation does (stale = 0, epochBase = cur.cost)?
//
// TRUE looks natural but at small GA_EVERY_CYCLES it SUPPRESSES perturb()
// ENTIRELY.  Either reset does it: clearing `stale` outruns PATIENCE, and
// re-basing `epochBase` to the post-crossover cost -- usually HIGHER, since the
// offspring is installed unconditionally -- makes the next epoch read as an
// improvement, which clears `stale` anyway.  Measured on the CCVRP sibling:
// pert 0/10 for a whole run, the crossover silently becoming the only
// diversification mechanism.  FALSE (default) leaves the epoch logic alone so
// both fire on their own schedules.
constexpr bool   GA_RESET_PATIENCE = false;

// Repetition.  Run r uses seed RNG_SEED + r*SEED_STRIDE.
constexpr int      RUNS_PER_INSTANCE = 5;
constexpr uint64_t RNG_SEED          = 1337;
constexpr uint64_t SEED_STRIDE       = 7919;

// ---------------------------------------------------------------------------
// 3.  RESTRICTED NEIGHBOURHOODS
//
//   One enabled neighbourhood is drawn uniformly at random after each
//   reinsertion.  Disable any of them to ablate it; disabling all four reduces
//   the method to plain LNS with greedy insertion and no local search.
// ---------------------------------------------------------------------------

constexpr bool USE_RESTRICTED_2OPT    = true;   // N1  -- delta (1)
constexpr bool USE_RESTRICTED_SWAP    = true;   // N2  -- delta (2)
constexpr bool USE_RESTRICTED_2OROPT  = true;   // N3  -- delta (0b), L = 2
constexpr bool USE_RESTRICTED_3OROPT  = true;   // N4  -- delta (0b), L = 3

// Try the reversed orientation of the block in N3 / N4 as well as the forward
// one (Or-opt with inversion).  Same O(p), strictly larger neighbourhood.
constexpr bool OROPT_TRY_REVERSED = true;

// ---------------------------------------------------------------------------
// 4.  PROBLEM / MODEL OPTIONS
// ---------------------------------------------------------------------------

// The paper rounds its travel-time matrix UP.  This is not a guess: with Ceil
// an exact DP reproduces the paper's P20K2 = 1211, P20K3 = 1015 and
// P19K3 = 933 exactly, while Nearest gives 1124, Floor 1090 and Raw 1132.81
// on P20K2.  Do not change it without redoing that calibration.
constexpr Rounding METRIC = Rounding::Nearest;

// Coefficient of the closed-tour length in the objective; see the OBJECTIVE
// block further down.  1.0 = the paper's eq. (1) (return arc charged);
// 0.0 = the depot-exclusive objective used by the other builds here.
constexpr double RETURN_WEIGHT = 1.0;

// Relocate: an idle vehicle may be re-housed, and a route that just changed is
//   re-seated at its optimal depot.  This is the MDk-TRP's own freedom and is
//   needed for completeness -- under Fixed, the proven optimum of 10x4-3 is
//   unreachable because it houses 3 of 5 vehicles at one depot.
// Fixed: the vehicle-to-depot allocation from the nearest-depot clustering is
//   frozen for the whole run.
constexpr DepotMode DEPOT_MODE = DepotMode::Relocate;

// Keep the nearest-depot clustering filter active during recreate as well as
// during seeding.  Lossy (exact DP puts the constrained optimum 6-41 % above
// the unconstrained one on the 10-customer instances); off by default.
constexpr bool STRICT_CLUSTER = false;

constexpr SeedMode SEED_MODE = SeedMode::RoundRobin;

// ---------------------------------------------------------------------------
// 5.  OUTPUT / ENGINEERING
// ---------------------------------------------------------------------------

constexpr bool VERIFY_DELTAS = false;  // recompute every applied move from
                                       // scratch and report the largest error.
                                       // Slow; turn on to audit the algebra.
constexpr bool PRINT_ROUTES  = false;  // dump the routes of the best run
constexpr bool QUIET         = false;  // summary table only
constexpr bool WRITE_CSV     = true;
constexpr const char* CSV_PATH = "results_GA_KTRP_nint.csv";

// Every run's solution is written to RUN_DIR/<row>_run<i>.sol and immediately
// read back and re-costed from the file, so the reported number is backed by an
// artefact on disk rather than only by in-process state.  Create the directory
// before running; if it is missing the dump is silently skipped.
constexpr bool        DUMP_RUNS = true;
constexpr const char* RUN_DIR   = "runs_nint";

// Materialise a distance matrix when it fits in this budget; otherwise edges
// are computed on the fly, preserving ROAR's O(1) auxiliary space at scale.
constexpr bool   USE_DISTANCE_MATRIX = true;
constexpr size_t MATRIX_BUDGET_BYTES = 256ull * 1024 * 1024;

}  // namespace cfg

// ===========================================================================
// ===========================================================================
//                      END OF CONFIGURATION -- code below
// ===========================================================================
// ===========================================================================

namespace roar {

// ---------------------------------------------------------------------------
// Basics
// ---------------------------------------------------------------------------

static constexpr double INF = std::numeric_limits<double>::infinity();
static constexpr double ACC = 1e-7;   // strict-improvement threshold

using Clock = std::chrono::steady_clock;
using TimePoint = Clock::time_point;

static inline double secondsSince(const TimePoint& t0) {
    return std::chrono::duration<double>(Clock::now() - t0).count();
}

static const char* roundingName(Rounding r) {
    switch (r) {
        case Rounding::Nearest: return "nearest";
        case Rounding::Floor:   return "floor";
        case Rounding::Ceil:    return "ceil";
        default:                return "raw";
    }
}

static const char* neighborhoodName(Neighborhood nb) {
    switch (nb) {
        case Neighborhood::Restricted2Opt:   return "2opt";
        case Neighborhood::RestrictedSwap:   return "swap";
        case Neighborhood::Restricted2OrOpt: return "2oropt";
        default:                             return "3oropt";
    }
}

// ---------------------------------------------------------------------------
// Instance
//
// TWO plain-text layouts are accepted; the reader detects which by counting
// the tokens on the first line, so no configuration is needed.
//
// (A) Lalla-Ruiz / Voss MD(C)CVRP  -- the lr set.  First line holds ONE token.
//
//      n                   number of customers
//      m                   number of depots
//      Q                   vehicle capacity   (IGNORED: MDk-TRP is uncapacitated)
//      <blank>
//      x y   x (n+m)       customers 0..n-1 first, then depots n..n+m-1
//      <blank>
//      d     x (n+m)       demands (depots 0); IGNORED, tolerated if absent
//
// (B) Cordeau MDVRP -- the p and pr sets in ../dat.  First line holds FOUR
//     tokens.  This is the format the MDk-TRP paper's p/pr tables are built on.
//
//      type m n t          type = 2 (MDVRP);  m = vehicles PER DEPOT;
//                          n = customers;  t = DEPOTS  <- the depot count is
//                          the FOURTH field, not the second
//      D Q   x t           max route duration / vehicle capacity per depot
//                          (IGNORED: MDk-TRP is uncapacitated and untimed)
//      i x y d q f a <list...>   x n      customer lines
//      i x y d q f a <list...>   x t      depot lines, same leading fields
//
//     Three things make (B) need its own, LINE-ORIENTED reader:
//
//       * customer lines end in a variable-length list of visit-combination
//         codes, so a flat whitespace token stream -- which is all layout (A)
//         needs -- would run straight past the line boundary and silently
//         produce garbage.  Each node line is therefore parsed on its own,
//         taking only the 2nd and 3rd fields (x, y) and discarding the rest;
//       * the service duration d is non-zero throughout the pr set and must be
//         dropped: the MDk-TRP objective is pure travel-time latency, with no
//         service component (confirmed empirically -- ignoring d reproduces the
//         paper's own reported values on these instances);
//       * the header's m is vehicles per depot, which this problem does not
//         use at all; the fleet size k comes from the paper's tables via
//         kReferences, exactly as it does for the lr set.
//
//     Node ORDER is the same in both layouts -- all customers, then all depots
//     -- so everything downstream is identical and sees only n, m, xs and ys.
//
// Both readers tolerate blank lines and either line-ending convention.
// ---------------------------------------------------------------------------

struct Instance {
    std::string name;
    int n = 0;                     // customers : node ids [0, n)
    int m = 0;                     // depots    : node ids [n, n+m)
    double capacity = 0.0;         // parsed, unused
    std::vector<double> xs, ys;    // size n+m
    std::vector<double> demand;    // size n+m, parsed, unused

    int numNodes() const { return n + m; }
    bool isDepot(int v) const { return v >= n; }
};

static std::string baseName(const std::string& path) {
    const size_t s = path.find_last_of("/\\");
    std::string f = (s == std::string::npos) ? path : path.substr(s + 1);
    const size_t d = f.find_last_of('.');
    return (d == std::string::npos) ? f : f.substr(0, d);
}

static bool loadInstanceLalla(const std::string& path, Instance& inst, std::string& err) {
    std::ifstream in(path);
    if (!in) { err = "cannot open file"; return false; }

    std::vector<double> tok;
    tok.reserve(1024);
    double v;
    while (in >> v) tok.push_back(v);
    if (tok.size() < 3) { err = "fewer than 3 header tokens"; return false; }

    inst.name = baseName(path);
    inst.n = static_cast<int>(std::llround(tok[0]));
    inst.m = static_cast<int>(std::llround(tok[1]));
    inst.capacity = tok[2];
    if (inst.n < 1 || inst.m < 1) { err = "non-positive n or m"; return false; }

    const size_t N = static_cast<size_t>(inst.n) + static_cast<size_t>(inst.m);
    if (tok.size() < 3 + 2 * N) {
        std::ostringstream o;
        o << "expected >= " << (3 + 2 * N) << " tokens for " << N
          << " coordinate pairs, found " << tok.size();
        err = o.str();
        return false;
    }

    inst.xs.resize(N);
    inst.ys.resize(N);
    size_t p = 3;
    for (size_t i = 0; i < N; ++i) { inst.xs[i] = tok[p++]; inst.ys[i] = tok[p++]; }

    inst.demand.assign(N, 0.0);
    if (tok.size() >= p + N)
        for (size_t i = 0; i < N; ++i) inst.demand[i] = tok[p + i];

    return true;
}

// Layout (B): Cordeau MDVRP.  Line-oriented by necessity (see the note above).
static bool loadInstanceCordeau(const std::string& path, Instance& inst, std::string& err) {
    std::ifstream in(path);
    if (!in) { err = "cannot open file"; return false; }

    auto nextLine = [&](std::string& out) {            // skip blank lines
        while (std::getline(in, out)) {
            if (!out.empty() && out.back() == '\r') out.pop_back();   // CRLF
            if (out.find_first_not_of(" \t") != std::string::npos) return true;
        }
        return false;
    };

    std::string line;
    if (!nextLine(line)) { err = "empty file"; return false; }

    int type = -1, vehiclesPerDepot = 0, n = 0, t = 0;
    {
        std::istringstream h(line);
        if (!(h >> type >> vehiclesPerDepot >> n >> t)) {
            err = "malformed Cordeau header (expected: type m n t)";
            return false;
        }
    }
    if (type != 2) { err = "not an MDVRP file (type != 2)"; return false; }
    if (n < 1 || t < 1) { err = "non-positive customer or depot count"; return false; }

    // t lines of "D Q": route-duration and capacity limits, both unused here.
    for (int d = 0; d < t; ++d)
        if (!nextLine(line)) { err = "file ends inside the depot-limit block"; return false; }

    // n customer lines then t depot lines.  Only fields 2 and 3 (x, y) are read;
    // the trailing visit-combination list varies in length and is discarded.
    const size_t N = static_cast<size_t>(n) + static_cast<size_t>(t);
    inst.xs.resize(N);
    inst.ys.resize(N);
    for (size_t i = 0; i < N; ++i) {
        if (!nextLine(line)) {
            std::ostringstream o;
            o << "expected " << N << " node lines, file ends after " << i;
            err = o.str();
            return false;
        }
        std::istringstream ns(line);
        int id;
        double x, y;
        if (!(ns >> id >> x >> y)) {
            std::ostringstream o;
            o << "malformed node line " << (i + 1) << ": \"" << line << '"';
            err = o.str();
            return false;
        }
        inst.xs[i] = x;
        inst.ys[i] = y;
    }

    inst.name = baseName(path);
    inst.n = n;
    inst.m = t;                      // depots = the FOURTH header field
    inst.capacity = 0.0;             // uncapacitated
    inst.demand.assign(N, 0.0);      // demands and service times are not used
    return true;
}

// ---------------------------------------------------------------------------
// Layout (C): TSPLIB CVRP, the CVRPLIB P and E sets
//
//      NAME : P-n16-k8
//      COMMENT : (Augerat et al, No of trucks: 8, Optimal value: 450)
//      TYPE : CVRP
//      DIMENSION : 16                  nodes INCLUDING the depot
//      EDGE_WEIGHT_TYPE : EUC_2D
//      CAPACITY : 35                   IGNORED: the k-TRP is uncapacitated
//      NODE_COORD_SECTION
//      1 30 40                         node 1 is the depot
//      ...
//      DEMAND_SECTION                  IGNORED
//      DEPOT_SECTION
//       1
//       -1
//      EOF
//
//  Re-indexing.  This codebase stores customers at ids [0, n) and depots at
//  [n, n+m).  TSPLIB puts the depot first, so DIMENSION-1 customers are taken
//  from nodes 2..DIMENSION into slots 0..n-1 and the depot node lands in slot
//  n.  The DEPOT_SECTION is read and checked: a file whose depot is not node 1
//  is REJECTED rather than silently mis-indexed.
//
//  Only EUC_2D is accepted.  E-n13-k4 is EXPLICIT (LOWER_ROW) and is not part
//  of this benchmark; if an explicit-matrix file is ever added, the Metric has
//  to grow a matrix branch first, so refusing it here is the honest behaviour.
// ---------------------------------------------------------------------------
static bool loadInstanceTsplib(const std::string& path, Instance& inst, std::string& err) {
    std::ifstream in(path);
    if (!in) { err = "cannot open file"; return false; }

    int dim = -1, depotNode = -1;
    double capacity = -1.0;
    std::string edgeType = "EUC_2D";
    std::vector<double> xs, ys;                 // TSPLIB order, index 0 = node 1
    std::vector<int>    ids;
    enum class Sec { None, Coord, Demand, Depot } sec = Sec::None;

    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.find_first_not_of(" \t") == std::string::npos) continue;

        std::istringstream probe(line);
        std::string first;
        probe >> first;

        if (first == "NODE_COORD_SECTION") { sec = Sec::Coord;  continue; }
        if (first == "DEMAND_SECTION")     { sec = Sec::Demand; continue; }
        if (first == "DEPOT_SECTION")      { sec = Sec::Depot;  continue; }
        if (first == "EOF")                break;
        if (first == "EDGE_WEIGHT_SECTION") {
            err = "EDGE_WEIGHT_SECTION (explicit matrix) is not supported";
            return false;
        }

        if (line.find(':') != std::string::npos && sec == Sec::None) {
            const size_t c = line.find(':');
            std::string key = line.substr(0, c), val = line.substr(c + 1);
            auto trim = [](std::string& t) {
                const size_t a = t.find_first_not_of(" \t");
                const size_t b = t.find_last_not_of(" \t");
                t = (a == std::string::npos) ? std::string() : t.substr(a, b - a + 1);
            };
            trim(key); trim(val);
            if      (key == "NAME")             inst.name = val;
            else if (key == "DIMENSION")        dim = std::atoi(val.c_str());
            else if (key == "CAPACITY")         capacity = std::atof(val.c_str());
            else if (key == "EDGE_WEIGHT_TYPE") edgeType = val;
            continue;
        }

        if (sec == Sec::Coord) {
            std::istringstream ns(line);
            int id; double x, y;
            if (!(ns >> id >> x >> y)) { err = "malformed coordinate line: \"" + line + '"'; return false; }
            ids.push_back(id); xs.push_back(x); ys.push_back(y);
            continue;
        }
        if (sec == Sec::Demand) continue;                 // uncapacitated: skip
        if (sec == Sec::Depot) {
            std::istringstream ds(line);
            int d;
            while (ds >> d) { if (d < 0) { sec = Sec::None; break; }
                              if (depotNode < 0) depotNode = d;
                              else { err = "more than one depot in DEPOT_SECTION"; return false; } }
            continue;
        }
    }

    if (dim <= 1)                     { err = "missing or non-positive DIMENSION"; return false; }
    if (edgeType != "EUC_2D")         { err = "unsupported EDGE_WEIGHT_TYPE \"" + edgeType + "\" (EUC_2D only)"; return false; }
    if (static_cast<int>(xs.size()) != dim) {
        std::ostringstream o; o << "read " << xs.size() << " coordinates, DIMENSION says " << dim;
        err = o.str(); return false;
    }
    if (depotNode < 0) depotNode = 1;                     // TSPLIB default
    if (depotNode != 1)              { err = "depot is not node 1; re-indexing would be wrong"; return false; }
    if (ids.front() != 1)            { err = "first coordinate line is not node 1"; return false; }

    const int n = dim - 1;                                // customers
    inst.n = n;
    inst.m = 1;
    inst.capacity = capacity;                             // recorded, never used
    inst.xs.assign(n + 1, 0.0);
    inst.ys.assign(n + 1, 0.0);
    for (int i = 1; i < dim; ++i) {                       // nodes 2..dim
        inst.xs[i - 1] = xs[i];
        inst.ys[i - 1] = ys[i];
    }
    inst.xs[n] = xs[0];                                   // the depot
    inst.ys[n] = ys[0];
    inst.demand.assign(n + 1, 0.0);                       // uncapacitated
    if (inst.name.empty()) inst.name = baseName(path);
    return true;
}

// Dispatcher: one token on the first line -> layout (A); four -> layout (B).
static bool loadInstance(const std::string& path, Instance& inst, std::string& err) {
    std::ifstream probe(path);
    if (!probe) { err = "cannot open file"; return false; }

    std::string line;
    while (std::getline(probe, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.find_first_not_of(" \t") != std::string::npos) break;
        line.clear();
    }
    if (line.empty()) { err = "empty file"; return false; }

    int tokens = 0;
    {
        std::istringstream ts(line);
        std::string tok;
        while (ts >> tok) ++tokens;
    }
    probe.close();

    // Layout (C) announces itself: TSPLIB headers are "KEY : VALUE".
    if (line.find(':') != std::string::npos) return loadInstanceTsplib(path, inst, err);
    if (tokens >= 4) return loadInstanceCordeau(path, inst, err);
    return loadInstanceLalla(path, inst, err);
}

// ---------------------------------------------------------------------------
// Travel-time metric
// ---------------------------------------------------------------------------

class Metric {
public:
    Metric(const Instance& inst, Rounding r, bool allowMatrix, size_t budgetBytes)
        : xs_(inst.xs), ys_(inst.ys), r_(r), N_(inst.numNodes()) {
        const size_t cells = static_cast<size_t>(N_) * static_cast<size_t>(N_);
        if (allowMatrix && cells * sizeof(double) <= budgetBytes) {
            mat_.resize(cells);
            for (int i = 0; i < N_; ++i)
                for (int j = 0; j < N_; ++j)
                    mat_[static_cast<size_t>(i) * N_ + j] = compute(i, j);
            cached_ = true;
        }
    }

    inline double operator()(int i, int j) const {
        return cached_ ? mat_[static_cast<size_t>(i) * N_ + j] : compute(i, j);
    }

    bool cached() const { return cached_; }
    int size() const { return N_; }

private:
    inline double compute(int i, int j) const {
        if (i == j) return 0.0;
        const double dx = xs_[i] - xs_[j];
        const double dy = ys_[i] - ys_[j];
        const double d = std::sqrt(dx * dx + dy * dy);
        switch (r_) {
            case Rounding::Nearest: return std::floor(d + 0.5);
            case Rounding::Floor:   return std::floor(d);
            case Rounding::Ceil:    return std::ceil(d);
            default:                return d;
        }
    }

    const std::vector<double>& xs_;
    const std::vector<double>& ys_;
    Rounding r_;
    int N_;
    std::vector<double> mat_;
    bool cached_ = false;
};

// ---------------------------------------------------------------------------
// Solution: exactly k open routes, route[0] is the depot vertex
// ---------------------------------------------------------------------------

struct Solution {
    std::vector<std::vector<int>> routes;   // routes[r][0] = depot node id
    double cost = 0.0;

    int k() const { return static_cast<int>(routes.size()); }
    int depotOf(int r) const { return routes[r][0]; }
    int served(int r) const { return static_cast<int>(routes[r].size()) - 1; }
};

// ---------------------------------------------------------------------------
// OBJECTIVE
//
//  Two quantities are computed for every route, and they must not be confused.
//
//  (a) routeLatencyOnly -- the DEPOT-EXCLUSIVE cumulative latency used by the
//      MDk-TRP / CCVRP / MDCCVRP / LLRP builds in this repository:
//
//          A(R[t]) = sum_{s=1..t} c(R[s-1], R[s])
//          Lat(R)  = sum_{t=1..p} A(R[t]) = sum_{s=1..p} (p-s+1) c(R[s-1],R[s])
//
//      The depot has no arrival time and the return leg is NOT charged.
//
//  (b) routeLength -- the CLOSED tour length, return leg included:
//
//          Len(R)  = sum_{s=1..p} c(R[s-1],R[s]) + c(R[p], R[0])
//
//  The objective THIS build minimises is the one Jmal, Haddar & Chabchoub use
//  (EvoCOP 2026, eq. (1), after Kara, Kara & Yetis 2008):
//
//          L_k = sum_{i=0..m} (m + 1 - i) * c(v_i, v_{i+1}),   v_{m+1} = v_0
//
//  i.e. the first arc carries weight m+1 and the RETURN arc carries weight 1.
//  Expanding the coefficients shows this is exactly
//
//          Z(R) = Lat(R) + Len(R)                                        (*)
//
//  so the paper's objective is our depot-exclusive latency plus the closed
//  tour length.  (*) is what makes the transplant safe: both summands are
//  route-local, so every delta formula below keeps its latency term verbatim
//  and gains one extra term -- the ordinary CVRP tour-length delta of the same
//  move, evaluated on the CLOSED tour, i.e. with position p+1 reading R[0].
//
//  cfg::RETURN_WEIGHT is the coefficient of Len(R).  1.0 is the paper; 0.0
//  turns this build back into the plain depot-exclusive k-TRP and is how the
//  two conventions are compared.
//
//  CALIBRATION.  The convention above, together with METRIC = Ceil and the
//  requirement of exactly K NON-EMPTY routes, was not guessed: an independent
//  exact DP over the P instances reproduces the paper's published values
//  exactly -- P20K2 = 1211, P20K3 = 1015, P19K3 = 933 -- while nearest (1124),
//  floor (1090), raw (1132.81) and the depot-exclusive objective (804) all
//  miss P20K2.  The same DP also shows that several of the paper's small-
//  instance references are NOT optimal; see the table at the bottom.
// ---------------------------------------------------------------------------

// (a) depot-exclusive cumulative latency -- the repository's usual objective,
//     carried here only as a SECONDARY reported quantity.
static double routeLatencyOnly(const Metric& D, const std::vector<int>& R) {
    double t = 0.0, L = 0.0;
    for (size_t s = 1; s < R.size(); ++s) { t += D(R[s - 1], R[s]); L += t; }
    return L;
}

// (b) closed tour length, return leg included.  An empty route costs nothing.
static double routeLength(const Metric& D, const std::vector<int>& R) {
    if (R.size() < 2) return 0.0;
    double len = 0.0;
    for (size_t s = 1; s < R.size(); ++s) len += D(R[s - 1], R[s]);
    len += D(R.back(), R[0]);                       // the return leg
    return len;
}

// THE objective of this build: eq. (*) above.
static double routeCost(const Metric& D, const std::vector<int>& R) {
    return routeLatencyOnly(D, R) + cfg::RETURN_WEIGHT * routeLength(D, R);
}

static double totalLatencyOnly(const Metric& D, const Solution& S) {
    double z = 0.0;
    for (const auto& R : S.routes) z += routeLatencyOnly(D, R);
    return z;
}

static double totalCost(const Metric& D, const Solution& S) {
    double z = 0.0;
    for (const auto& R : S.routes) z += routeCost(D, R);
    return z;
}

// ---------------------------------------------------------------------------
// Fleet layout: which depot hosts each of the k vehicles, and the
// nearest-depot cluster each customer belongs to.
//
//   1. nearest[v] = argmin_D dist(v, D), ties to the lowest depot id.
//   2. Depots with a non-empty cluster are "active".  For k >= #active each
//      active depot receives one vehicle and the remaining k - #active are
//      spread over the clusters by the largest-remainder rule on cluster size.
//   3. For k < #active (never the case on this benchmark, where k >= m) only
//      the k largest clusters stay active and nearest[] is recomputed over
//      them, which keeps the seeding filter well defined.
// ---------------------------------------------------------------------------

struct Fleet {
    std::vector<int> vehicleDepot;   // size k -> depot node id
    std::vector<int> nearest;        // size n -> nearest ACTIVE depot node id
    std::vector<int> perDepot;       // size m -> vehicles hosted
};

static Fleet buildFleet(const Instance& inst, const Metric& D, int k) {
    const int n = inst.n, m = inst.m;
    Fleet F;
    F.nearest.assign(n, inst.n);
    F.perDepot.assign(m, 0);

    auto nearestAmong = [&](int v, const std::vector<int>& cand) {
        int best = cand.front();
        double bd = D(v, best);
        for (size_t t = 1; t < cand.size(); ++t) {
            const double d = D(v, cand[t]);
            if (d < bd) { bd = d; best = cand[t]; }
        }
        return best;
    };

    std::vector<int> allDepots(m);
    for (int d = 0; d < m; ++d) allDepots[d] = n + d;

    std::vector<int> size(m, 0);
    for (int v = 0; v < n; ++v) {
        const int d = nearestAmong(v, allDepots);
        F.nearest[v] = d;
        ++size[d - n];
    }

    std::vector<int> active;
    for (int d = 0; d < m; ++d) if (size[d] > 0) active.push_back(n + d);

    if (k < static_cast<int>(active.size())) {
        std::sort(active.begin(), active.end(), [&](int a, int b) {
            if (size[a - n] != size[b - n]) return size[a - n] > size[b - n];
            return a < b;
        });
        active.resize(k);
        std::sort(active.begin(), active.end());
        std::fill(size.begin(), size.end(), 0);
        for (int v = 0; v < n; ++v) {
            const int d = nearestAmong(v, active);
            F.nearest[v] = d;
            ++size[d - n];
        }
    }

    for (int d : active) ++F.perDepot[d - n];
    int remaining = k - static_cast<int>(active.size());

    if (remaining > 0) {
        const int totalSize = std::accumulate(size.begin(), size.end(), 0);
        std::vector<std::pair<double, int>> frac;
        for (int d : active) {
            const double share =
                static_cast<double>(remaining) * size[d - n] / std::max(1, totalSize);
            const int whole = static_cast<int>(share);
            F.perDepot[d - n] += whole;
            remaining -= whole;
            frac.emplace_back(share - whole, d);
        }
        std::sort(frac.begin(), frac.end(), [](const auto& a, const auto& b) {
            if (a.first != b.first) return a.first > b.first;
            return a.second < b.second;
        });
        for (size_t t = 0; remaining > 0; t = (t + 1) % frac.size(), --remaining)
            ++F.perDepot[frac[t].second - n];
    }

    F.vehicleDepot.clear();
    F.vehicleDepot.reserve(k);
    for (int d = 0; d < m; ++d)
        for (int c = 0; c < F.perDepot[d]; ++c) F.vehicleDepot.push_back(n + d);

    return F;
}

// ---------------------------------------------------------------------------
// Seeding: depot-clustered nearest neighbour
//
// A tour rooted at depot D only considers a candidate customer v with
//      dist(v, D) <= dist(v, D')   for every other depot D'
// i.e. v is skipped unless D is its own nearest depot.
// ---------------------------------------------------------------------------

static Solution seedNearestNeighbour(const Instance& inst, const Metric& D,
                                     const Fleet& F, SeedMode mode) {
    const int n = inst.n;
    const int k = static_cast<int>(F.vehicleDepot.size());

    Solution S;
    S.routes.assign(k, {});
    for (int r = 0; r < k; ++r) S.routes[r].push_back(F.vehicleDepot[r]);

    std::map<int, std::vector<int>> byDepot;
    for (int r = 0; r < k; ++r) byDepot[F.vehicleDepot[r]].push_back(r);

    std::vector<char> served(n, 0);

    for (const auto& kv : byDepot) {
        const int depot = kv.first;
        const std::vector<int>& vehicles = kv.second;

        std::vector<int> pool;
        for (int v = 0; v < n; ++v)
            if (!served[v] && F.nearest[v] == depot) pool.push_back(v);   // the filter

        size_t turn = 0;
        while (!pool.empty()) {
            const int r = vehicles[turn % vehicles.size()];
            const int cur = S.routes[r].back();

            int bestIdx = -1;
            double bestD = INF;
            for (size_t t = 0; t < pool.size(); ++t) {
                const double d = D(cur, pool[t]);
                if (d < bestD) { bestD = d; bestIdx = static_cast<int>(t); }
            }
            const int v = pool[bestIdx];
            pool[bestIdx] = pool.back();
            pool.pop_back();
            std::sort(pool.begin(), pool.end());   // deterministic tie-breaking

            S.routes[r].push_back(v);
            served[v] = 1;

            if (mode == SeedMode::RoundRobin) ++turn;
            else if (vehicles.size() > 1 &&
                     static_cast<int>(S.routes[r].size()) - 1 >=
                         (static_cast<int>(pool.size()) + 1))
                ++turn;
        }
    }

    // Any customer still unserved (only if a cluster lost its depot).
    for (int v = 0; v < n; ++v) {
        if (served[v]) continue;
        int br = 0;
        double bd = INF;
        for (int r = 0; r < k; ++r) {
            const double d = D(S.routes[r].back(), v);
            if (d < bd) { bd = d; br = r; }
        }
        S.routes[br].push_back(v);
        served[v] = 1;
    }

    S.cost = totalCost(D, S);
    return S;
}

// ---------------------------------------------------------------------------
// Fleet-wide single-node cheapest insertion -- delta (0)
//
// A removed customer is offered to every feasible route and every position in
// it; the slot minimising the fleet-wide latency increase wins.  O(1) per slot,
// so O(n + k) per customer.
// ---------------------------------------------------------------------------

struct InsertionSlot {
    int route = -1;
    int pos = -1;
    int depot = -1;      // depot to seat the route at (differs only when empty)
    double delta = INF;
};

static InsertionSlot bestInsertion(const Instance& inst, const Metric& D,
                                   const Solution& S, int v, const Fleet& F,
                                   bool strictCluster, DepotMode dmode) {
    InsertionSlot best;
    const int k = S.k();
    for (int r = 0; r < k; ++r) {
        if (strictCluster && S.depotOf(r) != F.nearest[v]) continue;

        const std::vector<int>& R = S.routes[r];
        const int p = static_cast<int>(R.size()) - 1;

        // Empty vehicle: it may be re-housed, so pick the best depot for v.
        // Seating the lone customer v at depot d costs
        //      Lat = c(d,v)   and   Len = c(d,v) + c(v,d) = 2 c(d,v),
        // so dZ = (1 + 2*RETURN_WEIGHT) * c(d,v).  The factor is positive and
        // identical for every depot, so argmin over depots is unchanged -- but
        // the DELTA has to carry it, or an empty route looks cheaper than it is
        // when it is compared against the non-empty slots below.
        if (p == 0) {
            int bd = R[0];
            double bdist = D(bd, v);
            if (dmode == DepotMode::Relocate && !strictCluster) {
                for (int d = 0; d < inst.m; ++d) {
                    const double dd = D(inst.n + d, v);
                    if (dd < bdist) { bdist = dd; bd = inst.n + d; }
                }
            }
            const double inc0 = (1.0 + 2.0 * cfg::RETURN_WEIGHT) * bdist;
            if (inc0 < best.delta) {
                best.delta = inc0; best.route = r; best.pos = 1; best.depot = bd;
            }
            continue;
        }

        // The LATENCY term keeps its two branches: on an append there is no
        // cascade because no customer follows v.  The LENGTH term has no such
        // split -- on the closed tour position p+1 simply reads R[0], so the
        // successor b is the depot and the detour formula applies unchanged.
        double T = 0.0;                               // prefix travel to R[i-1]
        for (int i = 1; i <= p + 1; ++i) {
            const int a = R[i - 1];
            const double dav = D(a, v);
            const int    bL  = (i <= p) ? R[i] : R[0];      // closed-tour succ.
            const double detL = dav + D(v, bL) - D(a, bL);  // tour-length delta
            double inc;
            if (i <= p) {
                const int b = R[i];
                const double det = dav + D(v, b) - D(a, b);
                inc = T + dav + static_cast<double>(p - i + 1) * det;
                T += D(a, b);
            } else {
                inc = T + dav;                        // append: no cascade
            }
            inc += cfg::RETURN_WEIGHT * detL;
            if (inc < best.delta) {
                best.delta = inc; best.route = r; best.pos = i; best.depot = R[0];
            }
        }
    }
    if (best.route < 0 && strictCluster)              // cluster has no vehicle
        return bestInsertion(inst, D, S, v, F, false, dmode);
    return best;
}

// ---------------------------------------------------------------------------
// Optimal depot re-seating for a FIXED customer sequence
//
//      L(R) = p * c(R[0], R[1]) + (terms independent of R[0])
//  =>  best depot = argmin_D c(D, R[1]),  dZ = p * ( c(D',R[1]) - c(D,R[1]) )
//
// O(m), exact, applied only to the route an insertion touched.
// ---------------------------------------------------------------------------

struct ReseatMove {
    int depot = -1;
    double delta = 0.0;
    bool found = false;
};

// With RETURN_WEIGHT > 0 the depot also sits on the CLOSING edge, so the
// cheapest depot is no longer argmin c(D, R[1]): moving the depot trades the
// first edge (weight p + RETURN_WEIGHT) against the last one (weight
// RETURN_WEIGHT).  The full delta is therefore evaluated for every depot.
// At m = 1 -- every instance in this benchmark -- the loop finds nothing and
// the whole mechanism is inert, exactly as in the single-depot CCVRP build.
static ReseatMove bestReseat(const Instance& inst, const Metric& D,
                             const std::vector<int>& R) {
    ReseatMove mv;
    const int p = static_cast<int>(R.size()) - 1;
    if (p <= 0) return mv;
    const int first = R[1];
    const int last  = R[p];
    const double curFirst = D(R[0], first);
    const double curLast  = D(last, R[0]);
    double bestDelta = 0.0;
    int bd = R[0];
    for (int d = 0; d < inst.m; ++d) {
        const int dn = inst.n + d;
        if (dn == R[0]) continue;
        const double delta =
              static_cast<double>(p) * (D(dn, first) - curFirst)
            + cfg::RETURN_WEIGHT * ((D(dn, first) - curFirst)
                                  + (D(last, dn) - curLast));
        if (delta < bestDelta - ACC) { bestDelta = delta; bd = dn; }
    }
    if (bd != R[0]) {
        mv.depot = bd;
        mv.delta = bestDelta;
        mv.found = true;
    }
    return mv;
}

// ===========================================================================
//  THE FOUR RESTRICTED NEIGHBOURHOODS
//
//  Each search function takes the route R just modified and idx, the position
//  of the freshly inserted node, and returns the single best STRICTLY improving
//  move, or `found == false`.  All of them are O(|R|) and route-local.
// ===========================================================================

struct LocalMove {
    bool found = false;
    double delta = 0.0;
    Neighborhood kind = Neighborhood::Restricted2Opt;

    // N1 (2-opt): reverse positions [i+1, j]
    // N2 (swap)  : exchange positions i and j            (i < j)
    int i = -1, j = -1;

    // N3 / N4 (Or-opt): lift R[blockStart .. blockStart+blockLen-1], optionally
    // reverse it, and reinsert it at position insertPos of the residual route.
    int blockStart = -1, blockLen = 0, insertPos = -1;
    bool reversed = false;
};

static void applyMove(std::vector<int>& R, const LocalMove& mv) {
    switch (mv.kind) {
        case Neighborhood::Restricted2Opt:
            std::reverse(R.begin() + mv.i + 1, R.begin() + mv.j + 1);
            break;
        case Neighborhood::RestrictedSwap:
            std::swap(R[mv.i], R[mv.j]);
            break;
        default: {
            std::array<int, 3> B{};
            for (int t = 0; t < mv.blockLen; ++t) B[t] = R[mv.blockStart + t];
            if (mv.reversed) std::reverse(B.begin(), B.begin() + mv.blockLen);
            R.erase(R.begin() + mv.blockStart, R.begin() + mv.blockStart + mv.blockLen);
            R.insert(R.begin() + mv.insertPos, B.begin(), B.begin() + mv.blockLen);
            break;
        }
    }
}

// ---------------------------------------------------------------------------
// N1 -- restricted, insertion-anchored 2-opt  (delta (1))
//
// One fracture edge is pinned to an edge incident to the inserted node (its
// entry edge or its exit edge); the other advances monotonically, giving ROAR's
// four contiguous families F1..F4.  The recurrences
//      L_tsp += f_j ;  TRP_rev += f_j*(j-i-1) ;  TRP_fwd += L_tsp
// (and their descending mirror) make every candidate O(1) time, O(1) space.
// ---------------------------------------------------------------------------

static LocalMove restricted2Opt(const Metric& D, const std::vector<int>& R, int idx) {
    const int p = static_cast<int>(R.size()) - 1;
    LocalMove best;
    best.kind = Neighborhood::Restricted2Opt;
    double bestDelta = -ACC;                   // strict improvement only

    auto consider = [&](int i, int j, double trpRev, double trpFwd) {
        const int a = R[i], b = R[i + 1], c = R[j];
        const int d = (j + 1 <= p) ? R[j + 1] : -1;
        const double Kb = static_cast<double>(p - i);    // depot-exclusive: no +1
        const double Kc = static_cast<double>(p - j);    // depot-exclusive: no +1
        const double entry = (D(a, c) - D(a, b)) * Kb;
        const double exitT = (d >= 0) ? (D(b, d) - D(c, d)) * Kc : 0.0;
        // Tour-length delta of the same 2-opt on the CLOSED tour.  The exit
        // node always exists here: when j = p it is the depot R[0], which is
        // precisely the case the latency term drops (exitT = 0).
        const int dL = (j + 1 <= p) ? R[j + 1] : R[0];
        const double lenDelta = (D(a, c) + D(b, dL)) - (D(a, b) + D(c, dL));
        const double delta = entry + exitT + trpRev - trpFwd
                           + cfg::RETURN_WEIGHT * lenDelta;
        if (delta < bestDelta) {
            bestDelta = delta;
            best.found = true; best.delta = delta; best.i = i; best.j = j;
        }
    };

    auto sweepForward = [&](int i) {            // anchor i, sweep j upwards
        if (i < 0 || i + 2 > p) return;
        double Ltsp = 0.0, trpRev = 0.0, trpFwd = 0.0;
        for (int j = i + 2; j <= p; ++j) {
            const double f = D(R[j - 1], R[j]);
            Ltsp   += f;
            trpRev += f * static_cast<double>(j - i - 1);
            trpFwd += Ltsp;
            consider(i, j, trpRev, trpFwd);
        }
    };

    auto sweepBackward = [&](int j) {           // anchor j, sweep i downwards
        if (j < 2 || j > p) return;
        double cumRev = 0.0, trpRev = 0.0, trpFwd = 0.0;
        for (int i = j - 2; i >= 0; --i) {
            const double f = D(R[i + 1], R[i + 2]);
            cumRev += f;
            trpRev += cumRev;
            trpFwd += f * static_cast<double>(j - i - 1);
            consider(i, j, trpRev, trpFwd);
        }
    };

    sweepForward(idx - 1);    // F1: entry edge as first cut
    sweepBackward(idx - 1);   // F2: entry edge as second cut
    sweepForward(idx);        // F3: exit  edge as first cut
    sweepBackward(idx);       // F4: exit  edge as second cut

    return best;
}

// ---------------------------------------------------------------------------
// N2 -- restricted swap  (delta (2))
//
// Exchange the inserted node with any other customer on the SAME route.  O(1)
// per candidate, so O(p) for the whole scan, versus O(p^2) for a full swap
// neighbourhood.
// ---------------------------------------------------------------------------

// dZ of exchanging positions i < j of a route with p customers.
static double swapDelta(const Metric& D, const std::vector<int>& R, int p, int i, int j) {
    const int a = R[i - 1], x = R[i], y = R[j];
    // Closed-tour successor of position j: position p+1 reads the depot.
    // (The successor of i is needed only in the non-adjacent case, where it is
    // the named node c = R[i+1]; i < j <= p guarantees it exists.)
    const int ys = (j + 1 <= p) ? R[j + 1] : R[0];

    if (j == i + 1) {                           // adjacent: middle edge unchanged
        const double d1 = D(a, y) - D(a, x);
        double d2 = 0.0;
        if (i + 2 <= p) d2 = D(x, R[i + 2]) - D(y, R[i + 2]);
        // length: (a,x),(y,ys) -> (a,y),(x,ys); the middle edge (x,y) is
        // symmetric and survives the exchange unchanged.
        const double lenDelta = (D(a, y) + D(x, ys)) - (D(a, x) + D(y, ys));
        return d1 * static_cast<double>(p - i + 1)
             + d2 * static_cast<double>(p - i - 1)
             + cfg::RETURN_WEIGHT * lenDelta;
    }

    const int c = R[i + 1], e = R[j - 1];
    const double d1 = D(a, y) - D(a, x);
    const double d2 = D(y, c) - D(x, c);
    const double d3 = D(e, x) - D(e, y);
    double d4 = 0.0;
    if (j + 1 <= p) d4 = D(x, R[j + 1]) - D(y, R[j + 1]);
    // length: four edges break, four form.
    const double lenDelta = (D(a, y) + D(y, c) + D(e, x) + D(x, ys))
                          - (D(a, x) + D(x, c) + D(e, y) + D(y, ys));
    return d1 * static_cast<double>(p - i + 1)
         + d2 * static_cast<double>(p - i)
         + d3 * static_cast<double>(p - j + 1)
         + d4 * static_cast<double>(p - j)
         + cfg::RETURN_WEIGHT * lenDelta;
}

static LocalMove restrictedSwap(const Metric& D, const std::vector<int>& R, int idx) {
    const int p = static_cast<int>(R.size()) - 1;
    LocalMove best;
    best.kind = Neighborhood::RestrictedSwap;
    double bestDelta = -ACC;

    for (int t = 1; t <= p; ++t) {
        if (t == idx) continue;
        const int i = std::min(idx, t);
        const int j = std::max(idx, t);
        const double delta = swapDelta(D, R, p, i, j);
        if (delta < bestDelta) {
            bestDelta = delta;
            best.found = true; best.delta = delta; best.i = i; best.j = j;
        }
    }
    return best;
}

// ---------------------------------------------------------------------------
// Block insertion -- delta (0b), the engine behind N3 and N4
//
// Scans every position of the residual route Q for the block B of L nodes and
// returns the cheapest.  blockLen / blockLat carry the block's own internal
// length and internal latency, which is what generalises the single-node
// formula; T is carried incrementally so each slot is O(1).
// ---------------------------------------------------------------------------

struct BlockSlot {
    int pos = -1;
    double delta = INF;
};

static BlockSlot bestBlockInsertion(const Metric& D, const std::vector<int>& Q,
                                    const int* B, int L) {
    const int q = static_cast<int>(Q.size()) - 1;    // customers in the residual

    double blockLen = 0.0;    // sum of internal edges
    double blockLat = 0.0;    // sum over members of their travel time from B[0]
    for (int t = 1; t < L; ++t) {
        blockLen += D(B[t - 1], B[t]);
        blockLat += blockLen;
    }

    BlockSlot best;
    double T = 0.0;                                  // prefix travel to Q[i-1]
    for (int i = 1; i <= q + 1; ++i) {
        const int a = Q[i - 1];
        const double head = D(a, B[0]);
        // Length term: on the closed tour the slot's successor is Q[i], or the
        // depot Q[0] when the block is appended.  blockLen is orientation-
        // invariant, so only the two end connections move.
        const int    bL   = (i <= q) ? Q[i] : Q[0];
        const double detL = head + blockLen + D(B[L - 1], bL) - D(a, bL);
        double inc;
        if (i <= q) {
            const int b = Q[i];
            const double det = head + blockLen + D(B[L - 1], b) - D(a, b);
            inc = static_cast<double>(L) * (T + head) + blockLat
                + static_cast<double>(q - i + 1) * det;
            T += D(a, b);
        } else {
            inc = static_cast<double>(L) * (T + head) + blockLat;
        }
        inc += cfg::RETURN_WEIGHT * detL;
        if (inc < best.delta) { best.delta = inc; best.pos = i; }
    }
    return best;
}

// ---------------------------------------------------------------------------
// N3 / N4 -- restricted Or-opt of a block of L nodes containing the new node
//
// Candidate blocks are the L sliding windows that cover position idx, clipped
// to 1..p, so there are at most L of them.  For each, the block is lifted out
// and the residual rescanned with delta (0b) in both orientations.  O(L*p).
//
//      dZ = ( L(residual) + dZ_blockInsertion ) - L(route)
//
// Reinserting at the original position reproduces the route, giving dZ = 0,
// which the strict-improvement test rejects, so that case is harmless.
// ---------------------------------------------------------------------------

static LocalMove restrictedOrOpt(const Metric& D, const std::vector<int>& R,
                                 int idx, int L, bool tryReversed) {
    const int p = static_cast<int>(R.size()) - 1;
    LocalMove best;
    best.kind = (L == 2) ? Neighborhood::Restricted2OrOpt
                         : Neighborhood::Restricted3OrOpt;
    if (p <= L) return best;                    // nothing left to reinsert into

    const double Lold = routeCost(D, R);
    double bestDelta = -ACC;

    const int sLo = std::max(1, idx - L + 1);
    const int sHi = std::min(idx, p - L + 1);

    std::vector<int> Q;
    Q.reserve(R.size());

    for (int s = sLo; s <= sHi; ++s) {
        // residual route with the block lifted out
        Q.clear();
        Q.insert(Q.end(), R.begin(), R.begin() + s);
        Q.insert(Q.end(), R.begin() + s + L, R.end());
        const double Lres = routeCost(D, Q);

        std::array<int, 3> B{};
        for (int t = 0; t < L; ++t) B[t] = R[s + t];

        const int orientations = tryReversed ? 2 : 1;
        for (int o = 0; o < orientations; ++o) {
            if (o == 1) std::reverse(B.begin(), B.begin() + L);
            const BlockSlot bs = bestBlockInsertion(D, Q, B.data(), L);
            const double delta = (Lres + bs.delta) - Lold;
            if (delta < bestDelta) {
                bestDelta = delta;
                best.found = true;
                best.delta = delta;
                best.blockStart = s;
                best.blockLen = L;
                best.insertPos = bs.pos;
                best.reversed = (o == 1);
            }
        }
    }
    return best;
}

// ---------------------------------------------------------------------------
// Dispatcher: search one chosen neighbourhood
// ---------------------------------------------------------------------------

static LocalMove searchNeighborhood(Neighborhood nb, const Metric& D,
                                    const std::vector<int>& R, int idx,
                                    bool oroptReversed) {
    switch (nb) {
        case Neighborhood::Restricted2Opt:   return restricted2Opt(D, R, idx);
        case Neighborhood::RestrictedSwap:   return restrictedSwap(D, R, idx);
        case Neighborhood::Restricted2OrOpt: return restrictedOrOpt(D, R, idx, 2, oroptReversed);
        default:                             return restrictedOrOpt(D, R, idx, 3, oroptReversed);
    }
}

// ---------------------------------------------------------------------------
// ROAR termination policy
// ---------------------------------------------------------------------------

// ROAR eq. (10): epoch length, clamped to a usable range at small N
static double epochInterval(int nodes) {
    if (nodes >= 100000) return 30.0;
    const double e = 1.0 + 29.0 * ((static_cast<double>(nodes) - 1000.0) / 99000.0);
    return (std::min(30.0, std::max(0.25, e))/50);
}

// ROAR eq. (11): wall-clock budget
static double searchTimeout(int nodes) {
    if (nodes <= 1000) return 100.0;
    if (nodes >= 100000) return 1000.0;
    return 100.0 + 900.0 * ((nodes - 1000.0) / 99000.0);
}

// ---------------------------------------------------------------------------
// Statistics of one run
// ---------------------------------------------------------------------------

// Render a cycle-segment list as "a|b|c" -- pipe-separated so that the whole
// list occupies a single CSV field.
static std::string formatSegments(const std::vector<long long>& v) {
    std::ostringstream os;
    for (size_t i = 0; i < v.size(); ++i) { if (i) os << '|'; os << v[i]; }
    return os.str();
}

struct RunStats {
    double seedCost = 0.0;
    double finalCost = 0.0;
    long long cycles = 0;
    long long accepted = 0;
    long long reseated = 0;
    long long drawn[4] = {0, 0, 0, 0};       // times each neighbourhood was drawn
    long long applied[4] = {0, 0, 0, 0};     // times each one produced a move
    double seconds = 0.0;
    int epochs = 0;
    int perturbations = 0;        // kicks fired in this run (<= cfg::PERTURB_V)
    // ---- per-segment cycle counts (REPORTING ONLY) ---------------------
    // Entry i is the number of ROAR cycles completed before kick i+1 fired;
    // the last entry is the stretch after the final kick.  Hence
    //     cycleSegments.size() == perturbations + 1
    //     sum(cycleSegments)   == cycles
    // Recorded so a run's cycle budget can be reproduced kick by kick.
    std::vector<long long> cycleSegments;
    // ---- in-search crossover ------------------------------------------
    int  crossovers    = 0;   // dEAX calls that produced a real offspring
    int  crossFailed   = 0;   // dEAX calls that fell back to parent A
    int  crossUsed     = 0;   // offspring installed as the incumbent
    int  crossRejected = 0;   // offspring dropped: repair or feasibility failed
    int  crossWorse    = 0;   // offspring legal but rejected by GA_ONLY_IF_BETTER
    long long arcOffered = 0, arcAdmitted = 0;
    long long kick2opt = 0;       // random 2-opt moves applied by the kicks
    long long kickCross = 0;      // random cross-exchanges applied by the kicks
    bool earlyStop = false;
    long long deltaChecks = 0;
    double maxDeltaError = 0.0;
};

// ---------------------------------------------------------------------------
// If a route ends up empty, relocate the single customer whose move costs the
// least overall.  Keeps "exactly k tours" satisfied and can only lower Z.
// ---------------------------------------------------------------------------

static void repairEmptyRoutes(const Instance& inst, const Metric& D, Solution& S,
                              const Fleet& F, bool strictCluster, DepotMode dmode) {
    for (int r = 0; r < S.k(); ++r) {
        if (S.served(r) > 0) continue;
        int bq = -1, bpos = -1, bdepot = S.depotOf(r);
        double bestGain = INF;
        for (int q = 0; q < S.k(); ++q) {
            if (q == r || S.served(q) < 2) continue;
            const std::vector<int>& Rq = S.routes[q];
            const double before = routeCost(D, Rq);
            for (int pos = 1; pos < static_cast<int>(Rq.size()); ++pos) {
                const int v = Rq[pos];
                if (strictCluster && S.depotOf(r) != F.nearest[v]) continue;
                int depot = S.depotOf(r);
                double arrival = D(depot, v);
                if (dmode == DepotMode::Relocate && !strictCluster) {
                    for (int d = 0; d < inst.m; ++d) {
                        const double dd = D(inst.n + d, v);
                        if (dd < arrival) { arrival = dd; depot = inst.n + d; }
                    }
                }
                std::vector<int> cut = Rq;
                cut.erase(cut.begin() + pos);
                // Seating v alone at `depot` costs (1 + 2*RETURN_WEIGHT)*c,
                // the same factor bestInsertion uses for an empty vehicle.
                const double solo = (1.0 + 2.0 * cfg::RETURN_WEIGHT) * arrival;
                const double gain = (routeCost(D, cut) - before) + solo;
                if (gain < bestGain) { bestGain = gain; bq = q; bpos = pos; bdepot = depot; }
            }
        }
        if (bq >= 0) {
            const int v = S.routes[bq][bpos];
            S.routes[bq].erase(S.routes[bq].begin() + bpos);
            S.routes[r][0] = bdepot;
            S.routes[r].push_back(v);
        }
    }
}

// ---------------------------------------------------------------------------
// PERTURBATION -- the single algorithmic addition over newROAR+
//
// Fired when the epoch/patience rule declares convergence and perturbation
// budget remains.  Two stages, in this order:
//
//   (1) INTRA-TOUR.  Every tour of every depot receives PERTURB_T consecutive
//       random 2-opt moves.  One move draws 0 <= i, i+2 <= j <= p and reverses
//       the customer segment at positions [i+1, j]; position 0 holds the depot
//       and is never touched.  A tour with fewer than two customers admits no
//       2-opt and is skipped.
//
//   (2) INTER-TOUR.  PERTURB_K consecutive random cross-exchanges ("tail
//       swaps") among the tours.  One exchange draws two DISTINCT tours A and
//       B, a cut after position i of A and after position j of B, and swaps
//       the tails:
//
//           A = [dA, a_1..a_i | a_{i+1}..a_p]   ->  [dA, a_1..a_i, b_{j+1}..b_q]
//           B = [dB, b_1..b_j | b_{j+1}..b_q]   ->  [dB, b_1..b_j, a_{i+1}..a_p]
//
//       i ranges over [0, p] and j over [0, q], so a whole tour or an empty
//       tail may migrate; the single degenerate draw (both tails empty) is a
//       no-op and is redrawn past.  Customers are conserved exactly, and the
//       depot of each tour stays put -- the ILO's own re-seating step revisits
//       it during the cycles that follow.
//
// BOTH stages are blind: the cost change of a drawn move is never consulted
// and never used to reject it.  That is what makes this a kick rather than a
// local search step, and it is why the kicked solution is nearly always worse
// than the incumbent it replaced.
//
// Afterwards the empty-route repair runs -- a tail swap can empty a tour and
// the "exactly k tours" invariant has to survive -- and the solution's cost is
// recomputed from scratch, since no delta algebra applies to a blind kick.
// ---------------------------------------------------------------------------

// (1) t blind random 2-opt moves on every tour.
static void kickRandom2Opt(Solution& S, std::mt19937_64& rng, int t, RunStats& st) {
    if (t <= 0) return;
    for (auto& R : S.routes) {
        const int p = static_cast<int>(R.size()) - 1;   // customers on this tour
        if (p < 2) continue;                            // no 2-opt exists
        for (int rep = 0; rep < t; ++rep) {
            const int i = std::uniform_int_distribution<int>(0, p - 2)(rng);
            const int j = std::uniform_int_distribution<int>(i + 2, p)(rng);
            std::reverse(R.begin() + i + 1, R.begin() + j + 1);
            ++st.kick2opt;
        }
    }
}

// (2) k blind random cross-exchanges (tail swaps) among the tours.
static void kickCrossExchange(Solution& S, std::mt19937_64& rng, int k, RunStats& st) {
    const int K = S.k();
    if (k <= 0 || K < 2) return;
    for (int rep = 0; rep < k; ++rep) {
        const int a = std::uniform_int_distribution<int>(0, K - 1)(rng);
        int b = std::uniform_int_distribution<int>(0, K - 2)(rng);
        if (b >= a) ++b;                                // b != a, still uniform

        std::vector<int>& A = S.routes[a];
        std::vector<int>& B = S.routes[b];
        const int p = static_cast<int>(A.size()) - 1;
        const int q = static_cast<int>(B.size()) - 1;

        const int i = std::uniform_int_distribution<int>(0, p)(rng);   // cut after A[i]
        const int j = std::uniform_int_distribution<int>(0, q)(rng);   // cut after B[j]
        if (i == p && j == q) continue;                 // both tails empty: no-op

        const std::vector<int> tailA(A.begin() + i + 1, A.end());
        const std::vector<int> tailB(B.begin() + j + 1, B.end());

        A.resize(i + 1);
        A.insert(A.end(), tailB.begin(), tailB.end());
        B.resize(j + 1);
        B.insert(B.end(), tailA.begin(), tailA.end());
        ++st.kickCross;
    }
}

// The complete kick.
static void perturb(const Instance& inst, const Metric& D, Solution& S,
                    const Fleet& F, std::mt19937_64& rng, RunStats& st) {
    kickRandom2Opt(S, rng, cfg::PERTURB_T, st);
    kickCrossExchange(S, rng, cfg::PERTURB_K, st);
    repairEmptyRoutes(inst, D, S, F, cfg::STRICT_CLUSTER, cfg::DEPOT_MODE);
    S.cost = totalCost(D, S);
    ++st.perturbations;
}

// ---------------------------------------------------------------------------
// The ROAR cycle
//
//   seed -> [ ruin -> for each removed v: fleet-wide greedy insert
//                     -> search ONE randomly drawn restricted neighbourhood
//                     -> depot re-seat
//             -> repair -> greedy accept ] repeat
//
//   ... and, on convergence, perturb and keep going until the perturbation
//   budget PERTURB_V is spent.  The global best is tracked separately from
//   the incumbent and is what the function returns (iterated local search).
// checkFeasible is defined after roarSearch; the in-search crossover needs it.
static bool checkFeasible(const Instance& inst, const Solution& S, int k,
                          std::string& why);

// ===========================================================================
//        THE IN-SEARCH CROSSOVER LAYER: ARCHIVE, dEAX, MUTATION
//
//  Archive       the u best DISTINCT solutions seen so far in this run, fed by
//                every acceptance
//  dEAX          the edge assembly crossover of Zou, Hao & Wu (IEEE TEVC 2024,
//                "A two-individual evolutionary algorithm for cumulative
//                capacitated vehicle routing with single and multiple
//                depots"), in its MULTI-DEPOT form
//  ejectionChain TIEA's mutation: three customers in three routes rotated
//
//  dEAX below is the DIRECTED crossover of that paper, Section III-B, taken
//  literally; its own header comment maps each paper step to the code.  With
//  several depots the paper's remedy for odd depot degree is followed too: all
//  depots are treated as ONE node while the alternating walk is built, and a
//  route is then closed at the real depot it departed from, so depot
//  assignment is inherited from BOTH parents.
//
//  gaOccurrences() / edgeMultiset() below stay UNDIRECTED: they serve only the
//  archive's distance test Dis(S_a, S_b) = |E_a| - |E_a n E_b|, which is not
//  part of the crossover and is deliberately left exactly as it was.
// ===========================================================================

// Collapsed node ids: customers keep 0..n-1, EVERY depot becomes inst.n.
static inline int gaCollapse(const Instance& inst, int v) {
    return (v >= inst.n) ? inst.n : v;
}

// One undirected edge occurrence.  `dep` is the REAL depot id when the edge is
// depot-incident, -1 otherwise -- this is what lets the routes be closed again.
struct GAOcc { int a = 0, b = 0, dep = -1; };

static std::vector<GAOcc> gaOccurrences(const Instance& inst, const Solution& S) {
    std::vector<GAOcc> out;
    for (const auto& R : S.routes) {
        if (R.size() < 2) continue;
        const int d = R[0];
        int prev = d;
        for (size_t t = 1; t < R.size(); ++t) {
            const int x = gaCollapse(inst, prev), y = gaCollapse(inst, R[t]);
            out.push_back({std::min(x, y), std::max(x, y),
                           (prev == d) ? d : -1});
            prev = R[t];
        }
        const int x = gaCollapse(inst, prev), y = inst.n;      // the return edge
        out.push_back({std::min(x, y), std::max(x, y), d});
    }
    return out;
}

// Plain sorted edge multiset, for the archive's distance test only.
static std::vector<std::pair<int,int>> edgeMultiset(const Instance& inst,
                                                    const Solution& S) {
    std::vector<std::pair<int,int>> e;
    for (const GAOcc& o : gaOccurrences(inst, S)) e.emplace_back(o.a, o.b);
    std::sort(e.begin(), e.end());
    return e;
}

static int commonEdges(const std::vector<std::pair<int,int>>& a,
                       const std::vector<std::pair<int,int>>& b) {
    size_t i = 0, j = 0; int c = 0;
    while (i < a.size() && j < b.size()) {
        if (a[i] == b[j]) { ++c; ++i; ++j; }
        else if (a[i] < b[j]) ++i;
        else ++j;
    }
    return c;
}

// ---------------------------------------------------------------------------
// Archive: the u best DISTINCT solutions seen so far, with TIEA's admission
// rule Dis(S_a, S_b) = |E_a| - |E_a n E_b| > tau * |E|.  Without it the archive
// fills with near-copies of the incumbent and dEAX degenerates: the symmetric
// difference of two almost identical parents is almost empty, so the offspring
// IS the first parent.
// ---------------------------------------------------------------------------
struct Archive {
    int cap = 0;
    double tau = 0.1;
    std::vector<Solution> sol;
    std::vector<std::vector<std::pair<int,int>>> edges;
    long long offered = 0, admitted = 0, rejNear = 0, rejCost = 0;

    void reset(int c, double t) { cap = c; tau = t; sol.clear(); edges.clear(); }
    bool empty() const { return sol.empty(); }
    int worstIdx() const {
        int w = 0;
        for (size_t i = 1; i < sol.size(); ++i)
            if (sol[i].cost > sol[w].cost) w = static_cast<int>(i);
        return w;
    }
    bool offer(const Instance& inst, const Solution& S) {
        if (cap <= 0) return false;
        ++offered;
        if (static_cast<int>(sol.size()) == cap &&
            S.cost >= sol[worstIdx()].cost - 1e-9) { ++rejCost; return false; }
        std::vector<std::pair<int,int>> e = edgeMultiset(inst, S);
        const int tot = static_cast<int>(e.size());
        for (size_t i = 0; i < sol.size(); ++i)
            if (tot - commonEdges(e, edges[i]) <= tau * tot) { ++rejNear; return false; }
        ++admitted;
        if (static_cast<int>(sol.size()) < cap) {
            sol.push_back(S); edges.push_back(std::move(e));
        } else {
            const int w = worstIdx();
            sol[w] = S; edges[w] = std::move(e);
        }
        return true;
    }
};

// ===========================================================================
//                 dEAX  --  EXACTLY AS IN ZOU, HAO & WU (2024)
//
//  Zou, Hao & Wu, "A two-individual evolutionary algorithm for cumulative
//  capacitated vehicle routing with single and multiple depots", IEEE TEVC
//  2024, Section III-B, followed step by step INCLUDING ITS DIRECTEDNESS.
//  Directedness is the whole point of the "d" in dEAX: reversing a latency
//  route changes its cost, so arc orientation is carried through the crossover
//  rather than recovered afterwards.
//
//   paper step                                   | here
//   ---------------------------------------------+-----------------------------
//   G_AB = (E_A u E_B) \ (E_A n E_B)             | step 1, over DIRECTED arcs
//   partition G_AB into AB-cycles: a random      | step 2, the alternating walk
//     start node, a random incident edge, then   |   driven by (tag, dir); both
//     A- and B-edges alternately linked "with    |   flip every step, so at each
//     different directions" until a cycle closes;|   node of a cycle the two
//     remove it and repeat until G_AB is empty   |   incident arcs are both
//                                                |   heads or both tails
//   E-set, block strategy: one random AB-cycle   | step 3
//     plus every AB-cycle sharing >= 1 node      |
//   intermediate = E_A \ (E-set n E_A)           | step 4, E_A is the base
//                       u (E-set n E_B)          |
//   sub-tours spliced into the route with the    | step 6, direction-preserving
//     FEWEST NODES by 2-opt*: delete one arc     |   2-opt*, chosen by the
//     from each, add two arcs with the SAME      |   minimum of (added - deleted)
//     DIRECTIONS, every other direction kept,    |   over all pairs; no route is
//     all combinations tried, cheapest taken,    |   ever reversed
//     repeated until no sub-tour is left         |
//   multiple depots: treat ALL DEPOTS AS ONE     | DEPV = inst.n; a route is
//     NODE while walking; start from the arcs    |   opened by the real depot of
//     leaving the depot and, on reaching a node  |   its departing arc and closed
//     linked to a DIFFERENT depot, delete that   |   there, so depot ASSIGNMENT
//     arc and close the route at the depot it    |   is inherited from both
//     started from                               |   parents
//
//  WHY THE DIRECTED FORM IS ALSO THE SAFE ONE.  In any solution a customer has
//  exactly one predecessor and one successor and the collapsed depot has K of
//  each, so a DIRECTED arc occurs at most once per parent -- no multiset
//  bookkeeping is needed (an undirected formulation needs it, because the pair
//  {c, depot} occurs twice for a single-customer route).  More importantly,
//
//        in_A(v) = in_B(v)   and   out_A(v) = out_B(v)   for every v
//
//  holds in G_AB -- an arc survives the intersection in A exactly when its
//  counterpart survives in B -- so the alternating walk can always continue,
//  and E_A XOR (a union of COMPLETE AB-cycles) preserves every in- and
//  out-degree exactly.  The intermediate solution is therefore always a
//  disjoint union of K depot cycles plus zero or more customer-only sub-tours,
//  and the "open walk" / "broken depot degree" failures an undirected
//  construction has to guard against cannot arise at all.
//
//  Every remaining failure path still returns parent A, so a crossover that
//  cannot complete degrades to "no crossover this time" rather than to a
//  broken solution.
// ===========================================================================

// One DIRECTED arc u -> v of the joint graph.  `dep` is the REAL depot id when
// the arc leaves or enters a depot and -1 otherwise, which is what lets a route
// be closed at the depot it actually departed from.
struct JArc { int u = 0, v = 0; int tag = 0; int dep = -1; bool dead = false; };

// The directed arc set of a solution, every depot collapsed to inst.n.
// Route [d, c_1, ..., c_p] contributes  d->c_1,  c_1->c_2, ...,  c_p->d.
static std::vector<JArc> gaArcs(const Instance& inst, const Solution& S) {
    std::vector<JArc> out;
    for (const auto& R : S.routes) {
        if (R.size() < 2) continue;
        const int d = R[0];
        out.push_back({inst.n, gaCollapse(inst, R[1]), 0, d, false});
        for (size_t t = 2; t < R.size(); ++t)
            out.push_back({gaCollapse(inst, R[t - 1]),
                           gaCollapse(inst, R[t]), 0, -1, false});
        out.push_back({gaCollapse(inst, R.back()), inst.n, 0, d, false});
    }
    return out;
}

static Solution dEAX(const Instance& inst, const Metric& D,
                     const Solution& PA, const Solution& PB,
                     std::mt19937_64& rng, bool& ok) {
    ok = false;
    const int DEPV = inst.n;             // every depot collapsed to this node
    const int K    = PA.k();
    const int NV   = inst.n + 1;

    // ---- step 1: G_AB = (E_A u E_B) \ (E_A n E_B), over DIRECTED arcs ------
    const std::vector<JArc> AA = gaArcs(inst, PA);
    const std::vector<JArc> BB = gaArcs(inst, PB);

    std::set<std::pair<int,int>> setA, setB;
    for (const JArc& a : AA) setA.insert({a.u, a.v});
    for (const JArc& b : BB) setB.insert({b.u, b.v});

    std::vector<JArc> JE;
    for (const JArc& a : AA)
        if (!setB.count({a.u, a.v})) { JArc x = a; x.tag = 0; JE.push_back(x); }
    for (const JArc& b : BB)
        if (!setA.count({b.u, b.v})) { JArc x = b; x.tag = 1; JE.push_back(x); }
    if (JE.empty()) return PA;                   // identical parents

    // tails_[t][v]: tag-t arcs LEAVING v.   heads_[t][v]: tag-t arcs ENTERING v.
    std::vector<std::vector<int>> tails_[2], heads_[2];
    for (int t = 0; t < 2; ++t) {
        tails_[t].assign(NV, std::vector<int>());
        heads_[t].assign(NV, std::vector<int>());
    }
    for (size_t i = 0; i < JE.size(); ++i) {
        tails_[JE[i].tag][JE[i].u].push_back(static_cast<int>(i));
        heads_[JE[i].tag][JE[i].v].push_back(static_cast<int>(i));
    }

    // dir == 0: the next arc must LEAVE cur and is traversed forwards.
    // dir == 1: the next arc must ENTER cur and is traversed backwards.
    // tag and dir both flip after every step, which IS the paper's "edges from
    // GA and GB are alternately linked with different directions".
    auto takeArc = [&](int v, int tag, int dir) -> int {
        const std::vector<int>& src = (dir == 0) ? tails_[tag][v] : heads_[tag][v];
        std::vector<int> cand;
        for (int id : src) if (!JE[id].dead) cand.push_back(id);
        if (cand.empty()) return -1;
        return cand[std::uniform_int_distribution<size_t>(0, cand.size() - 1)(rng)];
    };

    // ---- step 2: partition G_AB into AB-cycles ------------------------------
    std::vector<std::vector<int>> cycles;
    int live = static_cast<int>(JE.size());
    long long guard = 0;
    const long long guardMax = 64LL * static_cast<long long>(JE.size()) + 4096;

    while (live > 0 && ++guard < guardMax) {
        // "begins with a randomly selected node that has connected edges"
        std::vector<int> startable;
        for (int v = 0; v < NV; ++v) {
            bool any = false;
            for (int t = 0; t < 2 && !any; ++t) {
                for (int id : tails_[t][v]) if (!JE[id].dead) { any = true; break; }
                if (any) break;
                for (int id : heads_[t][v]) if (!JE[id].dead) { any = true; break; }
            }
            if (any) startable.push_back(v);
        }
        if (startable.empty()) break;
        const int s = startable[std::uniform_int_distribution<size_t>(
            0, startable.size() - 1)(rng)];

        // "an adjacent edge is chosen randomly with respect to this node" --
        // uniformly over the live arcs incident to s in either orientation.
        // The arc picked fixes the walk's (tag, dir) for every later step.
        std::vector<std::pair<int,int>> inc;          // (arc id, dir)
        for (int t = 0; t < 2; ++t) {
            for (int id : tails_[t][s]) if (!JE[id].dead) inc.push_back({id, 0});
            for (int id : heads_[t][s]) if (!JE[id].dead) inc.push_back({id, 1});
        }
        if (inc.empty()) break;
        const std::pair<int,int> pick =
            inc[std::uniform_int_distribution<size_t>(0, inc.size() - 1)(rng)];

        const int tag0 = JE[pick.first].tag, dir0 = pick.second;
        int tag = tag0, dir = dir0, forced = pick.first;

        std::vector<int> tNode{s}, tArc;
        std::map<std::pair<int,int>, int> seen;
        seen[{s, 0}] = 0;
        int cur = s;

        while (++guard < guardMax) {
            const int id = (forced >= 0) ? forced : takeArc(cur, tag, dir);
            forced = -1;
            if (id < 0) break;                 // trail is dropped, see below
            JE[id].dead = true; --live;
            cur = (dir == 0) ? JE[id].v : JE[id].u;
            tag ^= 1; dir ^= 1;
            tArc.push_back(id);
            tNode.push_back(cur);

            const int parity = static_cast<int>(tArc.size()) % 2;
            std::map<std::pair<int,int>, int>::iterator it = seen.find({cur, parity});
            if (it != seen.end()) {
                // Same node in the same alternation state: an AB-cycle closed.
                // Its length is even and it is removed from G_AB, as the paper
                // requires; the walk resumes from the truncated trail.
                const int from = it->second;
                cycles.emplace_back(tArc.begin() + from, tArc.end());
                tArc.resize(from);
                tNode.resize(from + 1);
                seen.clear();
                for (int q = 0; q <= static_cast<int>(tArc.size()); ++q)
                    seen[{tNode[q], q % 2}] = q;
                cur = tNode.back();
                const int par = static_cast<int>(tArc.size()) % 2;
                tag = tag0 ^ par;
                dir = dir0 ^ par;
                if (tArc.empty()) break;       // trail exhausted, start afresh
            } else {
                seen[{cur, parity}] = static_cast<int>(tArc.size());
            }
        }
        // A dropped trail (possible only in theory, see the degree argument
        // above) simply never becomes part of any AB-cycle, so it can never
        // enter the E-set and the XOR stays degree-preserving.
    }
    if (cycles.empty()) return PA;

    // ---- step 3: E-set, block strategy -------------------------------------
    const int centre = std::uniform_int_distribution<int>(
        0, static_cast<int>(cycles.size()) - 1)(rng);
    auto nodesOf = [&](int c, std::set<int>& out) {
        for (int id : cycles[c]) {
            if (cfg::GA_ESET_DEPOT_IS_SHARED_NODE || JE[id].u != DEPV)
                out.insert(JE[id].u);
            if (cfg::GA_ESET_DEPOT_IS_SHARED_NODE || JE[id].v != DEPV)
                out.insert(JE[id].v);
        }
    };
    std::set<int> hub;
    nodesOf(centre, hub);
    std::vector<int> eset{centre};
    for (int c = 0; c < static_cast<int>(cycles.size()); ++c) {
        if (c == centre) continue;
        std::set<int> nc;
        nodesOf(c, nc);
        for (int v : nc) if (hub.count(v)) { eset.push_back(c); break; }
    }

    // ---- step 4: intermediate solution, E_A as the base --------------------
    std::map<std::pair<int,int>, int> child;      // arc -> real depot, or -1
    for (const JArc& a : AA) child[{a.u, a.v}] = a.dep;
    for (int c : eset)
        for (int id : cycles[c]) {
            const std::pair<int,int> key{JE[id].u, JE[id].v};
            if (JE[id].tag == 0) child.erase(key);          // drop the A arc
            else                 child[key] = JE[id].dep;   // add the B arc
        }

    // Degree bookkeeping.  Guaranteed by the argument above; checked anyway so
    // that a violation can only ever cost a crossover, never corrupt a run.
    std::vector<int> succ(inst.n, -1);
    std::vector<int> indeg(NV, 0), outdeg(NV, 0);
    std::vector<std::pair<int,int>> fromDepot;    // (first customer, real depot)
    for (const auto& kv : child) {
        const int u = kv.first.first, v = kv.first.second;
        if (u < 0 || u > inst.n || v < 0 || v > inst.n) return PA;
        ++outdeg[u]; ++indeg[v];
        if (u == DEPV) fromDepot.push_back({v, kv.second});
        else           succ[u] = v;               // v is a customer or DEPV
    }
    for (int v = 0; v < inst.n; ++v)
        if (indeg[v] != 1 || outdeg[v] != 1) return PA;
    if (static_cast<int>(fromDepot.size()) != K || indeg[DEPV] != K) return PA;

    // ---- step 5: read the K routes out of the collapsed depot --------------
    Solution kid;
    std::vector<char> used(inst.n, 0);
    for (size_t f = 0; f < fromDepot.size(); ++f) {
        const int d0 = fromDepot[f].second;
        if (d0 < inst.n || d0 >= inst.numNodes()) return PA;
        // The route is opened by the REAL depot its departing arc carried.  The
        // arc that closes it may belong to a DIFFERENT real depot; that arc is
        // deleted and the route closed at d0, which is the paper's rewiring and
        // is why depot assignment is inherited from both parents.
        std::vector<int> R{d0};
        int c = fromDepot[f].first, steps = 0;
        while (c != DEPV && ++steps <= inst.n) {
            if (c < 0 || c >= inst.n || used[c]) return PA;
            used[c] = 1;
            R.push_back(c);
            c = succ[c];
        }
        if (c != DEPV || R.size() < 2) return PA;
        kid.routes.push_back(std::move(R));
    }

    // Whatever is left is a customer-only sub-tour.
    std::vector<std::vector<int>> subs;
    for (int v = 0; v < inst.n; ++v) {
        if (used[v]) continue;
        std::vector<int> T;
        int c = v, steps = 0;
        while (c != DEPV && !used[c] && ++steps <= inst.n) {
            used[c] = 1;
            T.push_back(c);
            c = succ[c];
        }
        if (c != v || T.empty()) return PA;       // not a closed sub-tour
        subs.push_back(std::move(T));
    }

    // ---- step 6: splice every sub-tour in by direction-preserving 2-opt* ---
    for (size_t sx = 0; sx < subs.size(); ++sx) {
        const std::vector<int>& T = subs[sx];
        // "connected to the existing routes with the fewest number of nodes"
        int tgt = 0;
        for (int r = 1; r < kid.k(); ++r)
            if (kid.routes[r].size() < kid.routes[tgt].size()) tgt = r;
        std::vector<int>& R = kid.routes[tgt];

        const int p = static_cast<int>(R.size()) - 1;   // customers on the route
        const int m = static_cast<int>(T.size());
        double bestDelta = INF;
        int bi = -1, bj = -1;

        // Delete (x -> y) from the route and (u -> v) from the sub-tour, add
        // (x -> v) and (u -> y).  Same directions, every other arc untouched,
        // nothing reversed.  i == p is the arc that closes the route.
        for (int i = 0; i <= p; ++i) {
            const int x = R[i];
            const int y = (i + 1 <= p) ? R[i + 1] : R[0];
            const double rem = D(x, y);
            for (int j = 0; j < m; ++j) {
                const int u = T[j], v = T[(j + 1) % m];
                const double delta = (D(x, v) + D(u, y)) - (rem + D(u, v));
                if (delta < bestDelta) { bestDelta = delta; bi = i; bj = j; }
            }
        }
        if (bi < 0) return PA;

        // The merged cycle reads  ... x, v, ..., u, y ...  so the sub-tour goes
        // in forwards, rotated to start at v and to end at u.
        std::vector<int> seq;
        seq.reserve(m);
        for (int t = 0; t < m; ++t) seq.push_back(T[(bj + 1 + t) % m]);
        R.insert(R.begin() + bi + 1, seq.begin(), seq.end());
    }

    // No re-orientation pass: dEAX is directed, so the offspring's arc
    // directions are the ones the construction produced.
    kid.cost = totalCost(D, kid);
    ok = true;
    return kid;
}

// ---------------------------------------------------------------------------
// MUTATION: TIEA's ejection chain.  Three customers in three different routes
// rotate positions (a -> b's slot, b -> c's, c -> a's), repeated reps times.
// Customers are conserved exactly and route lengths are unchanged.
// ---------------------------------------------------------------------------
static void ejectionChain(Solution& S, std::mt19937_64& rng, int reps) {
    const int K = S.k();
    if (K < 3) return;
    for (int t = 0; t < reps; ++t) {
        std::vector<int> cand;
        for (int r = 0; r < K; ++r) if (S.served(r) > 0) cand.push_back(r);
        if (cand.size() < 3) return;
        std::shuffle(cand.begin(), cand.end(), rng);
        const int r1 = cand[0], r2 = cand[1], r3 = cand[2];
        auto pos = [&](int r) {
            return std::uniform_int_distribution<int>(
                1, static_cast<int>(S.routes[r].size()) - 1)(rng);
        };
        const int p1 = pos(r1), p2 = pos(r2), p3 = pos(r3);
        const int a = S.routes[r1][p1], b = S.routes[r2][p2], c = S.routes[r3][p3];
        S.routes[r1][p1] = c;
        S.routes[r2][p2] = a;
        S.routes[r3][p3] = b;
    }
}


// ---------------------------------------------------------------------------

static Solution roarSearch(const Instance& inst, const Metric& D, const Fleet& F,
                           const Solution& seed, uint64_t seedValue,
                           const std::vector<Neighborhood>& pool, RunStats& st,
                           Archive* archive = nullptr) {
    const int n = inst.n;

    // ROAR eq. (3) transposed to customers: depot vertices are never removable,
    // so the removable pool is exactly the n customers and at least one stays.
    //
    // MIN_REMOVE is the only parameter added beyond ROAR's set.  ROAR's alpha
    // was tuned for N in the thousands; at n = 10 the product alpha*n is 2,
    // which leaves the ruin-and-recreate neighbourhood too thin to escape a
    // local optimum under greedy acceptance.  The floor binds only for
    // n < MIN_REMOVE/ALPHA (n < 25 at the defaults) and never exceeds n-1, so
    // it cannot change behaviour on the larger instances.
    int maxRemove = std::max(cfg::MIN_REMOVE, static_cast<int>(cfg::ALPHA * n));
    maxRemove = std::min(maxRemove, std::min(std::max(1, n - 1), cfg::REMOVAL_CAP));

    std::mt19937_64 rng(seedValue);
    std::uniform_int_distribution<int> pickNb(0, static_cast<int>(pool.size()) - 1);

    // Greedy acceptance alone no longer implies "cur IS best": a perturbation
    // deliberately moves the incumbent uphill, so the best solution ever seen
    // is tracked separately and is what this run returns.
    Solution cur = seed;
    cur.cost = totalCost(D, cur);
    st.seedCost = cur.cost;
    Solution best = cur;

    const double epochSec =
        (cfg::EPOCH_SECONDS > 0) ? cfg::EPOCH_SECONDS : epochInterval(n);
    const double budget =
        (cfg::TIME_BUDGET > 0) ? cfg::TIME_BUDGET : searchTimeout(n);

    const TimePoint t0 = Clock::now();
    double nextEpoch = epochSec;
    double epochBase = cur.cost;
    int stale = 0;
    long long segMark = 0;      // cycles at the start of the current segment

    std::vector<int> order(n);
    std::vector<char> removedFlag(n, 0);
    std::vector<int> removed;
    removed.reserve(maxRemove);

    Solution work;

    for (;;) {
        const double elapsed = secondsSince(t0);
        if (elapsed >= budget) break;

        // ---- epoch bookkeeping / patience, then PERTURBATION -------------
        if (elapsed >= nextEpoch) {
            ++st.epochs;
            if (cur.cost < epochBase - 1e-5) {
                epochBase = cur.cost;
                stale = 0;
            } else if (++stale >= cfg::PATIENCE) {
                // -------- convergence detected ------------------------
                if (st.perturbations < cfg::PERTURB_V) {
                    // Budget left: kick the incumbent instead of stopping.
                    perturb(inst, D, cur, F, rng, st);
                    st.cycleSegments.push_back(st.cycles - segMark);
                    segMark = st.cycles;
                    stale = 0;
                    epochBase = cur.cost;   // baseline is the kicked cost
                    nextEpoch = secondsSince(t0) + epochSec;
                    continue;
                }
                // Budget spent: this is the (PERTURB_V + 1)-th convergence.
                st.earlyStop = true;
                break;
            }
            nextEpoch = elapsed + epochSec;
        }

        work = cur;
        const double oldCost = cur.cost;

        // ---------------- Ruin: uniform random customer removal -----------
        const int nRemove = std::uniform_int_distribution<int>(1, maxRemove)(rng);
        order.resize(n);
        std::iota(order.begin(), order.end(), 0);
        std::shuffle(order.begin(), order.end(), rng);

        std::fill(removedFlag.begin(), removedFlag.end(), 0);
        removed.clear();
        for (int t = 0; t < nRemove; ++t) {
            removedFlag[order[t]] = 1;
            removed.push_back(order[t]);
        }

        for (auto& R : work.routes) {
            size_t w = 1;
            for (size_t rd = 1; rd < R.size(); ++rd)
                if (!removedFlag[R[rd]]) R[w++] = R[rd];
            R.resize(w);
        }

        // ------- Recreate: greedy insertion + one random restricted NB -----
        std::shuffle(removed.begin(), removed.end(), rng);
        for (int v : removed) {
            const InsertionSlot slot = bestInsertion(inst, D, work, v, F,
                                                     cfg::STRICT_CLUSTER,
                                                     cfg::DEPOT_MODE);
            if (slot.route < 0) break;                       // failsafe

            if (cfg::VERIFY_DELTAS) {
                const double before = routeCost(D, work.routes[slot.route]);
                std::vector<int> probe = work.routes[slot.route];
                probe[0] = slot.depot;
                probe.insert(probe.begin() + slot.pos, v);
                st.maxDeltaError = std::max(
                    st.maxDeltaError,
                    std::fabs((routeCost(D, probe) - before) - slot.delta));
                ++st.deltaChecks;
            }

            std::vector<int>& R = work.routes[slot.route];
            R[0] = slot.depot;                               // re-house idle vehicle
            R.insert(R.begin() + slot.pos, v);

            // ---- ILO: draw ONE restricted neighbourhood and search it ----
            if (!pool.empty()) {
                const Neighborhood nb = pool[pickNb(rng)];
                ++st.drawn[static_cast<int>(nb)];

                const LocalMove mv = searchNeighborhood(nb, D, R, slot.pos,
                                                        cfg::OROPT_TRY_REVERSED);
                if (mv.found) {
                    if (cfg::VERIFY_DELTAS) {
                        const double before = routeCost(D, R);
                        std::vector<int> probe = R;
                        applyMove(probe, mv);
                        st.maxDeltaError = std::max(
                            st.maxDeltaError,
                            std::fabs((routeCost(D, probe) - before) - mv.delta));
                        ++st.deltaChecks;
                    }
                    applyMove(R, mv);
                    ++st.applied[static_cast<int>(nb)];
                }
            }

            // ---- exact depot re-seating of the route just modified --------
            if (cfg::DEPOT_MODE == DepotMode::Relocate && !cfg::STRICT_CLUSTER) {
                const ReseatMove rs = bestReseat(inst, D, R);
                if (rs.found) {
                    if (cfg::VERIFY_DELTAS) {
                        const double before = routeCost(D, R);
                        std::vector<int> probe = R;
                        probe[0] = rs.depot;
                        st.maxDeltaError = std::max(
                            st.maxDeltaError,
                            std::fabs((routeCost(D, probe) - before) - rs.delta));
                        ++st.deltaChecks;
                    }
                    R[0] = rs.depot;
                    ++st.reseated;
                }
            }
        }

        repairEmptyRoutes(inst, D, work, F, cfg::STRICT_CLUSTER, cfg::DEPOT_MODE);

        // --------------------- Greedy acceptance --------------------------
        const double newCost = totalCost(D, work);
        if (newCost < oldCost - 1e-5) {
            cur = work;
            cur.cost = newCost;
            ++st.accepted;
            // Every interval of the run feeds the archive; the archive decides
            // what is good enough AND different enough to keep.
            if (archive) archive->offer(inst, cur);
            if (cur.cost < best.cost - 1e-9) best = cur;      // global best
        }

        ++st.cycles;

        // ===================================================================
        //        THE IN-SEARCH CROSSOVER -- every GA_EVERY_CYCLES cycles
        //
        // A third kind of kick.  perturb() moves the incumbent blindly; this
        // moves it toward edges that worked elsewhere in this run.  Like a
        // perturbation it may move uphill (unless GA_ONLY_IF_BETTER), and like
        // a perturbation `best` is held separately so nothing can be lost.
        //
        // Every failure path leaves `cur` untouched, so the search degrades to
        // "no crossover this time" rather than to a broken solution.
        // ===================================================================
        if (archive && cfg::GA_EVERY_CYCLES > 0 && cfg::GA_ARCHIVE_U > 0 &&
            st.cycles % cfg::GA_EVERY_CYCLES == 0 && !archive->empty()) {

            const Solution& PA = cfg::GA_PARENT_A_IS_BEST ? best : cur;
            const Solution& PB = archive->sol[
                std::uniform_int_distribution<size_t>(
                    0, archive->sol.size() - 1)(rng)];

            bool okx = false;
            Solution kid = dEAX(inst, D, PA, PB, rng, okx);
            if (!okx) {
                ++st.crossFailed;
            } else {
                ++st.crossovers;
                if (std::uniform_real_distribution<double>(0.0, 1.0)(rng)
                        < cfg::GA_MUTATION_P)
                    ejectionChain(kid, rng, cfg::GA_MUTATION_LEN);

                // The MDk-TRP is UNCAPACITATED, so there is no capacity repair
                // here -- only the empty-route invariant and the full check.
                repairEmptyRoutes(inst, D, kid, F,
                                  cfg::STRICT_CLUSTER, cfg::DEPOT_MODE);
                kid.cost = totalCost(D, kid);
                std::string whyKid;
                const bool good = checkFeasible(inst, kid, cur.k(), whyKid);

                if (good && (!cfg::GA_ONLY_IF_BETTER || kid.cost < cur.cost - 1e-9)) {
                    cur = kid;
                    ++st.crossUsed;
                    if (cur.cost < best.cost - 1e-9) best = cur;
                    // By default the epoch/patience machinery is NOT touched;
                    // see GA_RESET_PATIENCE for why touching it starves perturb().
                    if (cfg::GA_RESET_PATIENCE) { stale = 0; epochBase = cur.cost; }
                } else if (good) {
                    ++st.crossWorse;
                } else {
                    ++st.crossRejected;
                }
            }
        }
    }

    // Trailing stretch: the cycles run after the last kick (or the whole run
    // when no kick fired).  With this push the segments always sum to cycles.
    st.cycleSegments.push_back(st.cycles - segMark);

    st.seconds = secondsSince(t0);
    st.finalCost = best.cost;
    return best;
}

// ---------------------------------------------------------------------------
// Feasibility check
// ---------------------------------------------------------------------------

static bool checkFeasible(const Instance& inst, const Solution& S, int k,
                          std::string& why) {
    if (S.k() != k) { why = "route count != k"; return false; }
    std::vector<int> seen(inst.n, 0);
    for (int r = 0; r < S.k(); ++r) {
        const std::vector<int>& R = S.routes[r];
        if (R.empty()) { why = "empty route array"; return false; }
        // Both bounds.  isDepot() alone only tests v >= n: an id past the last
        // depot would pass it and then index the metric out of range.
        if (!inst.isDepot(R[0]) || R[0] >= inst.numNodes()) {
            why = "route does not start at a valid depot"; return false; }
        if (R.size() < 2) { why = "route serves no customer"; return false; }
        for (size_t t = 1; t < R.size(); ++t) {
            const int v = R[t];
            if (v < 0 || v >= inst.n) { why = "non-customer in route body"; return false; }
            if (seen[v]++) { why = "customer visited more than once"; return false; }
        }
    }
    for (int v = 0; v < inst.n; ++v)
        if (!seen[v]) { why = "customer never visited"; return false; }
    return true;
}

// ---------------------------------------------------------------------------
// PROVEN OPTIMA  --  computed here, not taken from the paper
//
//  The reference values in DATASETS are the paper's.  For the instances small
//  enough to settle exactly, an independent dynamic program was run over the
//  same cost model (ceil-rounded Euclidean, eq. (*) objective, exactly K
//  non-empty routes): a Held-Karp-style suffix DP gives the optimal single
//  route for every customer subset, and a layered set-partition DP combines
//  them into exactly K routes.  That DP is exhaustive, so its value IS the
//  optimum under this cost model.
//
//  Three of them reproduce the paper exactly -- which is what pins the cost
//  model down -- and five show that the paper's reference is NOT optimal:
//
//      row      paper ref   proven optimum
//      P16K5          785             774      paper 1.42% above optimum
//      P16K7          847             824      paper 2.79% above optimum
//      P19K3          933             933      exact match
//      P19K2         1110            1108      paper 0.18% above optimum
//      P20K2         1211            1211      exact match
//      P20K3         1015            1015      exact match
//      P21K3         1049            1041      paper 0.77% above optimum
//      E22K4        1269            1262       paper 0.55% above optimum
//
//  A negative gap on one of those five rows is therefore expected and real,
//  not a sign that this build is cheating; the OPT column marks them.
//  -1 means "not computed" (the DP is exponential and stops being practical
//  past ~22 customers).
// ---------------------------------------------------------------------------

struct ExactOpt { const char* label; double opt; };

static const ExactOpt kExactOptima[] = {
    {"P16K5",  774.0}, {"P16K7",  824.0},
    {"P19K3",  933.0}, {"P19K2", 1108.0},
    {"P20K2", 1211.0}, {"P20K3", 1015.0},
    {"P21K3", 1041.0}, {"E22K4", 1262.0},
};

static double exactOptimum(const std::string& label) {
    for (const auto& e : kExactOptima) if (label == e.label) return e.opt;
    return -1.0;
}

// ---------------------------------------------------------------------------
// Benchmark driver
// ---------------------------------------------------------------------------

struct Row {
    std::string name, paperId;
    int n = 0, m = 0, k = 0;
    double seedCost = 0, best = 0, mean = 0, bks = -1;
    double prevBest = -1;     // the paper's "Best Known" column, context only
    double opt      = -1;     // proven optimum where one was computed
    double bestLat  = 0;      // depot-exclusive latency OF the best solution
    double bestTime = 0;
    bool feasible = true;
    int goodRuns = 0;    // runs that passed BOTH guards
    int badRuns  = 0;    // runs discarded by a guard
    double maxDeltaError = 0.0;
};

static std::string joinPath(const std::string& dir, const std::string& file) {
    if (dir.empty()) return file;
    const char sep = (dir.find('\\') != std::string::npos) ? '\\' : '/';
    std::string base = dir;
    if (base.back() == '/' || base.back() == '\\') base.pop_back();
    return base + sep + file;
}

static std::vector<Neighborhood> buildNeighborhoodPool() {
    std::vector<Neighborhood> pool;
    if (cfg::USE_RESTRICTED_2OPT)   pool.push_back(Neighborhood::Restricted2Opt);
    if (cfg::USE_RESTRICTED_SWAP)   pool.push_back(Neighborhood::RestrictedSwap);
    if (cfg::USE_RESTRICTED_2OROPT) pool.push_back(Neighborhood::Restricted2OrOpt);
    if (cfg::USE_RESTRICTED_3OROPT) pool.push_back(Neighborhood::Restricted3OrOpt);
    return pool;
}

int run() {
    const std::vector<Neighborhood> pool = buildNeighborhoodPool();

    std::cout << "================================================================================================\n"
              << " ROARMDkTRP_perturbation  --  newROAR+ plus ILS perturbation  [p / pr set (Cordeau)]\n"
              << "================================================================================================\n"
              << " dataset dir      : " << cfg::DATASET_DIR << "\n"
              << " instances        : " << (sizeof(cfg::DATASETS) / sizeof(cfg::DATASETS[0]))
              << "   runs/instance : " << cfg::RUNS_PER_INSTANCE << "\n"
              << " alpha            : " << cfg::ALPHA
              << "   cap " << cfg::REMOVAL_CAP
              << "   min-remove " << cfg::MIN_REMOVE
              << "   patience " << cfg::PATIENCE << "\n"
              << " perturbation     : t " << cfg::PERTURB_T
              << " random 2-opt per tour   k " << cfg::PERTURB_K
              << " cross-exchanges among tours   v " << cfg::PERTURB_V
              << " kicks/run\n"
              << " in-search xover  : every " << cfg::GA_EVERY_CYCLES << " cycles"
                 << "   archive u=" << cfg::GA_ARCHIVE_U
                 << " (tau " << cfg::GA_DIVERSITY_TAU << ")"
                 << "   mutation p=" << cfg::GA_MUTATION_P
                 << " len " << cfg::GA_MUTATION_LEN << "\n"
              << "                    dEAX"
                 << ((cfg::GA_ARCHIVE_U > 0 && cfg::GA_EVERY_CYCLES > 0)
                         ? " ENABLED" : " disabled")
                 << ";  parent A = "
                 << (cfg::GA_PARENT_A_IS_BEST ? "global best" : "incumbent")
                 << ";  offspring installed "
                 << (cfg::GA_ONLY_IF_BETTER ? "only if better"
                                            : "unconditionally (kick)") << "\n"
              << " neighbourhoods   : ";
    if (pool.empty()) std::cout << "(none -- pure LNS, no local search)";
    for (size_t t = 0; t < pool.size(); ++t)
        std::cout << (t ? ", " : "") << neighborhoodName(pool[t]);
    std::cout << "\n"
              << " or-opt reversed  : " << (cfg::OROPT_TRY_REVERSED ? "yes" : "no")
              << "   depot mode: "
              << (cfg::DEPOT_MODE == DepotMode::Relocate ? "relocate" : "fixed")
              << "   strict cluster: " << (cfg::STRICT_CLUSTER ? "yes" : "no") << "\n"
              << " metric           : " << roundingName(cfg::METRIC)
              << "   verify deltas: " << (cfg::VERIFY_DELTAS ? "yes" : "no") << "\n"
              << "================================================================================================\n";

    std::ofstream csv;
    if (cfg::WRITE_CSV) {
        // Treat a missing OR empty file as fresh, so a zero-byte leftover
        // still gets its header row.
        bool fresh = true;
        {
            std::ifstream probe(cfg::CSV_PATH, std::ios::ate);
            if (probe && probe.tellg() > 0) fresh = false;
        }
        csv.open(cfg::CSV_PATH, std::ios::app);
        if (csv && fresh)
            csv << "Instance,Row,n,m,K,Run,Seed,SeedCost,FinalCost,Ref,Gap%,"
                   "XoverBuilt,XoverUsed,XoverFailed,XoverInfeasible,XoverWorse,ArcOffered,ArcAdmitted,"
                   "Cycles,CycleSegments,Accepted,Reseat,Applied2opt,AppliedSwap,Applied2oropt,"
                   "Applied3oropt,Epochs,Perturbations,Kick2opt,KickCross,"
                   "EarlyStop,Time(s)\n";
    }

    std::vector<Row> rows;
    long long totalDrawn[4] = {0, 0, 0, 0};
    long long totalApplied[4] = {0, 0, 0, 0};

    // ---- optional row window -------------------------------------------
    // The benchmark is one long run, and some execution environments cannot
    // keep a process alive for that long.  KTRP_ROWS="first:last" (1-based,
    // inclusive) restricts this invocation to a slice of DATASETS so the table
    // can be produced in pieces; unset, every row runs, which is the default
    // and the only behaviour the summary numbers are quoted from.  Nothing
    // else reads the environment.
    const int nRows = static_cast<int>(std::size(cfg::DATASETS));
    int rowLo = 1, rowHi = nRows;
    if (const char* win = std::getenv("KTRP_ROWS")) {
        int a = 0, b = 0;
        if (std::sscanf(win, "%d:%d", &a, &b) == 2 && a >= 1 && b >= a) {
            rowLo = a; rowHi = std::min(b, nRows);
            std::cout << " row window: " << rowLo << ".." << rowHi
                      << " of " << nRows << "\n";
        } else {
            std::cerr << " ignoring malformed KTRP_ROWS=\"" << win << "\"\n";
        }
    }

    int rowIdx = 0;
    for (const BenchEntry& entry : cfg::DATASETS) {
        ++rowIdx;
        if (rowIdx < rowLo || rowIdx > rowHi) continue;
        const std::string path = joinPath(cfg::DATASET_DIR, entry.file);

        Instance inst;
        std::string err;
        if (!loadInstance(path, inst, err)) {
            std::cerr << "skip " << path << ": " << err << "\n";
            continue;
        }

        // K comes from the ROW, never from the file name.  A K above the
        // customer count cannot be met with non-empty routes, so it is clamped
        // and the clamp is announced rather than silently absorbed.
        int k = entry.K;
        if (k > inst.n) {
            std::cerr << "   !! " << entry.label << ": K=" << entry.K
                      << " exceeds n=" << inst.n << ", clamped\n";
            k = inst.n;
        }
        const Metric D(inst, cfg::METRIC, cfg::USE_DISTANCE_MATRIX,
                       cfg::MATRIX_BUDGET_BYTES);
        const Fleet F = buildFleet(inst, D, k);

        Row row;
        row.name     = inst.name;
        row.paperId  = entry.label;
        row.n = inst.n; row.m = inst.m; row.k = k;
        row.bks      = entry.ref;
        row.prevBest = entry.prevBest;
        row.opt      = exactOptimum(entry.label);
        row.best = INF;

        if (!cfg::QUIET) {
            std::cout << "\n== " << entry.label << "  (" << inst.name << ")  n=" << inst.n
                      << " m=" << inst.m << " K=" << k
                      << (D.cached() ? "  [matrix]" : "  [on-the-fly]") << "\n";
        }

        Solution bestSol;
        double sumCost = 0;

        for (int runIdx = 0; runIdx < cfg::RUNS_PER_INSTANCE; ++runIdx) {
            const uint64_t seedValue =
                cfg::RNG_SEED + static_cast<uint64_t>(runIdx) * cfg::SEED_STRIDE;

            const Solution seed = seedNearestNeighbour(inst, D, F, cfg::SEED_MODE);
            RunStats st;
            // One search, one budget.  The archive lives for the whole run
            // and the crossover fires inside roarSearch every GA_EVERY_CYCLES
            // cycles (see section 4b).
            Archive arc;
            arc.reset(cfg::GA_ARCHIVE_U, cfg::GA_DIVERSITY_TAU);
            const Solution sol =
                roarSearch(inst, D, F, seed, seedValue, pool, st,
                           (cfg::GA_EVERY_CYCLES > 0 && cfg::GA_ARCHIVE_U > 0)
                               ? &arc : nullptr);
            st.arcOffered  = arc.offered;
            st.arcAdmitted = arc.admitted;

            // ---- validation of THIS run -------------------------------
            // Two independent guards, both of which must pass before the run's
            // objective is allowed anywhere near the reported Best/Mean:
            //   (a) structural feasibility (checkFeasible);
            //   (b) cost integrity -- Solution::cost is assigned in several
            //       places (seed, acceptance, post-kick, post-crossover), so it
            //       is recomputed from the returned routes and the two must
            //       agree.  A stale .cost can then never be reported as a
            //       (lower) solution value.
            // The original main_pr.cpp only WARNED on (a) and reported the run
            // anyway; with crossover offspring entering the incumbent, a run
            // that ends inconsistent must be discarded instead.
            std::string why;
            bool runOK = checkFeasible(inst, sol, k, why);
            if (runOK) {
                const double exact = totalCost(D, sol);
                if (std::fabs(exact - st.finalCost) > 1e-6 * std::max(1.0, exact)) {
                    std::ostringstream o;
                    o << "reported cost " << std::fixed << std::setprecision(6)
                      << st.finalCost << " != exact " << exact;
                    why = o.str();
                    runOK = false;
                }
            }
            if (!runOK) {
                row.feasible = false;
                ++row.badRuns;
                std::cerr << "   !! run discarded (" << why << ")\n";
            }

            // ---- third guard: write the solution out, read it back -------
            // The two guards above both live inside this process and share the
            // objective implementation.  Dumping the routes to disk and
            // recomputing the cost from the FILE catches anything that corrupts
            // the solution between validation and reporting, and leaves an
            // artefact that an external checker can verify independently.
            if (cfg::DUMP_RUNS) {
                std::ostringstream fn;
                fn << cfg::RUN_DIR << "/" << entry.label << "_run"
                   << (runIdx + 1) << ".sol";
                std::ofstream dump(fn.str());
                if (dump) {
                    dump << "# row " << entry.label << "  instance " << inst.name
                         << "  n " << inst.n << "  m " << inst.m << "  K " << k
                         << "  seed " << seedValue << "\n"
                         << "# metric " << roundingName(cfg::METRIC)
                         << "  return_weight " << cfg::RETURN_WEIGHT << "\n"
                         << "# objective " << std::fixed << std::setprecision(6)
                         << st.finalCost
                         << "  latency_only " << totalLatencyOnly(D, sol)
                         << "  valid " << (runOK ? 1 : 0) << "\n"
                         << "# cycles " << st.cycles
                         << "  cycle_segments "
                         << formatSegments(st.cycleSegments) << "\n";
                    for (int r = 0; r < sol.k(); ++r) {
                        dump << "Route " << (r + 1) << " depot "
                             << (sol.routes[r][0] - inst.n);
                        for (size_t t = 1; t < sol.routes[r].size(); ++t)
                            dump << ' ' << sol.routes[r][t];
                        dump << "\n";
                    }
                    dump.close();

                    // read it back and recompute from the file alone
                    std::ifstream back(fn.str());
                    Solution reread;
                    std::string bline;
                    while (std::getline(back, bline)) {
                        if (bline.empty() || bline[0] == '#') continue;
                        std::istringstream bs(bline);
                        std::string w; int idx = 0, dep = 0;
                        bs >> w >> idx >> w >> dep;
                        std::vector<int> R;
                        R.push_back(inst.n + dep);
                        int v;
                        while (bs >> v) R.push_back(v);
                        reread.routes.push_back(R);
                    }
                    const double fromFile = totalCost(D, reread);
                    if (runOK && std::fabs(fromFile - st.finalCost)
                                     > 1e-6 * std::max(1.0, fromFile)) {
                        std::cerr << "   !! dump mismatch: file says " << fromFile
                                  << ", run reported " << st.finalCost << "\n";
                        row.feasible = false;
                    }
                }
            }

            row.seedCost = st.seedCost;
            row.maxDeltaError = std::max(row.maxDeltaError, st.maxDeltaError);
            if (runOK) {
                sumCost += st.finalCost;
                ++row.goodRuns;
                if (st.finalCost < row.best) {
                    row.best = st.finalCost; row.bestTime = st.seconds; bestSol = sol;
                    row.bestLat = totalLatencyOnly(D, sol);   // secondary column
                }
            }
            for (int t = 0; t < 4; ++t) {
                totalDrawn[t] += st.drawn[t];
                totalApplied[t] += st.applied[t];
            }

            if (!cfg::QUIET) {
                std::cout << "   run " << std::setw(2) << (runIdx + 1)
                          << "  seed(NN) " << std::fixed << std::setprecision(2)
                          << std::setw(11) << st.seedCost
                          << "  ->  " << std::setw(11) << st.finalCost
                          << "  (-"
                          << (st.seedCost > 0
                                  ? 100.0 * (st.seedCost - st.finalCost) / st.seedCost
                                  : 0.0)
                          << "%)  cycles " << std::setw(8) << st.cycles
                          << "  cycseg ["
                          << formatSegments(st.cycleSegments) << "]"
                          << "  applied[2opt/swap/2or/3or] "
                          << st.applied[0] << "/" << st.applied[1] << "/"
                          << st.applied[2] << "/" << st.applied[3]
                          << "  reseat " << st.reseated
                          << "  pert " << st.perturbations << "/" << cfg::PERTURB_V
                          << "  xover " << st.crossUsed << "/" << st.crossovers

                             << " built (" << st.crossFailed << " fell back, "

                             << st.crossRejected << " infeasible, "

                             << st.crossWorse << " worse)"

                          << "  t " << st.seconds << "s"
                          << (st.earlyStop ? "  [early stop]" : "");
                if (row.bks > 0)
                    std::cout << "  gap " << 100.0 * (st.finalCost - row.bks) / row.bks << "%";
                if (cfg::VERIFY_DELTAS)
                    std::cout << "  maxDeltaErr " << std::scientific << std::setprecision(2)
                              << st.maxDeltaError << std::fixed << std::setprecision(2);
                // Flushed so this run's line reaches the terminal -- or a redirected
                // file -- the instant the run ends, not when the buffer fills.
                std::cout << "\n" << std::flush;
            }

            if (csv) {
                csv << inst.name << ',' << row.paperId << ',' << inst.n << ',' << inst.m
                    << ',' << k << ',' << (runIdx + 1) << ','
                    << seedValue << ',' << std::fixed << std::setprecision(4)
                    << st.seedCost << ',' << st.finalCost << ',';
                if (row.bks > 0)
                    csv << row.bks << ',' << 100.0 * (st.finalCost - row.bks) / row.bks;
                else
                    csv << ",";
                csv << ',' << st.crossovers << ',' << st.crossUsed
                    << ',' << st.crossFailed << ',' << st.crossRejected
                    << ',' << st.crossWorse << ',' << st.arcOffered
                    << ',' << st.arcAdmitted;
                csv << ',' << st.cycles
                    << ',' << formatSegments(st.cycleSegments)
                    << ',' << st.accepted << ',' << st.reseated << ','
                    << st.applied[0] << ',' << st.applied[1] << ',' << st.applied[2] << ','
                    << st.applied[3] << ',' << st.epochs << ','
                    << st.perturbations << ',' << st.kick2opt << ','
                    << st.kickCross << ',' << (st.earlyStop ? 1 : 0) << ','
                    << std::setprecision(3) << st.seconds << '\n';
                csv.flush();   // readable while the benchmark runs
            }
        }

        // Mean over the runs that PASSED both guards, not over all runs.
        row.mean = (row.goodRuns > 0) ? sumCost / row.goodRuns
                                      : std::numeric_limits<double>::infinity();
        rows.push_back(row);

        if (cfg::PRINT_ROUTES && !bestSol.routes.empty()) {
            std::cout << "   best routes (cost " << std::fixed << std::setprecision(2)
                      << bestSol.cost << "):\n";
            for (int r = 0; r < bestSol.k(); ++r) {
                std::cout << "     v" << std::setw(2) << r << "  D"
                          << (bestSol.depotOf(r) - inst.n) << " ->";
                for (size_t t = 1; t < bestSol.routes[r].size(); ++t)
                    std::cout << ' ' << bestSol.routes[r][t];
                std::cout << "   [L=" << routeCost(D, bestSol.routes[r]) << "]\n";
            }
        }
    }

    // ------------------------------- summary -------------------------------
    if (rows.empty()) {
        std::cerr << "no instance could be loaded -- check cfg::DATASET_DIR\n";
        return 1;
    }

    std::cout << "\n=========================================================================================================================\n"
              << "k-TRP ROAR+GA summary vs Jmal, Haddar & Chabchoub (EvoCOP 2026)   runs/row=" << cfg::RUNS_PER_INSTANCE
              << "   objective: latency + " << cfg::RETURN_WEIGHT << " x closed length, metric "
              << roundingName(cfg::METRIC) << "\n"
              << "=========================================================================================================================\n"
              << std::left << std::setw(9) << "Row" << std::setw(13) << "Instance"
              << std::right << std::setw(5) << "n" << std::setw(4) << "K"
              << std::setw(12) << "NN seed" << std::setw(11) << "Best"
              << std::setw(11) << "Mean" << std::setw(12) << "Lat(best)"
              << std::setw(11) << "Ref" << std::setw(9) << "Gap%"
              << std::setw(10) << "PrevBKS" << std::setw(8) << "OPT"
              << std::setw(8) << "t(s)" << "\n"
              << "-------------------------------------------------------------------------------------------------------------------------\n";

    double gapSum = 0; int gapCnt = 0;
    bool allFeasible = true;
    double worstDelta = 0;
    int    beatRef = 0, matchedOpt = 0, belowOpt = 0;

    for (const Row& r : rows) {
        std::cout << std::left << std::setw(9) << r.paperId << std::setw(13) << r.name
                  << std::right << std::setw(5) << r.n << std::setw(4) << r.k
                  << std::fixed << std::setprecision(2)
                  << std::setw(12) << r.seedCost << std::setw(11) << r.best
                  << std::setw(11) << r.mean << std::setw(12) << r.bestLat;
        if (r.bks > 0) {
            const double gap = 100.0 * (r.best - r.bks) / r.bks;
            gapSum += gap; ++gapCnt;
            if (r.best < r.bks - 1e-9) ++beatRef;
            std::cout << std::setw(11) << r.bks << std::setw(8) << gap << "%";
        } else {
            std::cout << std::setw(11) << "-" << std::setw(9) << "-";
        }
        if (r.prevBest > 0) std::cout << std::setw(10) << r.prevBest;
        else                std::cout << std::setw(10) << "-";
        if (r.opt > 0) {
            // A run can never be BELOW a proven optimum: if it is, the cost
            // model or the DP is wrong and the whole table is suspect.
            if (r.best < r.opt - 1e-9)      { std::cout << std::setw(8) << "BELOW!"; ++belowOpt; }
            else if (r.best < r.opt + 1e-9) { std::cout << std::setw(8) << "=opt";   ++matchedOpt; }
            else                            { std::cout << std::setw(8) << r.opt; }
        } else {
            std::cout << std::setw(8) << "-";
        }
        std::cout << std::setw(8) << std::setprecision(1) << r.bestTime << "\n";
        allFeasible = allFeasible && r.feasible;
        worstDelta = std::max(worstDelta, r.maxDeltaError);
    }

    std::cout << "-------------------------------------------------------------------------------------------------------------------------\n";
    if (gapCnt)
        std::cout << " mean gap vs the paper's Co-MARL-ATS best over " << gapCnt << " rows: "
                  << std::fixed << std::setprecision(2) << (gapSum / gapCnt) << "%"
                  << "   (strictly better on " << beatRef << " of " << gapCnt << ")\n";
    if (matchedOpt)
        std::cout << " proven optima reached: " << matchedOpt << " of the "
                  << "rows with a computed optimum\n";
    if (belowOpt)
        std::cout << " !! " << belowOpt << " row(s) report a value BELOW a proven optimum"
                     " -- the cost model is wrong, do not use this table\n";
    std::cout << " Lat(best) is the depot-exclusive latency of the same solution"
                 " (the objective the other builds here minimise), for reference only.\n";

    std::cout << " neighbourhood usage (improving moves applied / times drawn):\n";
    static const char* nbNames[4] = {"restricted 2-opt  ", "restricted swap   ",
                                     "restricted 2Or-opt", "restricted 3Or-opt"};
    for (int t = 0; t < 4; ++t) {
        if (!totalDrawn[t]) continue;
        std::cout << "   " << nbNames[t] << "  " << std::setw(12) << totalApplied[t]
                  << " / " << std::setw(12) << totalDrawn[t] << "   ("
                  << std::fixed << std::setprecision(1)
                  << 100.0 * static_cast<double>(totalApplied[t]) / static_cast<double>(totalDrawn[t])
                  << "% hit rate)\n";
    }

    std::cout << " feasibility: " << (allFeasible ? "all solutions valid" : "VIOLATION DETECTED") << "\n";
    if (cfg::VERIFY_DELTAS)
        std::cout << " delta verification: largest |O(1) delta - exact delta| = "
                  << std::scientific << std::setprecision(3) << worstDelta
                  << (worstDelta < 1e-6 ? "   (OK)" : "   (FAIL)") << "\n";
    if (cfg::WRITE_CSV)
        std::cout << " csv appended to " << cfg::CSV_PATH << "\n";

    return allFeasible ? 0 : 2;
}

}  // namespace roar

int main() {
    std::ios::sync_with_stdio(false);
    return roar::run();
}
