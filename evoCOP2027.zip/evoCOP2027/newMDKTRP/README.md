# newMDKTRP — MDkTRPGAenhanced with the paper's dEAX and per-segment cycle counts

Derived from `../MDkTRPGAenhanced`. **Two changes, nothing else.** The claim is
mechanical: an inverse patch reverses both changes and the result is
**byte-identical** to `../MDkTRPGAenhanced/main_ga_mdktrp_standard.cpp`.

| file | differs from `main_ga_mdktrp_standard.cpp` only in |
|---|---|
| `main_ga_mdktrp_standard.cpp` | — (the base; all logic lives here) |
| `main_ga_mdktrp_reduced.cpp` | the 42 `FleetSetting` entries, `CSV_PATH`, `SOL_DIR` |
| `main_ga_mdktrp_standard_noGA.cpp` | `GA_ARCHIVE_U = 0`, `CSV_PATH`, `SOL_DIR` |
| `main_ga_mdktrp_reduced_noGA.cpp` | all of the above |
| `postcheck_mdktrp.py`, `run.sh` | unchanged copies |

Each variant diff is identical, modulo line numbers, to the corresponding diff
in `../MDkTRPGAenhanced`. `GA_EVERY_CYCLES = 0` or `GA_ARCHIVE_U = 0` still
reduces the build exactly to its no-crossover base.

    bash run.sh        # builds and runs all four
    mkdir -p runs_standard runs_reduced runs_standard_noGA runs_reduced_noGA

> **Before you run this:** `DATASETS[]` block 2 points at
> `../LallaRuizVoss_Instances/*.txt`, and that directory is not present in the
> project root (only `../Li`, which is the unrelated CVRPLIB Li set). Those 18
> `lr` rows will not load until it is restored. Inherited from the original
> build, not introduced here.

---

## Change 1 — per-segment cycle counts (reporting only)

`RunStats::cycleSegments` records how many ROAR cycles ran in each stretch
between perturbation kicks. Entry *i* is the count completed **before kick
*i*+1 fired**; the last entry is the stretch after the final kick. So

    cycleSegments.size() == perturbations + 1
    sum(cycleSegments)   == cycles

both hold on every run, always. Reported in three places:

* console, after the total: `cycles 452992  cycseg [228857|179568|44567]`
* a new CSV column **`CycleSegments`**, immediately after `Cycles`, pipe-separated
  so the whole list sits in one field
* the `.sol` dump, as a new key/value line: `cycle_segments 228857|179568|44567`

Nothing in the search reads this back — no branch, no RNG draw, no allocation
inside the hot loop — so a run's trajectory is bit-for-bit what it was before.
`postcheck_mdktrp.py` stores unknown `.sol` keys in `sol.fields` without
interpreting them, so the verifier is unaffected.

## Change 2 — dEAX is now the paper's crossover, literally

The previous build partitioned the **undirected** symmetric difference into
AB-sequences and recovered orientation afterwards by reading each route both
ways and keeping the cheaper one. That is gone. dEAX is now the **directed**
construction of Zou, Hao & Wu (IEEE TEVC 2024) §III-B, step by step:

| paper, §III-B | here |
|---|---|
| `G_AB = (E_A ∪ E_B) \ (E_A ∩ E_B)` | step 1, over **directed arcs** |
| partition into AB-cycles: random start node, random incident edge, then A- and B-edges alternately linked **"with different directions"** until a cycle closes; remove it; repeat until `G_AB` is empty | step 2 — the walk carries `(tag, dir)` and **both flip every step**, so at each node of a cycle the two incident arcs are both heads or both tails |
| E-set by the **block strategy**: one random AB-cycle plus every AB-cycle sharing ≥1 node with it | step 3 |
| intermediate `= E_A \ (E-set ∩ E_A) ∪ (E-set ∩ E_B)`, `E_A` the base | step 4 |
| sub-tours spliced into the route with the **fewest nodes** by 2-opt\*: delete one arc from each, add two arcs **with the same directions as the deleted ones**, every other direction unchanged, all combinations tried, minimum (added − deleted) taken, repeat until none left | step 6 |
| **multiple depots**: treat **all depots as one node** while walking, so an edge leaving the collapsed depot may be followed by an unselected edge of *any* depot; start from the arcs leaving the depot and, on reaching a node linked to a *different* depot, delete that arc and close the route at the depot it started from | `DEPV = inst.n`; each arc carries its **real** depot id, a route is opened by the real depot of its departing arc and closed there — so depot **assignment is inherited from both parents**, which is the whole point of collapsing rather than freezing parent A's assignment |

Three pieces of the old construction are therefore **deleted**, not disabled:

* `orientRoute()` — the post-hoc cheaper-reading pass. Reversal is exactly what
  the "d" in dEAX exists to avoid; the offspring now keeps the directions the
  construction produced.
* the reversed 2-opt\* variant (`bRev`) — the paper keeps the directions of the
  two deleted arcs.
* the undirected multiset bookkeeping (`GAOcc` occurrence lists inside dEAX) — a
  directed arc occurs at most once per parent, so plain sets suffice. (An
  undirected formulation *needs* multisets, because the pair `{c, depot}` occurs
  twice for a single-customer route.)

### Why the directed form is also the safe one

In any solution a customer has exactly one predecessor and one successor, and
the collapsed depot has *K* of each, so in `G_AB`

    in_A(v) = in_B(v)   and   out_A(v) = out_B(v)   for every v

— an arc survives the intersection in A exactly when its counterpart survives in
B, and this holds **at the collapsed depot too**. Hence the alternating walk can
always continue, and `E_A XOR (a union of complete AB-cycles)` preserves every
in- and out-degree exactly. The intermediate solution is therefore **always** a
disjoint union of *K* depot cycles plus zero or more customer-only sub-tours.
The "open walk" and "broken depot degree" failures the undirected version had to
guard against cannot arise. Measured on the 24 Cordeau rows: **3538 offspring
built, 0 infeasible, 81 fall-backs** — against 3314 built and 185 fall-backs for
the undirected build at the same budget and seed.

Every remaining failure path still returns parent A, so a crossover that cannot
complete degrades to "no crossover this time".

### The one configuration constant added

    constexpr bool GA_ESET_DEPOT_IS_SHARED_NODE = true;   // section 4b

The paper says the E-set takes "the AB-cycles that **share at least one node**
with the chosen cycle". `true` is that sentence read literally — the collapsed
depot counts as a shared node like any other — and is the default. `false`
excludes the depot from the sharing test only, and is there because the depot
sits in nearly every AB-cycle, so counting it tends to pull the whole partition
into the E-set and push the offspring towards parent B. It is an ablation knob;
it changes nothing else.

### What was deliberately *not* touched

The archive and its admission rule `Dis(S_a,S_b) = |E_a| − |E_a ∩ E_b| > τ·|E|`
still use the **undirected** edge multiset (`gaOccurrences` / `edgeMultiset`).
That is the population surrogate, not the crossover, so it is out of scope here
and is left exactly as it was. Same for the ejection-chain mutation,
`GA_EVERY_CYCLES`, the install policy, ROAR's ruin-and-recreate, the four
restricted neighbourhoods, the delta algebra, the depot-exclusive latency
objective and `Raw` metric, the depot re-seating, the perturbation, the
epoch/patience termination, both readers, the reference table and every
hyperparameter.

---

## Verification performed

1. **Inverse patch.** Reversing both changes reproduces
   `../MDkTRPGAenhanced/main_ga_mdktrp_standard.cpp` byte-for-byte.
2. **Variant structure.** All three variant diffs here are identical, modulo
   line numbers, to the ones in `../MDkTRPGAenhanced`.
3. **Compilation.** All four sources build clean under
   `g++ -std=c++17 -O3 -Wall -Wextra` — no warnings.
4. **Segment arithmetic.** Over all 24 Cordeau rows of a smoke benchmark,
   `sum(CycleSegments) == Cycles` and `len(CycleSegments) == Perturbations + 1`.
5. **Crossover health, multi-depot.** `0 infeasible`, `0 worse`, and fall-backs
   more than halved versus the old construction.
6. **No quality regression.** 24 rows, one seed, a 2.0 s budget (1/50th of the
   real one): 4 better, 11 identical, 9 worse, mean gap against BKS +0.186 %
   (new) vs +0.164 % (old) — noise at that budget.

Point 6 is a smoke test, not a result. Run the real budget before quoting
anything.
