# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance p07
instance_file ../dat/p07
paper_id p07
n 100
m 4
k 10
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 2906.6944482611
cost_reported 2906.6944482611
cost_recomputed 2906.6944482611
seed_cost 3850.5804968654
time_seconds 11.268
cycles 1169283
cycle_segments 80952|83373|164723|151845|99823|85979|131658|85441|84825|85064|115600
accepted 6545
epochs 153
perturbations 10
crossovers_used 698
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 102 customers 1 86 96 91 36 97 92 84 90 99 41 42   # L=298.4732567703
route 1 depot 102 customers 12 93 94 58 98 95 5 88 17 51 6   # L=302.2035597956
route 2 depot 103 customers 30 87 61 9 89 31 62 10 18 45   # L=337.3974908828
route 3 depot 101 customers 53 54 24 3 55 22 38 66   # L=263.5560399786
route 4 depot 102 customers 57 39 20 72 71 73 74 21 40 56 14   # L=315.0777758652
route 5 depot 100 customers 59 4 83 16 60 15 85 43 13 37   # L=287.8310755185
route 6 depot 103 customers 68 0 49 75 11 25 52 27 26   # L=253.7667177904
route 7 depot 103 customers 69 29 19 50 8 34 70 65 64   # L=316.7447647561
route 8 depot 101 customers 79 67 76 2 78 32 80 77 33 28 23   # L=258.9923835134
route 9 depot 100 customers 82 44 7 81 47 46 35 48 63   # L=272.6513833901
end
