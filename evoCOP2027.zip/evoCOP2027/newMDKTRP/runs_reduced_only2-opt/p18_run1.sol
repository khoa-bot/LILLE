# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..239, depots 240..245
format mdktrp-sol-1
instance p18
instance_file ../dat/p18
paper_id p18
n 240
m 6
k 24
fleet reduced
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 15704.1047410657
cost_reported 15704.1047410657
cost_recomputed 15704.1047410657
seed_cost 20981.1573322523
time_seconds 20.296
cycles 525826
cycle_segments 75966|80753|24088|30391|42609|30193|32275|92057|26289|48601|42604
accepted 7344
epochs 261
perturbations 10
crossovers_used 522
early_stop 1
valid 1
note ok
num_routes 24
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 240 customers 1 0 3 11 19 27 35 16 24 32   # L=640.5929451351
route 1 depot 240 customers 4 12 20 28 36 155 147 139 131 120 128 136 144   # L=951.4213562373
route 2 depot 240 customers 6 7 15 23 31 39 74 66 58 50   # L=682.5483399594
route 3 depot 241 customers 40 48 56 64 72 37 29 21 13   # L=619.8275605730
route 4 depot 241 customers 41 49 57 65 73 38 30 22 14 5 8   # L=689.9070478491
route 5 depot 241 customers 43 51 59 67 75 53 61 69 77   # L=579.0748647609
route 6 depot 241 customers 44 52 60 68 76 115 107 99 91 80 88   # L=672.4264068712
route 7 depot 241 customers 46 45 54 62 70 78 55 47 42   # L=575.4457588775
route 8 depot 242 customers 81 89 97 105 113 158 150 142 134 135 143   # L=684.1421356237
route 9 depot 242 customers 83 85 93 101 109 117 79 71 63   # L=553.5533905933
route 10 depot 242 customers 84 82 92 100 108 116 90 98 106   # L=569.5878945012
route 11 depot 242 customers 86 87 94 102 110 118 95 103 111 119   # L=712.2119497508
route 12 depot 243 customers 121 129 137 145 153 198 190 182 174 175   # L=560.0000000000
route 13 depot 243 customers 123 125 133 141 149 157 112 104 96   # L=553.5533905933
route 14 depot 243 customers 124 122 130 138 146 154 199 191 183   # L=553.5533905933
route 15 depot 243 customers 126 127 132 140 148 156 151 159 114   # L=580.9723893821
route 16 depot 244 customers 163 171 179 187 195 236 228 220 212 207 215   # L=672.4264068712
route 17 depot 244 customers 164 162 161 160 169 177 185 193 170   # L=496.7661908733
route 18 depot 244 customers 165 173 181 189 197 152 34 239 231 223   # L=728.1118318204
route 19 depot 244 customers 166 167 172 180 188 196 178 186 194   # L=569.5878945012
route 20 depot 245 customers 201 200 209 217 225 233 208 216 224 232   # L=712.2119497508
route 21 depot 245 customers 203 205 211 219 227 235 213 221 229 237   # L=712.2119497508
route 22 depot 245 customers 204 202 210 218 226 234 192 184 176 168   # L=682.5483399594
route 23 depot 245 customers 206 214 222 230 238 33 25 17 9 2 10 18 26   # L=951.4213562373
end
