# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..101
format mdktrp-sol-1
instance p05
instance_file ../dat/p05
paper_id p05
n 100
m 2
k 10
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 3124.6835424245
cost_reported 3124.6835424245
cost_recomputed 3124.6835424245
seed_cost 3641.7825079346
time_seconds 8.985
cycles 909808
cycle_segments 80607|81250|82006|81986|81200|82448|82128|82759|82134|90775|82515
accepted 7856
epochs 122
perturbations 10
crossovers_used 909
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 4 92 97 36 99 90 84 60 15 85 43 13 37   # L=388.4881845185
route 1 depot 101 customers 11 25 20 72 71 73 74 21 40 22 66   # L=367.6725027993
route 2 depot 100 customers 17 51 30 87 61 9 89 31 65   # L=325.1464927735
route 3 depot 101 customers 53 54 24 38 55 3 23 28   # L=274.6618398156
route 4 depot 100 customers 59 95 98 58 91 96 86 1 56 14 42 41   # L=333.5590980271
route 5 depot 101 customers 75 49 0 68 69 29 19 50 8   # L=305.8241957976
route 6 depot 101 customers 79 67 76 2 78 32 80 77 33 34 70 64   # L=315.6305442406
route 7 depot 100 customers 82 7 81 6 47 18 10 62 63   # L=278.7663317214
route 8 depot 100 customers 83 16 44 45 46 35 48   # L=212.8536391387
route 9 depot 100 customers 88 5 93 94 12 57 39 52 27 26   # L=322.0807135922
end
