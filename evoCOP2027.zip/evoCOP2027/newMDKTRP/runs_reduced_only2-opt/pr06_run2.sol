# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..287, depots 288..291
format mdktrp-sol-1
instance pr06
instance_file ../dat/pr06
paper_id pr06
n 288
m 4
k 29
fleet reduced
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 9372.7863230836
cost_reported 9372.7863230836
cost_recomputed 9372.7863230836
seed_cost 12703.9080476049
time_seconds 12.669
cycles 234157
cycle_segments 63254|17830|16354|17884|16323|18740|15749|15809|18868|15933|17413
accepted 4128
epochs 160
perturbations 10
crossovers_used 234
early_stop 1
valid 1
note ok
num_routes 29
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 290 customers 18 83 75 13 115 90 285 158 79 67 41   # L=446.5419999382
route 1 depot 291 customers 22 56 61 169 182 154 49 205 6   # L=273.8245481996
route 2 depot 289 customers 37 220 16 145 203 14 170 4 26 234 84 70   # L=346.0292649213
route 3 depot 288 customers 38 263 171 59 276 27 272 260 149 19 104   # L=326.7192820924
route 4 depot 291 customers 39 208 57 267 100 17 81 60   # L=233.4000140077
route 5 depot 291 customers 63 236 1 95 125 72 173 62 207 133 243   # L=319.9860445776
route 6 depot 291 customers 64 273 150 249 112 12 233 96 206 177   # L=301.2895404549
route 7 depot 288 customers 76 71 199 7 68 89 130 111 168   # L=294.9973673226
route 8 depot 290 customers 11 20 44 21 200 131 213 5   # L=310.4896139316
route 9 depot 290 customers 105 227 138 214 181 121 142 196 286 33 148 211   # L=335.2746385738
route 10 depot 288 customers 85 159 217 184 250 24 223 265 103 58 135 118   # L=480.3310744789
route 11 depot 290 customers 86 73 136 77 215 242 102 204   # L=285.5131837066
route 12 depot 290 customers 97 194 128 195 161 240 51 258 224 36 191 140   # L=356.3991933391
route 13 depot 289 customers 99 2 172 216 283 259 78 30 31 156   # L=284.3412949975
route 14 depot 290 customers 80 166 32 29 120 127 277 229 123 270   # L=308.2843126243
route 15 depot 289 customers 134 287 279 143 50 9 55 225   # L=333.2730535185
route 16 depot 289 customers 155 241 230 254 268 253 151 47 42 69 157   # L=438.7285321293
route 17 depot 290 customers 174 269 278 137 228 209 94 129 87   # L=249.0741841926
route 18 depot 289 customers 176 65 113 147 197 202 226 238 93   # L=257.1495394902
route 19 depot 289 customers 178 110 108 152 246 66 48 183 261 282 114   # L=305.8150652764
route 20 depot 288 customers 179 117 175 189 124 252 284 43   # L=220.0499312770
route 21 depot 291 customers 180 210 144 82 167 248 187 132 126 98 54   # L=253.0093337508
route 22 depot 291 customers 190 106 231 222 235 15 237 28 35 218   # L=276.0516373997
route 23 depot 289 customers 244 53 52 232 3 91 221 88 239   # L=370.3430738902
route 24 depot 290 customers 245 162 46 107 0 153 163 160 92   # L=306.0315040394
route 25 depot 290 customers 251 101 266 165 45 25 122 198 188 8   # L=298.3754840988
route 26 depot 288 customers 264 219 193 255 275 40 139 212 146 247 109 274   # L=501.1674596308
route 27 depot 288 customers 280 10 116 119 185 262 257 141   # L=320.1526221670
route 28 depot 289 customers 281 271 74 201 164 186 34 192 256 23   # L=340.1435290566
end
