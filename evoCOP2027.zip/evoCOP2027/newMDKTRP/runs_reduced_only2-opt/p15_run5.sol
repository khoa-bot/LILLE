# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..159, depots 160..163
format mdktrp-sol-1
instance p15
instance_file ../dat/p15
paper_id p15
n 160
m 4
k 16
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 10560.6475548190
cost_reported 10560.6475548190
cost_recomputed 10560.6475548190
seed_cost 13934.5833265496
time_seconds 11.085
cycles 572676
cycle_segments 77934|78067|42630|42903|43013|62255|46965|46815|42757|42883|46454
accepted 6058
epochs 147
perturbations 10
crossovers_used 572
early_stop 1
valid 1
note ok
num_routes 16
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 160 customers 2 1 0 9 17 25 33 18 10   # L=568.3851954890
route 1 depot 160 customers 3 11 19 27 35 8 16 24 32   # L=579.0748647609
route 2 depot 160 customers 4 12 20 28 36 155 147 139 131 133 141 149   # L=822.4264068712
route 3 depot 160 customers 5 13 21 29 37 72 64 56 48   # L=619.8275605730
route 4 depot 160 customers 7 15 23 31 39 157 112 74 66 58   # L=728.1118318204
route 5 depot 161 customers 41 40 51 59 67 75 61 69 77   # L=569.5878945012
route 6 depot 160 customers 6 14 22 30 38 73 65 57 49 42 50   # L=672.4264068712
route 7 depot 161 customers 43 45 46 47 54 62 70 78 53   # L=496.7661908733
route 8 depot 161 customers 44 52 60 68 76 115 107 99 91 80 88 96 104   # L=951.4213562373
route 9 depot 162 customers 81 89 97 105 113 158 150 142 134 127 135   # L=672.4264068712
route 10 depot 162 customers 84 82 92 100 108 116 90 98 106   # L=569.5878945012
route 11 depot 162 customers 83 85 93 101 109 117 79 71 63 55   # L=682.5483399594
route 12 depot 162 customers 86 87 94 102 110 118 95 103 111 119   # L=712.2119497508
route 13 depot 163 customers 121 122 129 137 145 153 130 138 146 154   # L=712.2119497508
route 14 depot 163 customers 124 132 140 148 156 143 151 159 114   # L=574.9327291372
route 15 depot 163 customers 126 125 123 120 128 136 144 152 34 26   # L=628.7005768509
end
