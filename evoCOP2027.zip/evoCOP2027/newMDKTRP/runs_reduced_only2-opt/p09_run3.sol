# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..251
format mdktrp-sol-1
instance p09
instance_file ../dat/p09
paper_id p09
n 249
m 3
k 25
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 14747.2651251298
cost_reported 14747.2651251298
cost_recomputed 14747.2651251298
seed_cost 21702.2657754284
time_seconds 15.762
cycles 378014
cycle_segments 96446|20557|20389|20563|20632|63689|20905|34117|24690|31729|24297
accepted 4875
epochs 202
perturbations 10
crossovers_used 378
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 251 customers 32 210 89 60 128 220 204 30   # L=456.5756586489
route 1 depot 249 customers 36 115 125 214 212 111   # L=432.0787627718
route 2 depot 251 customers 71 184 18 78 4 132 11 48 123 129   # L=617.2665497829
route 3 depot 250 customers 81 156 248 61 236 145 134 83 15   # L=487.5858429778
route 4 depot 249 customers 84 168 180 170 58 161 74 218 232 175 135 225   # L=791.8540436392
route 5 depot 249 customers 91 177 209 40 109 59 157 133 158   # L=452.3021233244
route 6 depot 251 customers 98 69 243 107 154 75 153 86   # L=364.0494349791
route 7 depot 250 customers 100 202 56 213 130 237 9 41 196 193 79 112 102 167 46 54 174   # L=1122.1816915430
route 8 depot 249 customers 104 131 96 66 31 77 200 23 39 16   # L=727.6540429704
route 9 depot 249 customers 108 19 226 28 50 146 126   # L=444.7027307472
route 10 depot 249 customers 110 43 198 207 245 24 140 103 73   # L=583.1960497466
route 11 depot 250 customers 113 147 25 8 152 166 88 247 120 105 188 12   # L=527.4027901308
route 12 depot 249 customers 116 239 97 106 211 76 87 246   # L=549.2805006751
route 13 depot 250 customers 124 63 223 162 68 176 122 117 2 7 189   # L=618.4647679903
route 14 depot 251 customers 137 20 185 171 139 163 6 159 27   # L=481.7483192909
route 15 depot 250 customers 169 1 216 172 136 17 29 190   # L=426.2095690163
route 16 depot 249 customers 173 142 13 44 90 49 244 93 150 85 148   # L=784.0966906935
route 17 depot 250 customers 192 234 10 240 224 222 42 121 37 241 55 65   # L=692.0780374548
route 18 depot 250 customers 194 26 203 197 72 95 165 206 53   # L=580.8620738647
route 19 depot 249 customers 195 47 127 178 160 186 92 45 215 151 155   # L=581.9135561623
route 20 depot 251 customers 208 99 144 114 80 3 187 94 33 181 34   # L=627.1808974306
route 21 depot 249 customers 221 164 5 242 51 14 101 38   # L=453.2080580126
route 22 depot 250 customers 229 57 182 149 219 35 82 205 64 227 52   # L=607.6648054380
route 23 depot 251 customers 233 67 141 231 230 201 138 70 228 0   # L=525.5639325495
route 24 depot 249 customers 235 22 119 21 199 62 179 143 191 183 217 118 238   # L=812.1441952891
end
