# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance p07
instance_file ../dat/p07
paper_id p07
n 100
m 4
k 10
fleet reduced
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 2899.0736768754
cost_reported 2899.0736768754
cost_recomputed 2899.0736768754
seed_cost 3850.5804968654
time_seconds 10.531
cycles 1091060
cycle_segments 122212|91476|108282|99366|82751|144786|83684|91136|98354|84501|84512
accepted 10279
epochs 143
perturbations 10
crossovers_used 1090
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 102 customers 1 56 86 41 13 43 15 85 37   # L=280.0528906472
route 1 depot 102 customers 12 93 94 96 91 58 98 95 5 88 17 51   # L=313.7204244723
route 2 depot 103 customers 30 87 61 9 89 31 62 10 18   # L=262.9079089472
route 3 depot 101 customers 53 54 24 3 55 22 38 66   # L=263.5560399786
route 4 depot 102 customers 57 39 20 72 71 73 74 21 40 14 42   # L=317.0481462114
route 5 depot 100 customers 59 4 92 97 36 99 90 84 60 83 16 44 45   # L=360.4005673924
route 6 depot 103 customers 68 0 49 75 11 25 52 27 26   # L=253.7667177904
route 7 depot 103 customers 69 29 19 50 8 34 70 65 64   # L=316.7447647561
route 8 depot 101 customers 79 67 76 2 78 32 80 77 33 28 23   # L=258.9923835134
route 9 depot 100 customers 82 7 81 6 47 46 35 48 63   # L=271.8838331663
end
