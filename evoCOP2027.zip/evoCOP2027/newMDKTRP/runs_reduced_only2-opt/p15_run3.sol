# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..159, depots 160..163
format mdktrp-sol-1
instance p15
instance_file ../dat/p15
paper_id p15
n 160
m 4
k 16
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 10566.0723048499
cost_reported 10566.0723048499
cost_recomputed 10566.0723048499
seed_cost 13934.5833265496
time_seconds 12.970
cycles 665908
cycle_segments 139404|42757|58385|62072|42474|42779|46982|50329|65587|45761|69378
accepted 6346
epochs 172
perturbations 10
crossovers_used 651
early_stop 1
valid 1
note ok
num_routes 16
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 160 customers 1 0 9 17 25 33 8 16 24 32   # L=712.2119497508
route 1 depot 160 customers 3 5 11 19 27 35 13 21 29   # L=569.5878945012
route 2 depot 160 customers 4 2 10 18 26 34 152 144 136 128   # L=682.5483399594
route 3 depot 160 customers 6 14 22 30 38 73 65 57 49 40 48   # L=672.4264068712
route 4 depot 161 customers 41 42 50 58 66 74 39 31 23   # L=553.5533905933
route 5 depot 161 customers 43 45 51 59 67 75 56 64 72 37   # L=708.0698141271
route 6 depot 161 customers 44 52 60 68 76 115 107 99 91 80 88   # L=672.4264068712
route 7 depot 161 customers 46 47 54 62 70 78 53 61 69 77   # L=712.2119497508
route 8 depot 162 customers 81 89 97 105 113 158 150 142 134 127 135   # L=672.4264068712
route 9 depot 162 customers 83 85 93 101 109 117 79 71 63 55   # L=682.5483399594
route 10 depot 162 customers 84 82 92 100 108 116 90 98 106   # L=569.5878945012
route 11 depot 162 customers 86 87 94 102 110 118 95 103 111 119   # L=712.2119497508
route 12 depot 163 customers 121 120 129 137 145 153 130 138 146 154   # L=712.2119497508
route 13 depot 163 customers 123 131 139 147 155 36 28 20 12 7 15   # L=672.4264068712
route 14 depot 163 customers 124 122 132 140 148 156 143 151 159 114   # L=708.0698141271
route 15 depot 163 customers 126 125 133 141 149 157 112 104 96   # L=553.5533905933
end
