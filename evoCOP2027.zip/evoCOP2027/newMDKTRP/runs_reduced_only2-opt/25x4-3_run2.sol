# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..24, depots 25..28
format mdktrp-sol-1
instance 25x4-3
instance_file ../LallaRuizVoss_Instances/25x4-3.txt
paper_id lr06
n 25
m 4
k 4
fleet reduced
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 2965.1349764100
cost_reported 2965.1349764100
cost_recomputed 2965.1349764100
seed_cost 4080.4396952168
time_seconds 8.644
cycles 7302175
cycle_segments 655473|663527|662501|659641|662896|665425|664005|668292|667532|664511|668372
accepted 13673
epochs 121
perturbations 10
crossovers_used 3672
early_stop 1
valid 1
note ok
num_routes 4
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 26 customers 24 9 5 22 0 13 17   # L=920.9347544394
route 1 depot 28 customers 18 6 16 19 14 10 7   # L=649.5406232567
route 2 depot 25 customers 20 1 23 8 3   # L=657.3321872943
route 3 depot 26 customers 12 4 11 21 2 15   # L=737.3274114196
end
