# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance 50x4-2
instance_file ../LallaRuizVoss_Instances/50x4-2.txt
paper_id lr08
n 50
m 4
k 5
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 7089.6409657910
cost_reported 7089.6409657910
cost_recomputed 7089.6409657910
seed_cost 8961.1524585485
time_seconds 9.383
cycles 2732603
cycle_segments 230878|230248|231088|231286|219170|231164|425809|233686|233964|232475|232835
accepted 5341
epochs 130
perturbations 10
crossovers_used 1362
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 51 customers 7 37 48 12 33 17 24 15 27 4 11 23 16 8   # L=2138.7082968112
route 1 depot 53 customers 25 32 10 41 43 34 5 20 45 49 3   # L=1437.6915028479
route 2 depot 52 customers 31 39 13 14 30 38 9 0   # L=935.9348162732
route 3 depot 51 customers 35 36 19 29 44 26 6 18   # L=1142.7947524219
route 4 depot 50 customers 40 47 42 22 2 46 21 1 28   # L=1434.5115974368
end
