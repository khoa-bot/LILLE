# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..101
format mdktrp-sol-1
instance p04
instance_file ../dat/p04
paper_id p04
n 100
m 2
k 10
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 3122.1272450726
cost_reported 3122.1272450726
cost_recomputed 3122.1272450726
seed_cost 4297.0732119878
time_seconds 10.678
cycles 1118306
cycle_segments 151306|145330|107325|84815|93386|85608|100900|85796|84604|93740|85496
accepted 8898
epochs 145
perturbations 10
crossovers_used 1116
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 1 56 14 42 41 13 43 37   # L=230.9084082958
route 1 depot 101 customers 9 61 18 10 62 89 31 65   # L=293.5571426922
route 2 depot 100 customers 12 93 5 95 98 58 92 4 83 44 7 45   # L=353.4745192687
route 3 depot 100 customers 20 72 71 73 21 40 74 55 22 38 66   # L=348.7214709509
route 4 depot 101 customers 30 87 6 81 47 46 35 48 63   # L=264.2949167260
route 5 depot 100 customers 39 25 11 67 79 53 54 24 3   # L=297.8882204572
route 6 depot 100 customers 57 52 27 26 51 17 82 59 88   # L=297.1123497928
route 7 depot 101 customers 68 0 49 75 76 2 78 77 33 28 23   # L=319.0200928560
route 8 depot 101 customers 69 29 19 50 32 80 8 70 34 64   # L=352.8552870632
route 9 depot 100 customers 86 96 94 91 36 97 99 90 84 60 15 85 16   # L=364.2948369699
end
