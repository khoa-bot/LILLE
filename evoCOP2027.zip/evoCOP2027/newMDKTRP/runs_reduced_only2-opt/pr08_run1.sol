# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..143, depots 144..149
format mdktrp-sol-1
instance pr08
instance_file ../dat/pr08
paper_id pr08
n 144
m 6
k 15
fleet reduced
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 5910.5135024660
cost_reported 5910.5135024660
cost_recomputed 5910.5135024660
seed_cost 8146.6679557012
time_seconds 11.915
cycles 701245
cycle_segments 146080|92502|53042|48706|52507|48719|52995|53033|48693|48180|56788
accepted 6584
epochs 159
perturbations 10
crossovers_used 643
early_stop 1
valid 1
note ok
num_routes 15
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 147 customers 18 2 4 76 138 133 120 118 48 142   # L=507.1573516532
route 1 depot 148 customers 35 51 123 99 57 59 93 94 85 88   # L=375.2400193526
route 2 depot 145 customers 22 49 7 37 15 21 60 109 25 119 11 8   # L=540.6290007885
route 3 depot 144 customers 27 101 33 108 62 24 100 95   # L=259.8544784497
route 4 depot 144 customers 39 52 113 65 46 38 92 140 81 115   # L=429.5681800963
route 5 depot 149 customers 53 58 64 131 89 141 68   # L=291.9290642752
route 6 depot 146 customers 55 134 45 23 14 124 67 107 44 36   # L=356.6391557862
route 7 depot 149 customers 71 143 42 80 54 47 1 29 30 136   # L=467.3670600552
route 8 depot 148 customers 20 106 82 63 84 0 75 135 40 91 130   # L=337.3507621697
route 9 depot 146 customers 90 32 31 61 5 86 87 125   # L=325.6474521763
route 10 depot 145 customers 103 9 34 41 127 112 102 3 17 117 50   # L=619.2321606413
route 11 depot 144 customers 121 6 72 83 26 79 28 56   # L=364.4238637940
route 12 depot 149 customers 122 43 74 98 70 16 110 129 97 19 77   # L=430.7923777703
route 13 depot 145 customers 132 105 139 73 96 126 114 12 10 128   # L=334.1600532649
route 14 depot 148 customers 137 111 13 104 78 69 66 116   # L=270.5225221927
end
