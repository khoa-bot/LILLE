# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..9, depots 10..13
format mdktrp-sol-1
instance 10x4-1
instance_file ../LallaRuizVoss_Instances/10x4-1.txt
paper_id lr01
n 10
m 4
k 4
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 592.2691191901
cost_reported 592.2691191901
cost_recomputed 592.2691191901
seed_cost 724.5561607353
time_seconds 8.591
cycles 23739055
cycle_segments 2145784|2157442|2147142|2153632|2156498|2160086|2149910|2169656|2171427|2148013|2179465
accepted 28140
epochs 121
perturbations 10
crossovers_used 11712
early_stop 1
valid 1
note ok
num_routes 4
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 10 customers 1   # L=64.0312423743
route 1 depot 11 customers 4 3 8   # L=99.5153275036
route 2 depot 13 customers 9 7   # L=141.6552506060
route 3 depot 13 customers 6 2 5 0   # L=287.0672987061
end
