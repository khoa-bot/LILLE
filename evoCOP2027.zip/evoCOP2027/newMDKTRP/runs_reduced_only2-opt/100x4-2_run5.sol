# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance 100x4-2
instance_file ../LallaRuizVoss_Instances/100x4-2.txt
paper_id lr14
n 100
m 4
k 10
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 10742.5572587947
cost_reported 10742.5572587947
cost_recomputed 10742.5572587947
seed_cost 15826.6549029123
time_seconds 10.310
cycles 1077986
cycle_segments 153068|92342|84942|99599|85185|92713|85210|85004|84446|84838|130639
accepted 5597
epochs 140
perturbations 10
crossovers_used 618
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 3 86 5 68 90 61 1 30 97 45 62   # L=1415.5108368336
route 1 depot 103 customers 49 53 51 50 93 99 82 60 2 77   # L=963.3613435889
route 2 depot 102 customers 71 56 79 89 85 88 81 63 48 22 64   # L=1054.3837051393
route 3 depot 101 customers 54 73 70 39 29 24 40   # L=676.0674675869
route 4 depot 102 customers 52 59 34 95 23 37 80 44 11 12 33   # L=874.0454114869
route 5 depot 102 customers 58 15 10 66 67 25 36 18   # L=706.0213998427
route 6 depot 100 customers 69 0 8 75 9 31 78 38   # L=1059.3145308327
route 7 depot 101 customers 72 84 27 42 43 41 20 92 65 46 13 74   # L=1655.5358627280
route 8 depot 103 customers 83 17 21 94 6 16 26 87 91 14 19   # L=1326.9331621071
route 9 depot 100 customers 55 35 57 96 47 4 28 76 32 98 7   # L=1011.3835386486
end
