# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..95, depots 96..99
format mdktrp-sol-1
instance pr02
instance_file ../dat/pr02
paper_id pr02
n 96
m 4
k 10
fleet reduced
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 4092.5108527055
cost_reported 4092.5108527055
cost_recomputed 4092.5108527055
seed_cost 5179.6009730371
time_seconds 10.220
cycles 1183530
cycle_segments 160122|110902|103671|94379|94413|93447|118039|101628|92443|93732|120754
accepted 8534
epochs 139
perturbations 10
crossovers_used 1146
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 99 customers 10 27 53 28 94 56 57 85   # L=225.6272831752
route 1 depot 96 customers 24 71 59 86 64 31 93 8 68 38   # L=458.2630266864
route 2 depot 99 customers 44 78 25 20 90 45 14 29 22 39   # L=402.7856785894
route 3 depot 98 customers 55 65 35 70 52 11 2 75 49   # L=424.1825449601
route 4 depot 96 customers 72 61 36 43 16 15 63 4 6   # L=402.8030468708
route 5 depot 97 customers 77 87 32 46 0 41 21 84 82 74   # L=331.5755205584
route 6 depot 96 customers 80 18 73 54 19 91 92 37 67 26   # L=534.9938917298
route 7 depot 96 customers 83 58 69 40 42 62 12 7   # L=416.9129916743
route 8 depot 99 customers 88 51 60 89 76 3 30 34 81 48 33   # L=466.6067176269
route 9 depot 98 customers 95 66 13 17 79 23 1 9 47 5 50   # L=428.7601508343
end
