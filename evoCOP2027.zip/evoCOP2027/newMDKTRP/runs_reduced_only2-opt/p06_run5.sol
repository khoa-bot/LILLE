# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..102
format mdktrp-sol-1
instance p06
instance_file ../dat/p06
paper_id p06
n 100
m 3
k 10
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 2870.0542629227
cost_reported 2870.0542629227
cost_recomputed 2870.0542629227
seed_cost 4003.0992744652
time_seconds 10.531
cycles 1107459
cycle_segments 138220|85507|114660|100360|92834|116972|85309|108014|93683|85659|86241
accepted 8238
epochs 143
perturbations 10
crossovers_used 1106
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 101 customers 3 24 54 53 79 67 28 23   # L=236.4678208197
route 1 depot 102 customers 9 89 31 62 10 61 18 45   # L=265.4655320736
route 2 depot 100 customers 60 83 4 59 82 7 44 16 85 37   # L=326.3616280367
route 3 depot 101 customers 20 72 71 73 21 40 74 55 22 38 66   # L=293.7214709509
route 4 depot 102 customers 30 87 6 81 47 46 35 48 63   # L=269.0456931310
route 5 depot 102 customers 68 0 49 75 76 2 78 77 33 34 64   # L=369.3571477899
route 6 depot 102 customers 69 29 19 50 32 80 8 70 65   # L=249.2912578585
route 7 depot 100 customers 84 92 58 98 95 93 5 88 17 51 26 27   # L=276.3119626930
route 8 depot 100 customers 15 43 13 41 86 1 56 14 42   # L=292.2503160871
route 9 depot 100 customers 90 99 36 97 91 96 94 12 57 39 52 25 11   # L=291.7814334823
end
