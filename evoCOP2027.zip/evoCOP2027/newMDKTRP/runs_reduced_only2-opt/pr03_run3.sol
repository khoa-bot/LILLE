# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..143, depots 144..147
format mdktrp-sol-1
instance pr03
instance_file ../dat/pr03
paper_id pr03
n 144
m 4
k 15
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 6474.1784222930
cost_reported 6474.1784222930
cost_recomputed 6474.1784222930
seed_cost 8868.8200803650
time_seconds 10.716
cycles 638495
cycle_segments 75253|58554|53992|68371|54441|49658|70498|52674|48549|52857|53648
accepted 4603
epochs 143
perturbations 10
crossovers_used 474
early_stop 1
valid 1
note ok
num_routes 15
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 145 customers 3 5 50 45 67 57 21 24 125 54   # L=491.5929213441
route 1 depot 144 customers 61 16 79 2 13 126 120 87 51 39   # L=370.3963285354
route 2 depot 146 customers 129 98 22 121 80 31 137 95 89 6 133 29   # L=594.8197696168
route 3 depot 145 customers 36 23 69 78 18 140 73 71 99   # L=393.5638913272
route 4 depot 144 customers 108 106 10 34 27 4 77 107   # L=308.8144788481
route 5 depot 147 customers 42 103 15 17 122 127 64 32 92 119 53 97 48   # L=650.8661520940
route 6 depot 144 customers 38 70 25 94 0 138 131 12 109 118 68   # L=450.2529292978
route 7 depot 147 customers 85 20 65 52 28 81 58 75 115   # L=452.4590417639
route 8 depot 144 customers 90 44 86 128 132 72 9 111 11 49   # L=360.3040842372
route 9 depot 147 customers 91 62 142 14 40 105 83 143 117   # L=302.0008322851
route 10 depot 146 customers 93 101 47 96 63 136 130 8 76   # L=353.0579747718
route 11 depot 145 customers 116 74 7 55 82 124 66 84   # L=354.3689062822
route 12 depot 146 customers 1 141 112 135 59 46 139 88   # L=425.2716335097
route 13 depot 146 customers 123 43 41 37 19 30 102 113 26   # L=481.3999669289
route 14 depot 145 customers 134 104 114 100 33 110 60 35 56   # L=485.0095114507
end
