# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..252
format mdktrp-sol-1
instance p10
instance_file ../dat/p10
paper_id p10
n 249
m 4
k 25
fleet reduced
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 14031.4502377497
cost_reported 14031.4502377497
cost_recomputed 14031.4502377497
seed_cost 22071.7550704624
time_seconds 17.088
cycles 410078
cycle_segments 35667|63169|26060|39554|31777|22125|28249|49048|52638|28043|33748
accepted 6848
epochs 219
perturbations 10
crossovers_used 400
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 252 customers 3 80 99 144 208 137 20 185 171   # L=453.0410402584
route 1 depot 250 customers 9 237 12 166 88 247 120 105   # L=520.2511287217
route 2 depot 250 customers 224 240 10 234 81 156 248 61 236 176 68 162 223 63 124   # L=803.8737757914
route 3 depot 251 customers 17 29 53 203 197 72 206 165 95 111 212   # L=526.1327639158
route 4 depot 251 customers 123 48 11 210 89 60 129 128 220 204 30   # L=581.2571958296
route 5 depot 250 customers 55 175 232 135 225 31 77 200 146   # L=504.8237445112
route 6 depot 250 customers 65 167 46 54 16 23 39 126   # L=387.0052115304
route 7 depot 249 customers 84 221 164 36 5 242 15   # L=376.7635131564
route 8 depot 249 customers 91 177 209 40 109 108 19 226 28 59 157   # L=506.8514327865
route 9 depot 252 customers 94 33 181 27 155 143 191 183 217 118 238 34   # L=706.2051306133
route 10 depot 249 customers 104 131 96 66 50 133 158   # L=442.0519028953
route 11 depot 249 customers 110 235 22 119 21 43 198 207 245 24 140   # L=596.7526578426
route 12 depot 252 customers 114 243 107 69 98 141 67 70 228 0   # L=689.0324542871
route 13 depot 249 customers 116 239 97 106 211 76 87 246   # L=512.1689141814
route 14 depot 251 customers 227 52 64 205 82 35 219 216   # L=503.0965757140
route 15 depot 250 customers 130 213 56 202 192 100 113 147 25 8 152 188   # L=662.3383107269
route 16 depot 251 customers 136 172 26 194 1 169 229 57 182 149   # L=563.8783579305
route 17 depot 252 customers 159 6 163 139 73 103 125 115 214   # L=609.6315657182
route 18 depot 249 customers 173 142 13 44 186 92 90 49 244 93 150 85 148   # L=945.6793809235
route 19 depot 252 customers 187 86 153 75 154 231 230 201 138   # L=531.7531301597
route 20 depot 251 customers 190 4 132 78 18 184 71 32 233   # L=450.6606970471
route 21 depot 249 customers 195 47 127 178 160 45 215 179 62 199 151   # L=573.1001032230
route 22 depot 250 customers 196 41 193 79 112 102 174   # L=259.9977127529
route 23 depot 250 customers 222 42 121 145 83 134 122 117 2 7 189   # L=642.7651404264
route 24 depot 250 customers 241 37 38 101 14 218 74 161 58 170 180 168 51   # L=682.3383968063
end
