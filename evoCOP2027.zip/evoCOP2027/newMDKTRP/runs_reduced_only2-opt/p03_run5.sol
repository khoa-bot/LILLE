# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..74, depots 75..79
format mdktrp-sol-1
instance p03
instance_file ../dat/p03
paper_id p03
n 75
m 5
k 8
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 2271.2151943903
cost_reported 2271.2151943903
cost_recomputed 2271.2151943903
seed_cost 2950.3721083861
time_seconds 14.436
cycles 2397867
cycle_segments 202729|403962|183367|208553|185191|244315|181144|263742|227343|131010|166511
accepted 13508
epochs 198
perturbations 10
crossovers_used 1702
early_stop 1
valid 1
note ok
num_routes 8
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 79 customers 0 72 32 62 15 48 23 22 55   # L=266.1113695604
route 1 depot 78 customers 2 43 31 8 38 24 49 17 54   # L=264.7554646651
route 2 depot 76 customers 28 44 3 29 1 73 20 68   # L=232.1806454584
route 3 depot 77 customers 34 7 45 33 51 26 12 53 18 13 58   # L=344.9655886355
route 4 depot 79 customers 42 40 41 63 21 61 27 60   # L=236.1944201885
route 5 depot 76 customers 47 46 35 70 59 69 19 36 4 14 56   # L=360.4763236533
route 6 depot 77 customers 52 10 65 64 37 9 57 71 30   # L=274.1338510631
route 7 depot 75 customers 74 67 5 50 16 39 11 25 66 6   # L=292.3975311660
end
