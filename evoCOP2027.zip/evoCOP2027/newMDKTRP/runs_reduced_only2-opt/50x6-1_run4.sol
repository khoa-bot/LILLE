# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..55
format mdktrp-sol-1
instance 50x6-1
instance_file ../LallaRuizVoss_Instances/50x6-1.txt
paper_id lr10
n 50
m 6
k 6
fleet reduced
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 6143.4704876202
cost_reported 6143.4704876202
cost_recomputed 6143.4704876202
seed_cost 10027.6533163092
time_seconds 9.816
cycles 3029624
cycle_segments 488351|241957|244819|242783|334129|246278|245408|246518|245965|247302|246114
accepted 7253
epochs 136
perturbations 10
crossovers_used 1506
early_stop 1
valid 1
note ok
num_routes 6
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 55 customers 9 43 42 24 12 44 41 38 27   # L=858.9133477075
route 1 depot 50 customers 20 10 22 13 5 33 28 7 16   # L=1123.0094487091
route 2 depot 52 customers 40 46 1 36 26 17 19 37 23   # L=1304.4917167522
route 3 depot 53 customers 47 48 3 11 2 14 39 31 34   # L=1162.4389307758
route 4 depot 54 customers 21 0 25 45 6 35   # L=622.1539773822
route 5 depot 52 customers 49 18 8 15 32 4 29 30   # L=1072.4630662935
end
