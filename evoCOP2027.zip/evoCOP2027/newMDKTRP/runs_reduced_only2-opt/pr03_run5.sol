# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..143, depots 144..147
format mdktrp-sol-1
instance pr03
instance_file ../dat/pr03
paper_id pr03
n 144
m 4
k 15
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 6480.6887739604
cost_reported 6480.6887739604
cost_recomputed 6480.6887739604
seed_cost 8868.8200803650
time_seconds 11.166
cycles 678012
cycle_segments 110900|63828|50832|54663|54648|54843|50270|59672|68907|49968|59481
accepted 6133
epochs 149
perturbations 10
crossovers_used 678
early_stop 1
valid 1
note ok
num_routes 15
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 147 customers 15 17 122 127 64 32 92 58 75 115   # L=478.0737406418
route 1 depot 145 customers 36 23 69 78 18 140 73 71 99   # L=393.5638913272
route 2 depot 144 customers 38 61 25 94 0 138 131 12 109 26 113   # L=392.0073504452
route 3 depot 147 customers 42 103 21 57 67 24 125 119 53 97 48   # L=569.4880727356
route 4 depot 144 customers 16 79 2 13 126 120 87 51 39 68 118   # L=545.9795392096
route 5 depot 147 customers 62 142 14 40 27 4 34 10 70   # L=313.8767355810
route 6 depot 145 customers 3 5 50 45 107 77 11 111   # L=319.0939044348
route 7 depot 147 customers 85 20 65 28 81 52 89 6 29   # L=448.9235735982
route 8 depot 144 customers 90 44 108 106 86 128 132 72 9 49   # L=321.8873373942
route 9 depot 147 customers 91 105 83 22 121 80 31 137 95 133 76   # L=486.0939080373
route 10 depot 146 customers 93 101 47 96 63 136 1 141 130   # L=305.2405457814
route 11 depot 145 customers 116 74 7 55 82 124 66 84 54   # L=494.9192139631
route 12 depot 146 customers 123 112 135 59 46 139 88 8   # L=418.1153752521
route 13 depot 146 customers 129 98 143 117 41 43 37 19 30 102   # L=508.4160741082
route 14 depot 145 customers 134 104 114 100 33 110 60 35 56   # L=485.0095114507
end
