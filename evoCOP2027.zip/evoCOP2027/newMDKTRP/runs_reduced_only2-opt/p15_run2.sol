# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..159, depots 160..163
format mdktrp-sol-1
instance p15
instance_file ../dat/p15
paper_id p15
n 160
m 4
k 16
fleet reduced
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 10549.8989789989
cost_reported 10549.8989789989
cost_recomputed 10549.8989789989
seed_cost 13934.5833265496
time_seconds 13.045
cycles 667230
cycle_segments 76597|62094|42169|42619|104769|50032|57514|42315|104517|42346|42258
accepted 6581
epochs 173
perturbations 10
crossovers_used 667
early_stop 1
valid 1
note ok
num_routes 16
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 160 customers 1 9 17 25 33 8 16 24 32   # L=579.0748647609
route 1 depot 160 customers 6 5 3 0 11 19 27 35 13   # L=496.7661908733
route 2 depot 160 customers 2 10 18 26 34 152 144 136 128   # L=619.8275605730
route 3 depot 160 customers 4 12 20 28 36 155 147 139 131 125 133   # L=672.4264068712
route 4 depot 161 customers 41 49 57 65 73 38 30 22 14 7 15   # L=672.4264068712
route 5 depot 161 customers 43 40 48 56 64 72 37 29 21   # L=553.5533905933
route 6 depot 161 customers 44 42 50 58 66 74 39 31 23   # L=553.5533905933
route 7 depot 161 customers 46 45 51 59 67 75 53 61 69 77   # L=712.2119497508
route 8 depot 162 customers 81 80 88 96 104 112 157 149 141   # L=553.5533905933
route 9 depot 162 customers 83 91 99 107 115 76 68 60 52 47 54 62 70 78   # L=1087.2792206136
route 10 depot 162 customers 84 87 94 102 110 118 95 103 111 119   # L=712.2119497508
route 11 depot 162 customers 86 85 93 101 109 117 79 71 63 55   # L=682.5483399594
route 12 depot 163 customers 123 120 121 122 129 137 145 153 130   # L=496.7661908733
route 13 depot 163 customers 124 132 140 148 156 138 146 154   # L=450.5929451351
route 14 depot 163 customers 126 134 142 150 158 113 105 97 89 82 92 100 108 116   # L=1087.2792206136
route 15 depot 163 customers 127 135 143 151 159 114 106 98 90   # L=619.8275605730
end
