# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..105
format mdktrp-sol-1
instance 100x6-2
instance_file ../LallaRuizVoss_Instances/100x6-2.txt
paper_id lr17
n 100
m 6
k 10
fleet reduced
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 9917.5658727513
cost_reported 9917.5658727513
cost_recomputed 9917.5658727513
seed_cost 13777.6640642041
time_seconds 9.353
cycles 1013754
cycle_segments 103407|88073|93793|94841|86875|95416|88242|88232|88690|88916|97269
accepted 3961
epochs 127
perturbations 10
crossovers_used 502
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 102 customers 28 97 77 2 42 89 32 90 13   # L=756.3098756209
route 1 depot 101 customers 48 50 59 12 39 49 82 8 60   # L=914.2439808028
route 2 depot 100 customers 64 85 47 61 9 36 46 17 63   # L=896.4632314334
route 3 depot 101 customers 74 31 92 4 1 65 10 3 33 18 72 57   # L=1424.0415202339
route 4 depot 105 customers 79 80 56 23 0 68 26 29 41 78   # L=940.5929451351
route 5 depot 100 customers 83 81 66 27 93 45 6 25 24 19   # L=867.8329753679
route 6 depot 105 customers 84 62 94 91 37 71 7 16 58 52 11   # L=1114.7763684207
route 7 depot 102 customers 86 35 30 73 38 76 98 43 15 51   # L=796.1914518631
route 8 depot 101 customers 88 21 67 5 20 75 22 87 70 95 55   # L=1335.9490459779
route 9 depot 103 customers 99 44 40 34 96 69 53 14 54   # L=871.1644778957
end
