# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance 50x4-1
instance_file ../LallaRuizVoss_Instances/50x4-1.txt
paper_id lr07
n 50
m 4
k 5
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 8325.9689949800
cost_reported 8325.9689949800
cost_recomputed 8325.9689949800
seed_cost 12896.5019070884
time_seconds 8.950
cycles 2519683
cycle_segments 225172|246657|222291|242628|221388|222062|223841|224025|223000|224469|244150
accepted 13676
epochs 124
perturbations 10
crossovers_used 2519
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 50 customers 3 1 2 13 46 9 39 4 34 21 25 0   # L=2065.3834413810
route 1 depot 50 customers 26 14 11 20 7 36 41 47 48 43 37 29 24   # L=2400.9506956521
route 2 depot 50 customers 28 40 49 8 31 32   # L=812.8278956108
route 3 depot 53 customers 44 35 15 19 33 27 16 30 45 6   # L=1833.7748365425
route 4 depot 53 customers 18 23 10 38 12 22 42 5 17   # L=1213.0321257935
end
