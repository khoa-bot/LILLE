# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..252
format mdktrp-sol-1
instance p10
instance_file ../dat/p10
paper_id p10
n 249
m 4
k 25
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 14032.2930156635
cost_reported 14032.2930156635
cost_recomputed 14032.2930156635
seed_cost 22071.7550704624
time_seconds 18.492
cycles 449713
cycle_segments 22182|26042|22384|87835|45181|32704|60646|44966|20697|58727|28349
accepted 7885
epochs 237
perturbations 10
crossovers_used 434
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 252 customers 3 80 99 144 208 137 20 185 171   # L=453.0410402584
route 1 depot 250 customers 10 240 234 81 223 162 63 124 194 1   # L=513.5480994393
route 2 depot 251 customers 17 29 53 203 197 72 206 165 95 111 212   # L=526.1327639158
route 3 depot 252 customers 27 155 143 191 183 217 244 93 150 246   # L=645.5413973641
route 4 depot 250 customers 55 175 232 135 225 31 77 200 146   # L=504.8237445112
route 5 depot 250 customers 65 112 102 167 46 54 174 16 23 39 126   # L=626.8164978548
route 6 depot 250 customers 79 193 196 41 9 237 12 166 88   # L=502.3586005450
route 7 depot 249 customers 84 221 164 5 36 43 198 207   # L=487.6020682576
route 8 depot 249 customers 91 177 209 40 109 108 19 226 28 59 157   # L=506.8514327865
route 9 depot 252 customers 94 33 181 34 238 118 148 85   # L=415.0612554687
route 10 depot 249 customers 104 131 96 66 50 133 158   # L=442.0519028953
route 11 depot 249 customers 110 235 22 119 21 199 62 179 215 45 151   # L=535.1718610627
route 12 depot 252 customers 114 243 107 69 98 141 67 70 228 0   # L=689.0324542871
route 13 depot 251 customers 123 48 11 210 89 60 129 128 220 204 30   # L=581.2571958296
route 14 depot 250 customers 130 213 56 202 192 100 113 147 25 8 152 247 120 105   # L=870.5916046866
route 15 depot 251 customers 136 172 26 216 182 149 57 229 169   # L=482.0299442593
route 16 depot 252 customers 159 6 163 139 73 103 140 24 245   # L=612.2891793536
route 17 depot 249 customers 173 142 13 97 116 239 106 211 44   # L=489.7164226403
route 18 depot 252 customers 187 86 153 75 154 231 230 201 138   # L=531.7531301597
route 19 depot 251 customers 190 4 132 78 18 184 71 32 233   # L=450.6606970471
route 20 depot 249 customers 195 47 127 178 160 186 92 90 76 49 87   # L=605.2564936342
route 21 depot 250 customers 222 42 121 145 83 134 117 122 2 15   # L=551.4808526264
route 22 depot 250 customers 224 156 248 61 236 176 68 189 7 214 125 115   # L=718.1011010422
route 23 depot 251 customers 227 52 64 205 82 35 219 188   # L=505.4827506768
route 24 depot 250 customers 241 37 38 101 14 218 74 161 58 170 180 168 51 242   # L=785.6405250610
end
