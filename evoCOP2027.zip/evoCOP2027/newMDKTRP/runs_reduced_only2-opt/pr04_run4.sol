# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..191, depots 192..195
format mdktrp-sol-1
instance pr04
instance_file ../dat/pr04
paper_id pr04
n 192
m 4
k 20
fleet reduced
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 7102.2586400172
cost_reported 7102.2586400172
cost_recomputed 7102.2586400172
seed_cost 10859.1815431712
time_seconds 11.223
cycles 412638
cycle_segments 70253|36187|30937|36694|30592|30971|33776|36597|36614|39381|30636
accepted 4422
epochs 147
perturbations 10
crossovers_used 408
early_stop 1
valid 1
note ok
num_routes 20
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 194 customers 26 112 21 68 114 98 170 32 167 35 186   # L=453.2653934840
route 1 depot 194 customers 33 15 138 129 166 108 38 46 161 131 126 158   # L=503.6580490562
route 2 depot 195 customers 43 184 16 91 118 22 119 3 157   # L=335.3091828919
route 3 depot 193 customers 57 177 124 132 106 110 10   # L=253.5820852984
route 4 depot 194 customers 61 92 76 9 97 133 23 63 52 159 51 84   # L=398.6179121374
route 5 depot 192 customers 67 81 103 176 8 31 191 75 180   # L=384.5262948604
route 6 depot 193 customers 78 148 72 107 141 121 56   # L=244.6359270658
route 7 depot 192 customers 147 12 173 130 175 79 94 59 1   # L=357.6054929396
route 8 depot 195 customers 93 40 82 27 83 135 28 5 53 155 60 190 74 125   # L=483.7589368358
route 9 depot 195 customers 111 163 87 150 50 0 85 104 19   # L=416.1916417683
route 10 depot 193 customers 122 187 37 71 73 6 80 149 154   # L=285.4512553187
route 11 depot 195 customers 123 48 62 89 152 188 14 17 153   # L=234.2219426879
route 12 depot 193 customers 136 2 156 144 127 58 128 96 18 54   # L=317.7670863328
route 13 depot 195 customers 143 162 142 100 181 139 30 146 39   # L=316.4927043782
route 14 depot 192 customers 11 151 88 164 64 116 4 34 20   # L=425.4603159543
route 15 depot 195 customers 168 95 25 113 42 101 102 178 165 47   # L=382.2724705831
route 16 depot 193 customers 172 24 109 115 182 45 29 171   # L=371.6414815212
route 17 depot 195 customers 174 7 36 99 77 183 145 86 44 169   # L=337.0157995929
route 18 depot 192 customers 179 160 49 70 120 66 55 41 140 117   # L=388.8581654415
route 19 depot 194 customers 90 185 189 134 105 65 137 13 69   # L=211.9265018687
end
