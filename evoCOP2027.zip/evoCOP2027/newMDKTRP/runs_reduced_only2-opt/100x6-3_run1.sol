# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..105
format mdktrp-sol-1
instance 100x6-3
instance_file ../LallaRuizVoss_Instances/100x6-3.txt
paper_id lr18
n 100
m 6
k 10
fleet reduced
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 9220.7745670027
cost_reported 9220.7745670027
cost_recomputed 9220.7745670027
seed_cost 11956.5550649950
time_seconds 11.857
cycles 1262937
cycle_segments 116663|117834|85647|109904|94462|133902|102244|196164|109954|109976|86187
accepted 9077
epochs 161
perturbations 10
crossovers_used 1262
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 101 customers 19 42 84 74 83 81 11 52   # L=611.3529669572
route 1 depot 102 customers 25 22 58 47 56 99 39 14 67 86   # L=934.1421356237
route 2 depot 102 customers 87 27 97 13 15 41 24 73 57 3 48   # L=1049.4989250920
route 3 depot 100 customers 30 18 65 8 66 45 77 91 94   # L=850.4163056034
route 4 depot 104 customers 32 89 46 80 62 96 26 51 6 16 23 55 60 50   # L=1472.2539674442
route 5 depot 101 customers 34 31 4 10 64 85 28 68 2   # L=792.0380392525
route 6 depot 100 customers 78 36 54 90 93 35 21 79 63 75   # L=868.8772163826
route 7 depot 102 customers 82 49 59 20 33 98 38 76 43 53 72   # L=870.8426344855
route 8 depot 103 customers 88 92 71 69 17 70 0   # L=552.4571558364
route 9 depot 101 customers 95 44 9 40 1 37 61 7 5 29 12   # L=1218.8952203253
end
