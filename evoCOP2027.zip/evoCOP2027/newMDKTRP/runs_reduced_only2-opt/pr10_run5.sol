# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..287, depots 288..293
format mdktrp-sol-1
instance pr10
instance_file ../dat/pr10
paper_id pr10
n 288
m 6
k 29
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 9868.0718031205
cost_reported 9868.0718031205
cost_recomputed 9868.0718031205
seed_cost 14920.4292373538
time_seconds 17.736
cycles 328733
cycle_segments 54905|17455|22058|21938|16307|81167|16222|20570|23539|22107|32465
accepted 4918
epochs 224
perturbations 10
crossovers_used 328
early_stop 1
valid 1
note ok
num_routes 29
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 292 customers 5 15 221 6 58 199 173 281 88   # L=314.8642829290
route 1 depot 293 customers 8 265 47 278 280 237 277 208 115 18 181   # L=419.8256646055
route 2 depot 289 customers 9 156 16 250 191 21 165 17 36 148   # L=290.7598362322
route 3 depot 291 customers 24 113 212 283 268 167 224 286 175   # L=257.4454565918
route 4 depot 292 customers 26 109 242 229 77 40 110 131 101   # L=426.4192589623
route 5 depot 290 customers 28 144 211 90 195 240 38 14 244 223 161   # L=451.4254708747
route 6 depot 292 customers 37 43 87 168 120 236 147 104   # L=299.7467001859
route 7 depot 289 customers 159 117 262 121 243 97 39 50 267 287   # L=209.0083514485
route 8 depot 290 customers 41 150 33 133 19 27 48 204 231 130 45 180   # L=323.8675097578
route 9 depot 290 customers 42 140 274 68 86 93 160 12 22   # L=211.2426114462
route 10 depot 288 customers 46 82 51 163 145 25 54 103 233 106   # L=361.9085242042
route 11 depot 288 customers 61 13 53 122 174 137 279 69   # L=220.2740252128
route 12 depot 292 customers 71 154 241 70 67 55 100 149 249 80 254 73   # L=539.7182517473
route 13 depot 292 customers 78 184 157 151 127 202 89 62 98   # L=275.3167136820
route 14 depot 288 customers 79 49 63 94 23 29 196 186 66 271 216 255   # L=524.5346776123
route 15 depot 293 customers 83 170 143 172 164 187 3   # L=221.3427826280
route 16 depot 291 customers 96 266 65 220 60 201 75 108 114 252 171   # L=300.1478661613
route 17 depot 290 customers 105 138 198 169 177 210 190 129 253 203 10 219 238   # L=462.0819769724
route 18 depot 293 customers 111 264 74 76 183 64 102 188 59   # L=220.2587610073
route 19 depot 291 customers 126 158 282 270 132 11 72 136 44 4 197 193   # L=406.3377811408
route 20 depot 289 customers 178 99 107 275 125 85 34 248   # L=230.2734261554
route 21 depot 291 customers 217 213 185 226 272 135 2 251 119 182   # L=423.4614082276
route 22 depot 291 customers 218 263 225 258 118 179 152 123   # L=211.4960969948
route 23 depot 289 customers 232 273 276 128 200 91 31 139   # L=227.6710710255
route 24 depot 288 customers 245 205 234 228 134 112 194 32 81 209 57   # L=586.5821027636
route 25 depot 291 customers 256 162 246 7 227 215 30 269 230 124 166   # L=425.4430624108
route 26 depot 292 customers 257 1 247 0 20 207 285 214 155 284   # L=273.0078537952
route 27 depot 293 customers 259 92 206 176 192 189 142 260 116 84 222   # L=355.0482758420
route 28 depot 290 customers 261 141 146 239 35 153 235 95 56 52   # L=398.5620025034
end
