# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..9, depots 10..13
format mdktrp-sol-1
instance 10x4-3
instance_file ../LallaRuizVoss_Instances/10x4-3.txt
paper_id lr03
n 10
m 4
k 4
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 846.9142822671
cost_reported 846.9142822671
cost_recomputed 846.9142822671
seed_cost 1196.6870048215
time_seconds 8.591
cycles 24556724
cycle_segments 2209116|2223607|2223638|2232436|2238492|2218333|2244289|2251762|2241519|2236173|2237359
accepted 27515
epochs 121
perturbations 10
crossovers_used 12210
early_stop 1
valid 1
note ok
num_routes 4
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 10 customers 2 4   # L=171.6552506060
route 1 depot 13 customers 0 3   # L=70.0000000000
route 2 depot 12 customers 6 5 8   # L=465.1713615387
route 3 depot 10 customers 9 1 7   # L=140.0876701225
end
