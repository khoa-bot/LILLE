# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..159, depots 160..163
format mdktrp-sol-1
instance p15
instance_file ../dat/p15
paper_id p15
n 160
m 4
k 16
fleet reduced
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 10571.8712626780
cost_reported 10571.8712626780
cost_recomputed 10571.8712626780
seed_cost 13934.5833265496
time_seconds 11.914
cycles 607997
cycle_segments 49455|99599|42136|42824|42492|61847|42107|49461|42375|69454|66247
accepted 6119
epochs 158
perturbations 10
crossovers_used 396
early_stop 1
valid 1
note ok
num_routes 16
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 160 customers 1 2 9 17 25 33 16 24 32   # L=569.5878945012
route 1 depot 160 customers 4 12 20 28 36 155 147 139 131 133 141 149   # L=822.4264068712
route 2 depot 160 customers 6 5 3 0 11 19 27 35 8   # L=496.7661908733
route 3 depot 161 customers 40 48 56 64 72 37 29 21 13   # L=619.8275605730
route 4 depot 161 customers 41 49 57 65 73 38 30 22 14 7 15   # L=672.4264068712
route 5 depot 161 customers 42 50 58 66 74 112 157 39 31 23   # L=728.1118318204
route 6 depot 161 customers 43 45 51 59 67 75 53 61 69 77   # L=712.2119497508
route 7 depot 161 customers 44 52 60 68 76 115 107 99 91 80 88 96 104   # L=951.4213562373
route 8 depot 161 customers 46 47 54 62 70 78 55 63 71 79   # L=712.2119497508
route 9 depot 162 customers 84 82 90 98 106 114 159 151 143   # L=553.5533905933
route 10 depot 162 customers 81 89 97 105 113 158 150 142 134 135   # L=560.0000000000
route 11 depot 162 customers 86 87 92 100 108 116 95 103 111 119   # L=712.2119497508
route 12 depot 162 customers 83 85 94 102 110 118 93 101 109 117   # L=712.2119497508
route 13 depot 163 customers 124 122 129 137 145 153 138 146 154   # L=569.5878945012
route 14 depot 163 customers 121 120 128 136 144 152 34 26 18 10   # L=682.5483399594
route 15 depot 163 customers 123 125 126 127 132 140 148 156 130   # L=496.7661908733
end
