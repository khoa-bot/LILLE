# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance p01
instance_file ../dat/p01
paper_id p01
n 50
m 4
k 5
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 1958.9489248726
cost_reported 1958.9489248726
cost_recomputed 1958.9489248726
seed_cost 2327.7578987594
time_seconds 12.486
cycles 3509499
cycle_segments 220449|526830|322723|282720|304001|346723|242787|326951|304612|387608|244095
accepted 17237
epochs 173
perturbations 10
crossovers_used 3506
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 50 customers 3 16 36 14 43 41 18 40 12 39   # L=394.8305350501
route 1 depot 53 customers 28 20 33 29 9 38 32 44   # L=262.7134197293
route 2 depot 52 customers 8 49 15 1 19 34 35 2 27 30 21   # L=475.0664997838
route 3 depot 51 customers 45 11 46 17 24 13 23 22 6 42   # L=385.1241363247
route 4 depot 52 customers 48 4 37 10 31 0 26 5 47 7 25   # L=441.2143339847
end
