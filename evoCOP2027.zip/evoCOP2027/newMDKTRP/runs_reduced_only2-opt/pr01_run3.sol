# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..47, depots 48..51
format mdktrp-sol-1
instance pr01
instance_file ../dat/pr01
paper_id pr01
n 48
m 4
k 5
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 3036.4308216602
cost_reported 3036.4308216602
cost_recomputed 3036.4308216602
seed_cost 3626.9422155973
time_seconds 8.798
cycles 2674198
cycle_segments 241266|241583|238852|242027|241262|238562|262306|240555|243597|242743|241445
accepted 14396
epochs 122
perturbations 10
crossovers_used 2668
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 51 customers 1 29 14 24 22 25 17 16 39   # L=588.7347385185
route 1 depot 49 customers 9 33 10 44 47 5 2 26 21 6   # L=577.4711076861
route 2 depot 50 customers 15 27 13 0 19 28 4 7 12 32   # L=711.7061585422
route 3 depot 48 customers 36 34 8 31 43 30 35 40 3 18   # L=549.5092733037
route 4 depot 51 customers 38 23 46 11 37 20 42 41 45   # L=609.0095436098
end
