# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance 50x4-3
instance_file ../LallaRuizVoss_Instances/50x4-3.txt
paper_id lr09
n 50
m 4
k 5
fleet reduced
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 7390.9746362785
cost_reported 7390.9746362785
cost_recomputed 7390.9746362785
seed_cost 11484.5838733015
time_seconds 8.950
cycles 2613362
cycle_segments 250046|230712|231390|229933|230637|231176|233401|233935|274749|233253|234130
accepted 19174
epochs 124
perturbations 10
crossovers_used 2613
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 51 customers 3 17 36 23 46 30 9 0   # L=1084.1582905607
route 1 depot 52 customers 6 44 48 7 41 26 39 31 28 19 32 2 42   # L=1946.3196237261
route 2 depot 53 customers 12 11 18 1 10 20 34 35 14 24   # L=1556.8588179356
route 3 depot 51 customers 49 5 40 47 8 4 16 45 25 15 27   # L=1858.5026050574
route 4 depot 52 customers 13 38 21 22 43 29 37 33   # L=945.1352989987
end
