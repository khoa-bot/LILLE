# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..239, depots 240..243
format mdktrp-sol-1
instance pr05
instance_file ../dat/pr05
paper_id pr05
n 240
m 4
k 24
fleet reduced
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 8157.2199965844
cost_reported 8157.2199965844
cost_recomputed 8157.2199965844
seed_cost 12182.9378459687
time_seconds 15.786
cycles 394989
cycle_segments 91786|22076|31984|21882|85298|22995|22990|23140|24986|25032|22820
accepted 6028
epochs 203
perturbations 10
crossovers_used 394
early_stop 1
valid 1
note ok
num_routes 24
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 242 customers 2 9 204 106 12 110 155 52 119 190 166   # L=409.7811968604
route 1 depot 242 customers 4 165 36 82 180 171 194 198   # L=300.1344048405
route 2 depot 242 customers 11 31 8 205 111 184 191 102 185 30   # L=333.5998937275
route 3 depot 243 customers 17 53 152 55 140 164 84 220 239   # L=183.1862535711
route 4 depot 241 customers 29 161 197 76 112 86 96 24 233 68   # L=320.9025906243
route 5 depot 243 customers 35 209 172 64 91 158 21   # L=233.8164729437
route 6 depot 243 customers 42 238 33 121 26 214 46 67 75 97   # L=353.1311773403
route 7 depot 240 customers 74 193 179 18 199 0 15 116   # L=344.7817587378
route 8 depot 240 customers 80 216 101 132 157 153 113   # L=194.9337428605
route 9 depot 240 customers 90 32 130 56 20 47 183 167 103   # L=406.6922546975
route 10 depot 241 customers 131 78 226 104 147 58 114 230 213 124 60 66   # L=300.8347032010
route 11 depot 240 customers 141 202 54 19 234 186 79 176 196 134 27 229 115 81 77   # L=450.1138106734
route 12 depot 243 customers 142 71 122 200 203 13 133 231 146 1 109   # L=329.3404193841
route 13 depot 243 customers 143 162 118 70 49 87 163 154 57 219 85 227   # L=478.4032793617
route 14 depot 242 customers 144 107 117 145 174 137 170 41 151 125   # L=341.0354784901
route 15 depot 240 customers 156 210 14 3 128 50 38 89 93 222 208   # L=356.0208643143
route 16 depot 240 customers 160 188 149 148 225 7 44 40 92   # L=525.1672634377
route 17 depot 242 customers 169 189 65 72 23 73 5 221 218 88 37   # L=511.6145588914
route 18 depot 241 customers 181 136 173 48 207 127 6 94 129   # L=286.4155138300
route 19 depot 240 customers 192 10 123 83 59 223 159 95 43   # L=267.2240528863
route 20 depot 241 customers 211 120 99 212 100 34 150 28 182 187   # L=236.7780254953
route 21 depot 241 customers 224 206 105 63 201 61 135 138 139 235 168   # L=302.9493381584
route 22 depot 243 customers 236 98 178 217 228 126 232 39 215 51   # L=321.9744209485
route 23 depot 243 customers 237 25 195 22 16 62 177 175 108 69 45   # L=368.3885213086
end
