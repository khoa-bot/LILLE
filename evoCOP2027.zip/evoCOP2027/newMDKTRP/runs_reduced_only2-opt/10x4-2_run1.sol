# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..9, depots 10..13
format mdktrp-sol-1
instance 10x4-2
instance_file ../LallaRuizVoss_Instances/10x4-2.txt
paper_id lr02
n 10
m 4
k 4
fleet reduced
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 885.8919774609
cost_reported 885.8919774609
cost_recomputed 885.8919774609
seed_cost 1035.4939051121
time_seconds 8.662
cycles 24596613
cycle_segments 2187102|2223934|2213287|2405352|2223325|2213402|2219868|2229730|2211459|2242520|2226634
accepted 29024
epochs 122
perturbations 10
crossovers_used 12316
early_stop 1
valid 1
note ok
num_routes 4
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 13 customers 8 0   # L=179.8143216520
route 1 depot 11 customers 4 9   # L=153.2780272076
route 2 depot 13 customers 2 5 1   # L=268.8840046122
route 3 depot 13 customers 6 3 7   # L=283.9156239890
end
