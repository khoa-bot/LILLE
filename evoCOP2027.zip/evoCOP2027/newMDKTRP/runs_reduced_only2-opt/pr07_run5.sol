# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..71, depots 72..77
format mdktrp-sol-1
instance pr07
instance_file ../dat/pr07
paper_id pr07
n 72
m 6
k 8
fleet reduced
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 3496.6825004156
cost_reported 3496.6825004156
cost_recomputed 3496.6825004156
seed_cost 4445.2097485558
time_seconds 9.612
cycles 1669368
cycle_segments 275080|139198|139750|139630|139335|139250|139832|139076|139762|139224|139231
accepted 9762
epochs 132
perturbations 10
crossovers_used 1669
early_stop 1
valid 1
note ok
num_routes 8
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 74 customers 7 33 43 21 53 55 2 15 14 44 71 4   # L=592.1400198990
route 1 depot 76 customers 65 47 20 54 3 12 58 50 49   # L=485.1815533310
route 2 depot 76 customers 29 41 18 8 10 69 59 26 9 64 32   # L=542.9578771809
route 3 depot 72 customers 35 30 19 17 70 34 1 37 38   # L=450.0744769391
route 4 depot 73 customers 42 6 48 60 36 57 5   # L=271.7124293320
route 5 depot 75 customers 51 28 52 45 27 62 23 56   # L=360.7531714592
route 6 depot 76 customers 13 66 39 68 61 31 24   # L=329.4635391570
route 7 depot 73 customers 67 11 16 40 46 63 22 25 0   # L=464.3994331173
end
