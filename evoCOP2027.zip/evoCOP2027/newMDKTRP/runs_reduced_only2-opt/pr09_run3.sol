# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..215, depots 216..221
format mdktrp-sol-1
instance pr09
instance_file ../dat/pr09
paper_id pr09
n 216
m 6
k 22
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 7309.0085403699
cost_reported 7309.0085403699
cost_recomputed 7309.0085403699
seed_cost 9967.9273060751
time_seconds 14.101
cycles 425133
cycle_segments 108897|29264|48371|25286|27786|30300|30621|25951|35511|28058|35088
accepted 5771
epochs 183
perturbations 10
crossovers_used 415
early_stop 1
valid 1
note ok
num_routes 22
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 218 customers 3 42 142 0 17 129 19 13 146   # L=384.3410812098
route 1 depot 217 customers 4 206 196 186 126 86 24 6   # L=295.0554172756
route 2 depot 220 customers 50 47 144 133 182 174 88 135 172 131 21 60   # L=367.7287539146
route 3 depot 216 customers 66 58 179 109 63 38 46 78 2 1 102   # L=375.9650369809
route 4 depot 217 customers 72 107 15 120 117 75 188 155 20 34 127 84   # L=451.8196386395
route 5 depot 216 customers 85 171 122 28 100 152 35 57 55   # L=274.2369553917
route 6 depot 220 customers 113 70 115 211 33 184 43 195   # L=272.7994984318
route 7 depot 219 customers 138 145 82 156 183 197 62 27 54 128   # L=332.3295115827
route 8 depot 219 customers 143 36 97 37 98 65 111 212 90   # L=322.8626108032
route 9 depot 218 customers 148 176 134 103 162 198 93 79 114 51 44 105   # L=313.8190416743
route 10 depot 216 customers 149 104 22 119 213 77 116 14 59   # L=367.0909412705
route 11 depot 218 customers 201 10 170 25 11 136 81 185 87 193 167   # L=453.8395509513
route 12 depot 216 customers 166 29 139 118 67 157 132 125 151 208   # L=289.4628175482
route 13 depot 219 customers 150 173 168 12 160 189 215 190 53   # L=275.8713320503
route 14 depot 219 customers 177 191 141 192 99 39 69 158 9   # L=369.6264689124
route 15 depot 221 customers 178 64 18 124 202 165 89 26 209 61   # L=320.1546624926
route 16 depot 220 customers 180 74 154 96 164 95 16 7 49   # L=252.9104604442
route 17 depot 221 customers 187 112 137 163 8 80 41 23   # L=241.2156408493
route 18 depot 220 customers 200 199 73 56 207 48 159 92 194 106   # L=370.3717263687
route 19 depot 221 customers 203 205 153 110 52 175 45 210 91 32 71   # L=326.0575525923
route 20 depot 218 customers 204 40 161 123 5 94 76 31 140   # L=308.9246158794
route 21 depot 220 customers 214 169 130 121 108 147 101 83 30 181 68   # L=342.5252251065
end
