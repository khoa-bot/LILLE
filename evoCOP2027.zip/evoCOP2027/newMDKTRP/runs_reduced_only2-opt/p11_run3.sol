# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..253
format mdktrp-sol-1
instance p11
instance_file ../dat/p11
paper_id p11
n 249
m 5
k 25
fleet reduced
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 14062.2972612888
cost_reported 14062.2972612888
cost_recomputed 14062.2972612888
seed_cost 21011.5396569159
time_seconds 15.216
cycles 364680
cycle_segments 91942|52169|24488|35893|20541|20870|20645|24543|22666|30087|20836
accepted 5617
epochs 195
perturbations 10
crossovers_used 364
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 253 customers 4 132 11 48 123 52 227 64 205   # L=380.5800076827
route 1 depot 250 customers 16 23 39 126 146 158   # L=301.1438033235
route 2 depot 253 customers 18 184 71 20 137 99 144 114 243 107 69 98 208   # L=804.2373154409
route 3 depot 252 customers 26 216 1 169 113 147 25 229 8 152 88 166 12   # L=809.8168836238
route 4 depot 251 customers 34 181 94 33 187 86 153 75 154   # L=553.8287700415
route 5 depot 250 customers 174 54 46 167 65 102 112 79 193 196 41 9 237 130   # L=717.1304983040
route 6 depot 250 customers 77 31 200 66 50 96 131 104   # L=384.1459050627
route 7 depot 253 customers 78 32 233 67 141 231 230 201 138 0   # L=666.2448530002
route 8 depot 249 customers 84 221 164 5 242 15 83 134 145   # L=510.4923113539
route 9 depot 249 customers 91 177 209 40 109 108 19 226 28 59 157 133   # L=647.7420719105
route 10 depot 249 customers 110 235 22 119 21 43 198 24 140 103 73   # L=560.1433818221
route 11 depot 251 customers 143 179 62 215 45 92 186 44 211   # L=450.9544118772
route 12 depot 251 customers 155 27 159 6 163 139 171 185 80 3   # L=766.4787931891
route 13 depot 252 customers 172 82 35 219 149 182 57 188 247 120 105   # L=686.3389846395
route 14 depot 249 customers 173 142 13 97 239 116 106   # L=292.7047507828
route 15 depot 250 customers 55 241 224 240 10 213 56 202 192 100   # L=697.2465801618
route 16 depot 250 customers 175 232 218 14 101 38 121 42 222 37   # L=624.1049687284
route 17 depot 253 customers 190 29 17 136 53 206 165 212 214   # L=433.7057309724
route 18 depot 251 customers 191 183 217 244 49 90 76 87   # L=310.5275280562
route 19 depot 252 customers 194 124 63 223 162 68 176 236 61 248 156 81 234   # L=845.2235595543
route 20 depot 249 customers 195 47 127 160 178 199 151 207 245   # L=467.4008162142
route 21 depot 252 customers 203 197 72 95 111 189 7 122 117 2 115 125   # L=680.2680828088
route 22 depot 253 customers 210 89 60 129 128 220 204 30 70 228   # L=613.9710589951
route 23 depot 250 customers 225 135 74 161 58 170 180 168 51 36   # L=566.7023879224
route 24 depot 251 customers 238 118 93 150 85 148 246   # L=291.1638058208
end
