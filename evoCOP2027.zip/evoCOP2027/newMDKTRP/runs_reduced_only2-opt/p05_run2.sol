# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..101
format mdktrp-sol-1
instance p05
instance_file ../dat/p05
paper_id p05
n 100
m 2
k 10
fleet reduced
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 3103.2591845397
cost_reported 3103.2591845397
cost_recomputed 3103.2591845397
seed_cost 3641.7825079346
time_seconds 11.194
cycles 1144380
cycle_segments 89969|120000|82753|90423|157197|97518|97745|112070|129831|83956|82918
accepted 9850
epochs 152
perturbations 10
crossovers_used 1144
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 4 92 97 36 99 90 84 60 15 85 43 13 37   # L=388.4881845185
route 1 depot 101 customers 11 25 39 20 72 71 73 21 40 3   # L=303.4966830529
route 2 depot 100 customers 17 88 5 93 12 57 52 27 26 51   # L=325.1674506307
route 3 depot 101 customers 23 28 77 33 34 70 64   # L=238.9340945033
route 4 depot 101 customers 53 54 24 38 55 74 22 66   # L=248.1365051208
route 5 depot 100 customers 59 95 98 58 91 94 96 86 1 56 14 42 41   # L=378.8141617867
route 6 depot 101 customers 75 49 0 68 30 87 6 61 9   # L=299.3999350259
route 7 depot 101 customers 79 67 76 2 78 32 80 8 50 19 29 69   # L=308.3287427013
route 8 depot 100 customers 82 7 81 47 18 10 62 89 31 65   # L=330.1842873962
route 9 depot 100 customers 83 16 44 45 46 35 48 63   # L=282.3091398033
end
