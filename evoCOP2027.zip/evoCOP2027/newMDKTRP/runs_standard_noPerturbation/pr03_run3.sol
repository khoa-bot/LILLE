# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..143, depots 144..147
format mdktrp-sol-1
instance pr03
instance_file ../dat/pr03
paper_id pr03
n 144
m 4
k 35
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 4464.4742016053
cost_reported 4464.4742016053
cost_recomputed 4464.4742016053
seed_cost 6071.6119936536
time_seconds 3.822
cycles 197903
cycle_segments 108090|89813
accepted 1840
epochs 51
perturbations 1
crossovers_used 197
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 146 customers 1 63 136 8   # L=126.4753043932
route 1 depot 145 customers 3 5 125 53 97 48   # L=292.0227265242
route 2 depot 145 customers 7 55 124 110 60 35 56   # L=339.2354178120
route 3 depot 144 customers 13 126 87 51   # L=146.3364641646
route 4 depot 147 customers 15 64 92 75 115   # L=228.5678143193
route 5 depot 144 customers 16 79 2 120 39   # L=131.7222477496
route 6 depot 147 customers 17 122 127 32 119   # L=142.2939462256
route 7 depot 147 customers 20 65 89 6   # L=122.4605089966
route 8 depot 146 customers 22 121 80 31   # L=84.1993907448
route 9 depot 145 customers 23 69 78 71   # L=115.5139691056
route 10 depot 144 customers 25 94 0 12 109   # L=114.2197653112
route 11 depot 145 customers 36 18 140 73   # L=143.4301526521
route 12 depot 144 customers 38 70 26 113   # L=126.1326764972
route 13 depot 146 customers 41 30   # L=63.6556735668
route 14 depot 147 customers 42 103 21 57 67 24   # L=127.4718984832
route 15 depot 146 customers 43 37 19 102   # L=142.5950030939
route 16 depot 146 customers 47 96 76   # L=78.2139197954
route 17 depot 145 customers 50 45 107   # L=65.6198677127
route 18 depot 144 customers 61 138 131 118 68   # L=158.1226250723
route 19 depot 147 customers 62 27 4   # L=62.2520864214
route 20 depot 145 customers 74 54   # L=76.9859046214
route 21 depot 145 customers 114 82 33   # L=96.7605160418
route 22 depot 147 customers 85 28 81 58   # L=122.5797060241
route 23 depot 144 customers 90 44 86 77   # L=50.5831289650
route 24 depot 147 customers 91 142 14 40 83   # L=79.9860030313
route 25 depot 146 customers 93 101 133 29   # L=121.4836312836
route 26 depot 147 customers 105 137 95 52   # L=115.5697016219
route 27 depot 144 customers 108 106 10 34   # L=72.5646268938
route 28 depot 145 customers 116 66 84   # L=125.4251553383
route 29 depot 146 customers 123 112 135 59 46   # L=175.3383585605
route 30 depot 144 customers 128 11 111   # L=83.9259279664
route 31 depot 146 customers 129 98 143 117   # L=88.5110971296
route 32 depot 144 customers 132 72 9 49   # L=118.0816179691
route 33 depot 145 customers 134 104 100 99   # L=127.3385363712
route 34 depot 146 customers 141 130 139 88   # L=198.7988311459
end
