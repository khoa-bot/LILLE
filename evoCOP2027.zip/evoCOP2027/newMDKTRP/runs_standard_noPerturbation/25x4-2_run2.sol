# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..24, depots 25..28
format mdktrp-sol-1
instance 25x4-2
instance_file ../LallaRuizVoss_Instances/25x4-2.txt
paper_id lr05
n 25
m 4
k 10
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 1827.4112081364
cost_reported 1827.4112081364
cost_recomputed 1827.4112081364
seed_cost 2388.9926652829
time_seconds 1.572
cycles 1133287
cycle_segments 563718|569569
accepted 5434
epochs 22
perturbations 1
crossovers_used 1133
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 25 customers 15 1 3   # L=259.5391279027
route 1 depot 25 customers 13 19   # L=175.0673269191
route 2 depot 25 customers 5 11 9   # L=220.3083672582
route 3 depot 25 customers 14 7   # L=223.0261402359
route 4 depot 26 customers 8 2 23 0   # L=343.5483716106
route 5 depot 26 customers 4 17 21   # L=146.0555127546
route 6 depot 26 customers 12 20 6   # L=220.9336873963
route 7 depot 26 customers 10 22   # L=62.4264068712
route 8 depot 27 customers 16 18   # L=135.2752109314
route 9 depot 28 customers 24   # L=41.2310562562
end
