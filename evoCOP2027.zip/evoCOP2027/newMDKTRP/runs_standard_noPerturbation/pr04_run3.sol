# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..191, depots 192..195
format mdktrp-sol-1
instance pr04
instance_file ../dat/pr04
paper_id pr04
n 192
m 4
k 35
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 5812.6137309581
cost_reported 5812.6137309581
cost_recomputed 5812.6137309581
seed_cost 8627.6151271197
time_seconds 1.833
cycles 61621
cycle_segments 30697|30924
accepted 849
epochs 24
perturbations 1
crossovers_used 61
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 193 customers 136 2 144 156 37   # L=68.4431225247
route 1 depot 195 customers 7 36 91 86 44 169   # L=158.9020343276
route 2 depot 192 customers 11 88 116 4 34   # L=212.1261860315
route 3 depot 194 customers 15 138 129 166 108 18 158   # L=219.2439867223
route 4 depot 193 customers 24 141 182 45 171   # L=240.9414229196
route 5 depot 194 customers 26 112 68 21   # L=72.2307107612
route 6 depot 194 customers 33 38 46 161 131 84 126   # L=272.7447073902
route 7 depot 195 customers 43 184 16 118 22 3 157   # L=216.9280891826
route 8 depot 195 customers 48 62 89 17   # L=64.0352467285
route 9 depot 195 customers 50 119 85 19   # L=226.9146672532
route 10 depot 193 customers 57 127 58 128 96 54   # L=182.8562290300
route 11 depot 194 customers 61 76 9 97 35 186   # L=108.9446474723
route 12 depot 192 customers 67 70 176 8 140   # L=129.8504078275
route 13 depot 193 customers 78 148 72 107 121 56   # L=185.8340840359
route 14 depot 192 customers 81 103 31 180   # L=145.7491430189
route 15 depot 195 customers 82 83 135 60 125 117   # L=240.6931071559
route 16 depot 194 customers 90 185 134 65 105 137   # L=85.7827891640
route 17 depot 194 customers 92 133 23 63 52 159 51   # L=211.3206285309
route 18 depot 195 customers 93 40 5 28 53 155 190 74   # L=198.1964385478
route 19 depot 193 customers 109 115 29   # L=128.9355849431
route 20 depot 195 customers 111 163 87 150 139 30 146 39   # L=302.8937205210
route 21 depot 193 customers 122 187 71 73 154   # L=94.3044503096
route 22 depot 195 customers 123 27 152 188 14   # L=93.5910747505
route 23 depot 193 customers 124 10   # L=62.1019871563
route 24 depot 195 customers 143 170 32 167   # L=95.7463333114
route 25 depot 192 customers 147 12 173 130 175 79 94   # L=219.6954241352
route 26 depot 192 customers 151 164 64 191 75 20   # L=293.4824110905
route 27 depot 192 customers 153 114 98   # L=56.2888968238
route 28 depot 195 customers 162 142 100 181 0 104   # L=211.6842750469
route 29 depot 195 customers 168 95 25 113 42 101 178 165   # L=242.9049904511
route 30 depot 193 customers 172 6 80 149 59 1   # L=206.3962510623
route 31 depot 195 customers 174 99 77 183 145 102 47   # L=222.4176492917
route 32 depot 193 customers 177 132 106 110   # L=108.6888703967
route 33 depot 192 customers 179 160 49 120 66 55 41   # L=175.2027503419
route 34 depot 194 customers 189 13 69   # L=56.5414127016
end
