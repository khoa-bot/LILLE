# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..101
format mdktrp-sol-1
instance p05
instance_file ../dat/p05
paper_id p05
n 100
m 2
k 35
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 1982.3312951773
cost_reported 1982.3312951773
cost_recomputed 1982.3312951773
seed_cost 2535.1793460781
time_seconds 3.682
cycles 313817
cycle_segments 182365|131452
accepted 2818
epochs 50
perturbations 1
crossovers_used 313
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 101 customers 2 32 65   # L=65.9377781050
route 1 depot 101 customers 3 55 22   # L=68.7725323918
route 2 depot 100 customers 4 84 90 13   # L=59.5113285652
route 3 depot 100 customers 6 61 62   # L=76.7244629735
route 4 depot 101 customers 11 27 52   # L=40.6501914655
route 5 depot 100 customers 16   # L=11.1803398875
route 6 depot 100 customers 17 51 30   # L=46.2936074491
route 7 depot 101 customers 20 72   # L=39.2177904148
route 8 depot 101 customers 23   # L=10.0000000000
route 9 depot 101 customers 25 39 57   # L=51.8062609118
route 10 depot 101 customers 28 33   # L=35.8419133124
route 11 depot 100 customers 44 45   # L=29.7439955753
route 12 depot 100 customers 46 48   # L=56.4374123030
route 13 depot 100 customers 81 10   # L=42.6815416923
route 14 depot 101 customers 49 29 31   # L=83.0918915670
route 15 depot 101 customers 53 38   # L=29.9117871423
route 16 depot 101 customers 54 24 66   # L=65.6104638069
route 17 depot 100 customers 59 5 93 12 1   # L=74.8225135501
route 18 depot 100 customers 60 15 43 37   # L=82.0056037560
route 19 depot 101 customers 67 78 80 8 70   # L=96.0569458929
route 20 depot 101 customers 68   # L=21.6333076528
route 21 depot 101 customers 71 73 21 40   # L=102.5161415003
route 22 depot 101 customers 74   # L=24.7386337537
route 23 depot 101 customers 75 0 69   # L=56.9811827456
route 24 depot 101 customers 76 50 19   # L=63.8492408945
route 25 depot 101 customers 79 77 34 64   # L=94.7259242672
route 26 depot 100 customers 47 18 63   # L=84.8441508083
route 27 depot 100 customers 82 7 35   # L=39.9187032624
route 28 depot 100 customers 83 85   # L=26.0785315592
route 29 depot 100 customers 87 9 89   # L=85.7049818258
route 30 depot 100 customers 88 26   # L=32.2956301410
route 31 depot 100 customers 92 97 36 41 14   # L=101.0086108600
route 32 depot 100 customers 95 94 86 56   # L=75.8760157282
route 33 depot 100 customers 98 58 91 96   # L=55.5251381116
route 34 depot 100 customers 99 42   # L=50.3367413041
end
