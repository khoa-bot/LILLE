# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..287, depots 288..291
format mdktrp-sol-1
instance pr06
instance_file ../dat/pr06
paper_id pr06
n 288
m 4
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 8703.2000961961
cost_reported 8703.2000961961
cost_recomputed 8703.2000961961
seed_cost 12156.6881126404
time_seconds 4.751
cycles 79148
cycle_segments 63235|15913
accepted 1505
epochs 60
perturbations 1
crossovers_used 79
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 290 customers 18 75 13 115 90 285 158 79 67 41   # L=419.3165963735
route 1 depot 291 customers 22 56 61 169 182 154 238 93   # L=207.4609108426
route 2 depot 289 customers 37 14 170 4 26 84 70   # L=238.8468375600
route 3 depot 288 customers 38 276 27 272 260 149 19   # L=186.9641671531
route 4 depot 291 customers 39 208 17 81 202 226   # L=129.0785256092
route 5 depot 289 customers 216 283 259 78 30 31 156   # L=237.9532740966
route 6 depot 291 customers 63 236 95 125 49 205 6   # L=159.0451423125
route 7 depot 288 customers 76 71 68 7 89 130 111 168   # L=238.2177994000
route 8 depot 290 customers 80 166 32 11 200 131 270 213 5   # L=313.7908926648
route 9 depot 290 customers 83 121 142 196 286 33 148 211   # L=277.4793988712
route 10 depot 288 customers 85 159 217 184 250 24 103 58 135 118   # L=373.7918594118
route 11 depot 290 customers 86 73 136 77 215 242   # L=160.2000497651
route 12 depot 290 customers 97 194 128 195 161 0 153 191 36 140   # L=318.9173311488
route 13 depot 289 customers 99 2 172 261 282 114 69 157   # L=303.4257375080
route 14 depot 290 customers 105 227 138 214 181 29 120 127 277 229 123   # L=266.0082921542
route 15 depot 289 customers 134 287 279 143 50 9 55 225   # L=333.2730535185
route 16 depot 291 customers 150 249 112 12 233 96 206 177   # L=254.6429235172
route 17 depot 289 customers 155 241 230 254 268 253 151 47 42   # L=253.7069439800
route 18 depot 289 customers 244 53 52 232 3 91   # L=153.9822693647
route 19 depot 290 customers 174 269 278 137 228 209 129 87 218   # L=255.0038290632
route 20 depot 289 customers 176 65 113 147 197 60   # L=98.2833200015
route 21 depot 289 customers 178 110 108 152 246 66 48 183   # L=139.9416171275
route 22 depot 288 customers 179 117 175 267 57 100   # L=112.3670778941
route 23 depot 291 customers 180 210 144 82 167 124 189 252   # L=124.2863735641
route 24 depot 291 customers 190 106 222 235 15 237 28 35 122 25   # L=289.6501468119
route 25 depot 291 customers 231 132 187 248 126 98 54 94   # L=204.7153770269
route 26 depot 289 customers 220 16 145 203 234 221 88 239   # L=261.9533335115
route 27 depot 290 customers 245 162 46 107 20 44 21 160 163 92   # L=312.8654806654
route 28 depot 290 customers 251 101 266 165 45 240 51 258 224 198 188 8   # L=350.5367308416
route 29 depot 288 customers 263 171 59 199 104 102 204   # L=198.4460866194
route 30 depot 288 customers 264 219 193 255 275 40 139 212 146 247 109 274   # L=501.1674596308
route 31 depot 291 customers 273 64 1 72 173 62 207 133 243   # L=269.3611463460
route 32 depot 288 customers 280 10 116 119 185 262   # L=155.8088442435
route 33 depot 289 customers 281 271 74 201 164 186 34 192 256 23   # L=340.1435290566
route 34 depot 288 customers 284 43 223 265 257 141   # L=262.5677385404
end
