# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..250
format mdktrp-sol-1
instance p08
instance_file ../dat/p08
paper_id p08
n 249
m 2
k 35
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 15378.6846010516
cost_reported 15378.6846010516
cost_recomputed 15378.6846010516
seed_cost 24434.4449306028
time_seconds 3.902
cycles 84806
cycle_segments 65891|18915
accepted 1671
epochs 50
perturbations 1
crossovers_used 84
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 249 customers 1 57 182 149 35 219   # L=312.6744542307
route 1 depot 250 customers 6 163 80 99 144 208 98 201   # L=595.6136969894
route 2 depot 250 customers 21 119 235 22 47 195 173 106   # L=353.7759221701
route 3 depot 250 customers 24 140 103 73 214 125 115   # L=306.6034646092
route 4 depot 249 customers 26 172 136 123 52   # L=275.1538672911
route 5 depot 250 customers 27 94 187 153 75 154   # L=452.4159426904
route 6 depot 250 customers 36 164 168 180 170 66 50   # L=474.7014095929
route 7 depot 249 customers 53 17 11 48 129 128   # L=397.9297628203
route 8 depot 249 customers 61 121 38 232 175 135 225 77 200 146   # L=721.0268682954
route 9 depot 250 customers 62 215 45 90 76 49 87 246   # L=413.2947120425
route 10 depot 249 customers 63 192 100 12 166 88   # L=285.8764002960
route 11 depot 249 customers 68 134 83 51 161 58   # L=306.9661925822
route 12 depot 249 customers 72 197 206 78 204 30 70 228 0   # L=814.7680421053
route 13 depot 249 customers 223 81 234 240 10 9 196 193 79 112 102   # L=615.9869794224
route 14 depot 249 customers 95 165 18 184 71 32 233   # L=453.9487536008
route 15 depot 250 customers 110 91 177 209 40 109 59 157   # L=664.1000678015
route 16 depot 249 customers 122 117 2 15 242 5   # L=305.1419437850
route 17 depot 249 customers 124 113 147 25 8 152 247 120   # L=377.8104974611
route 18 depot 250 customers 127 142 13 97 239 116   # L=348.3874145648
route 19 depot 250 customers 151 143 191 183 217 118 238 34   # L=425.8256891197
route 20 depot 250 customers 155 181 33 86   # L=235.9917230750
route 21 depot 249 customers 248 42 222 37 174 23 39 126   # L=572.7957502550
route 22 depot 249 customers 169 229 188 105   # L=229.2172100726
route 23 depot 249 customers 176 236 145 101 14 218 74 31   # L=428.9532969149
route 24 depot 250 customers 179 244 93 150 85 148   # L=391.9983302849
route 25 depot 249 customers 189 7 111 212   # L=154.4815034259
route 26 depot 249 customers 194 216 82 205 64 227   # L=319.4035888656
route 27 depot 250 customers 198 43 104 226 19 108 28   # L=451.5168532056
route 28 depot 250 customers 199 178 160 92 186 44 211   # L=277.2977378535
route 29 depot 249 customers 202 56 213 130 237 41   # L=317.9319744142
route 30 depot 249 customers 203 29 190 4 132 210 89 60 220   # L=616.1383681926
route 31 depot 250 customers 207 159 3 114 243 107 69 231 230 138   # L=804.0804340789
route 32 depot 250 customers 221 84 131 96 133 158   # L=496.0108846838
route 33 depot 249 customers 162 156 224 241 55 65 167 46 54 16   # L=620.5675306538
route 34 depot 250 customers 245 139 171 185 20 137 141 67   # L=560.2973336044
end
