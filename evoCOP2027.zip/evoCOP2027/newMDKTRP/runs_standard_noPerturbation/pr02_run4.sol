# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..95, depots 96..99
format mdktrp-sol-1
instance pr02
instance_file ../dat/pr02
paper_id pr02
n 96
m 4
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 2572.8361411463
cost_reported 2572.8361411463
cost_recomputed 2572.8361411463
seed_cost 3147.4413619915
time_seconds 2.500
cycles 226209
cycle_segments 114050|112159
accepted 2867
epochs 34
perturbations 1
crossovers_used 226
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 98 customers 1 79 23   # L=66.9045354118
route 1 depot 97 customers 6   # L=69.0150270666
route 2 depot 96 customers 8 68   # L=48.7972759611
route 3 depot 98 customers 9 47 5   # L=99.9963257701
route 4 depot 99 customers 10 20 45 14   # L=72.8615358357
route 5 depot 98 customers 17 50 49   # L=95.1425281432
route 6 depot 96 customers 18 73 91 26   # L=174.9079983439
route 7 depot 96 customers 24 71 59   # L=47.1483921672
route 8 depot 99 customers 25 22 74   # L=110.8280207945
route 9 depot 99 customers 27 56   # L=22.0893207418
route 10 depot 97 customers 31 86   # L=35.6709785519
route 11 depot 97 customers 32 46 64   # L=39.3857998258
route 12 depot 99 customers 34 48   # L=69.0545749590
route 13 depot 98 customers 35 52   # L=56.6424865371
route 14 depot 97 customers 41 21 84   # L=48.9330209828
route 15 depot 99 customers 44 30 33   # L=86.6430506781
route 16 depot 99 customers 53 28 94   # L=43.4493143521
route 17 depot 96 customers 54 19 38   # L=160.0391654337
route 18 depot 98 customers 55 65 70   # L=43.1738049955
route 19 depot 99 customers 57   # L=9.0240227172
route 20 depot 96 customers 58 69 40   # L=50.5181216285
route 21 depot 96 customers 61 43 15   # L=70.9647363617
route 22 depot 98 customers 66 13 75   # L=69.3509736239
route 23 depot 96 customers 72 36 16 63   # L=93.0812583266
route 24 depot 97 customers 77 87 0   # L=24.3864845885
route 25 depot 99 customers 78 81 39   # L=82.1533766899
route 26 depot 96 customers 80 92 37 67   # L=145.0532970737
route 27 depot 96 customers 83 42 12   # L=117.7286876378
route 28 depot 99 customers 3   # L=28.7418197406
route 29 depot 96 customers 85 7   # L=116.5592674321
route 30 depot 99 customers 88 51 60 62   # L=64.5943239262
route 31 depot 99 customers 89 76   # L=49.4765614998
route 32 depot 99 customers 90 29 82   # L=97.6175957740
route 33 depot 97 customers 93 4   # L=89.5338307339
route 34 depot 98 customers 95 11 2   # L=73.3686268403
end
