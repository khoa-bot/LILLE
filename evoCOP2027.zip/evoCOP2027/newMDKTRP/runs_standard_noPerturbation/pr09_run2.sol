# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..215, depots 216..221
format mdktrp-sol-1
instance pr09
instance_file ../dat/pr09
paper_id pr09
n 216
m 6
k 35
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 5898.8523064533
cost_reported 5898.8523064533
cost_recomputed 5898.8523064533
seed_cost 8311.6742896950
time_seconds 2.697
cycles 74457
cycle_segments 27348|47109
accepted 1390
epochs 35
perturbations 1
crossovers_used 74
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 218 customers 3 42 142 0 17 140 13 146   # L=298.3879347792
route 1 depot 217 customers 4 147 101 83 30 181 68   # L=250.1115932106
route 2 depot 219 customers 36 37 98 65 111 212 90   # L=285.8617645744
route 3 depot 220 customers 50 47 144 133 182 174 88 135 172 131   # L=215.3865269223
route 4 depot 221 customers 64 52 175 45 210 32 71   # L=206.9675197646
route 5 depot 216 customers 66 58 63 38 77 116 14 59   # L=282.9905454114
route 6 depot 217 customers 72 107 15 120 117 84 6   # L=188.3186369915
route 7 depot 216 customers 189 168 12 160 100   # L=87.3301698991
route 8 depot 220 customers 113 70 211 33 21   # L=127.6603771083
route 9 depot 218 customers 123 208 87 193 167   # L=200.1110103948
route 10 depot 219 customers 138 145 132 125 197 62   # L=104.9754376650
route 11 depot 219 customers 141 192 209 61   # L=119.5804737086
route 12 depot 219 customers 143 97 99 39 69 158 9   # L=246.8239298794
route 13 depot 218 customers 176 134 103 162 198 93 44 105   # L=173.3011365590
route 14 depot 216 customers 149 104 22 119 213 129 19   # L=210.7946074014
route 15 depot 218 customers 148 151 114 79 51   # L=90.5714044547
route 16 depot 220 customers 154 95 7 16   # L=110.4249238450
route 17 depot 217 customers 155 188 75 34 127   # L=161.4705275479
route 18 depot 219 customers 156 82 183 27 54 128   # L=210.5761745707
route 19 depot 216 customers 85 28 152 41 23   # L=122.7987920737
route 20 depot 216 customers 171 122 35 57 55   # L=140.1911403795
route 21 depot 219 customers 150 173 190 215   # L=78.7863761889
route 22 depot 219 customers 177 191 89 26   # L=87.0509970133
route 23 depot 221 customers 178 18 124 202 165 53   # L=115.9972692920
route 24 depot 216 customers 179 109 46 78 2 1 102   # L=256.7119660716
route 25 depot 220 customers 180 74 115 43 184 195 60   # L=226.4592015517
route 26 depot 221 customers 187 112 163 8 80 137   # L=116.2240826984
route 27 depot 220 customers 199 73 56 207 92 194   # L=178.3218919685
route 28 depot 220 customers 200 96 164 49 48 159 106   # L=195.0799719889
route 29 depot 216 customers 166 29 139 118 67 157   # L=95.6042208102
route 30 depot 221 customers 203 205 153 110 86 91 24   # L=146.6928549310
route 31 depot 218 customers 204 40 161 5 94 76 31   # L=200.4686375353
route 32 depot 217 customers 206 196 186 126   # L=56.1733549707
route 33 depot 218 customers 201 10 170 25 11 136 81 185   # L=227.1565853468
route 34 depot 220 customers 214 169 130 121 108 20   # L=83.4902689446
end
