# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance 50x4-2
instance_file ../LallaRuizVoss_Instances/50x4-2.txt
paper_id lr08
n 50
m 4
k 20
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 3737.3814388336
cost_reported 3737.3814388336
cost_recomputed 3737.3814388336
seed_cost 4958.4294853730
time_seconds 1.877
cycles 463686
cycle_segments 268009|195677
accepted 2886
epochs 26
perturbations 1
crossovers_used 463
early_stop 1
valid 1
note ok
num_routes 20
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 51 customers 35 36 34 5   # L=320.0000000000
route 1 depot 50 customers 33 12 18   # L=163.0056307975
route 2 depot 50 customers 24 27 4 8   # L=411.9787391199
route 3 depot 50 customers 42 2 46   # L=373.6257339320
route 4 depot 53 customers 9   # L=31.6227766017
route 5 depot 50 customers 49   # L=133.4166406413
route 6 depot 53 customers 25 32 43 20 45   # L=338.1741100487
route 7 depot 50 customers 11 23 1   # L=336.2277660168
route 8 depot 50 customers 17 15 16   # L=219.9699371389
route 9 depot 51 customers 29 19   # L=146.4911064067
route 10 depot 52 customers 31   # L=14.1421356237
route 11 depot 52 customers 13 38   # L=91.5298244508
route 12 depot 51 customers 26 44   # L=104.8227922874
route 13 depot 50 customers 21 28   # L=221.8702700423
route 14 depot 52 customers 14 30   # L=64.7213595500
route 15 depot 53 customers 0   # L=50.0000000000
route 16 depot 53 customers 10 41   # L=122.3606797750
route 17 depot 51 customers 7 48 37   # L=90.0000000000
route 18 depot 52 customers 39 6   # L=94.7213595500
route 19 depot 50 customers 40 47 22 3   # L=408.7005768509
end
