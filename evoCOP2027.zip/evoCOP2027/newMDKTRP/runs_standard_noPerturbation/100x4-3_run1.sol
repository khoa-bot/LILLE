# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance 100x4-3
instance_file ../LallaRuizVoss_Instances/100x4-3.txt
paper_id lr15
n 100
m 4
k 25
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 8625.1308712875
cost_reported 8625.1308712875
cost_recomputed 8625.1308712875
seed_cost 10626.8590007083
time_seconds 1.694
cycles 146317
cycle_segments 76481|69836
accepted 1691
epochs 23
perturbations 1
crossovers_used 146
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 103 customers 60 50 88 72 23   # L=304.1421356237
route 1 depot 103 customers 15 86   # L=94.8683298051
route 2 depot 100 customers 21 66 94 4 9   # L=460.2191243148
route 3 depot 102 customers 62 16 99   # L=401.9787391199
route 4 depot 101 customers 27 75 30 95   # L=338.5513763685
route 5 depot 103 customers 32 20 10   # L=131.8033988750
route 6 depot 103 customers 42 31   # L=152.6745506515
route 7 depot 102 customers 44 56 25 53 67 41 84 17 87 90 57 98   # L=930.0000000000
route 8 depot 100 customers 45 68 77 93   # L=538.4169147420
route 9 depot 100 customers 47 81 8 78 92 33 34 28   # L=1032.3721607270
route 10 depot 101 customers 48 38   # L=85.9524158062
route 11 depot 100 customers 51 11 37 35   # L=276.0332046212
route 12 depot 102 customers 14 79 59 49   # L=598.7434199508
route 13 depot 100 customers 12 40   # L=111.6227766017
route 14 depot 102 customers 65 43 96 63 0   # L=330.3067944373
route 15 depot 103 customers 36 2 19   # L=288.3096672314
route 16 depot 102 customers 74 6 80 39   # L=318.0908895362
route 17 depot 102 customers 58 52 1 7   # L=319.4427191000
route 18 depot 100 customers 69 5 61 85 83   # L=652.4753936404
route 19 depot 101 customers 24 64 18   # L=254.5584412272
route 20 depot 103 customers 73 46   # L=130.0639759177
route 21 depot 102 customers 26   # L=20.0000000000
route 22 depot 100 customers 55 70 82 76   # L=448.3617272026
route 23 depot 103 customers 91 13 89 3 29 22   # L=291.4213562373
route 24 depot 102 customers 97 54 71   # L=114.7213595500
end
