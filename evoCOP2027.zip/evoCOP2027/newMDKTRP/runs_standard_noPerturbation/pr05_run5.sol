# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..239, depots 240..243
format mdktrp-sol-1
instance pr05
instance_file ../dat/pr05
paper_id pr05
n 240
m 4
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 7145.0934368346
cost_reported 7145.0934368346
cost_recomputed 7145.0934368346
seed_cost 9712.2490054647
time_seconds 3.266
cycles 75324
cycle_segments 48265|27059
accepted 1397
epochs 42
perturbations 1
crossovers_used 75
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 242 customers 2 106 12 110 155 41 151 125   # L=254.5304770392
route 1 depot 242 customers 4 165 36 82 180 194   # L=155.5002827877
route 2 depot 242 customers 9 204 52 119 190 166   # L=261.8556694182
route 3 depot 242 customers 11 205 184 191 221 218 88 37   # L=387.9341439344
route 4 depot 243 customers 17 53 152 55 140 164 84   # L=92.6557566191
route 5 depot 243 customers 98 178 217 228 126 232 215   # L=177.6572202113
route 6 depot 241 customers 29 161 105 63 201 197 76 112 24 233   # L=211.2359413073
route 7 depot 242 customers 31 8 65 72 23 73 5 198 40 92   # L=445.8954461029
route 8 depot 243 customers 35 209 172 64 158   # L=115.9132316378
route 9 depot 243 customers 42 238 33 231 1 146 67 75 97   # L=316.6136233522
route 10 depot 243 customers 66 91 57 219 85 227   # L=263.2798435391
route 11 depot 240 customers 74 193 179 18 199 0 15 116   # L=344.7817587378
route 12 depot 240 customers 80 216 101 132 60   # L=86.9318106947
route 13 depot 240 customers 192 83 159 20 47 183 167   # L=255.3980226671
route 14 depot 242 customers 111 102 185 30   # L=179.9476967310
route 15 depot 242 customers 117 145 61 135 138 139 168   # L=187.6829788356
route 16 depot 243 customers 118 70 49 87 163 154   # L=160.6512857389
route 17 depot 240 customers 90 32 130 56 113   # L=129.8526928008
route 18 depot 241 customers 131 78 226 104 147 58 114 213 124   # L=170.6970381256
route 19 depot 240 customers 141 19 79 234 186 28 150   # L=106.4660231995
route 20 depot 243 customers 142 71 122 200 203 13 133 129 94   # L=225.9703359086
route 21 depot 243 customers 143 162 62 177 175 108 69 45   # L=272.0793452299
route 22 depot 242 customers 144 107 174 137 170 235   # L=149.3561119549
route 23 depot 240 customers 156 153 50 38 93 222 208   # L=229.5605383959
route 24 depot 240 customers 157 210 14 3 128 89 21   # L=173.9040028199
route 25 depot 240 customers 160 149 148 43   # L=121.5853125812
route 26 depot 242 customers 169 189 171 81 7 44 77   # L=344.6329940501
route 27 depot 241 customers 181 136 173 48 86 96 68   # L=200.0873856192
route 28 depot 240 customers 10 123 188 59 223 95 103   # L=207.6484636332
route 29 depot 240 customers 202 54 176 196 134 27 229 115 225   # L=235.8214210364
route 30 depot 241 customers 211 212 187 182 230   # L=83.8875909479
route 31 depot 243 customers 220 239 207 127 6   # L=135.2396415391
route 32 depot 241 customers 224 206 120 99 100 34   # L=75.6738975918
route 33 depot 243 customers 236 121 26 214 46 109   # L=193.9845361558
route 34 depot 243 customers 237 25 22 16 195 39 51   # L=190.1809158904
end
