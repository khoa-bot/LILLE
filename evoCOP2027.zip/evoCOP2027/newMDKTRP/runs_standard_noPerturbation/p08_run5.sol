# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..250
format mdktrp-sol-1
instance p08
instance_file ../dat/p08
paper_id p08
n 249
m 2
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 15414.8919309615
cost_reported 15414.8919309615
cost_recomputed 15414.8919309615
seed_cost 24434.4449306028
time_seconds 3.121
cycles 67432
cycle_segments 30303|37129
accepted 949
epochs 40
perturbations 1
crossovers_used 67
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 249 customers 1 57 182 149 35 219   # L=312.6744542307
route 1 depot 250 customers 6 163 185 99 208 141 67 230   # L=623.4050148312
route 2 depot 250 customers 21 119 22 47 195 173 106   # L=298.5019943999
route 3 depot 250 customers 24 140 103 73 214 125 115   # L=306.6034646092
route 4 depot 249 customers 26 172 136 123 52   # L=275.1538672911
route 5 depot 250 customers 27 181 94 33 187 86 153 75   # L=600.3243459255
route 6 depot 250 customers 36 164 5 168 180 170   # L=338.1855080926
route 7 depot 249 customers 53 17 11 48 129 128   # L=397.9297628203
route 8 depot 249 customers 61 121 38 232 175 135 225 31 77 200 146   # L=825.8360736277
route 9 depot 249 customers 63 192 100 12 166 88   # L=285.8764002960
route 10 depot 249 customers 68 145 134 83 51 161   # L=276.7494486412
route 11 depot 249 customers 72 197 206 78 204 30 228 0   # L=678.1272210983
route 12 depot 249 customers 95 165 18 184 71 32   # L=351.5256127272
route 13 depot 250 customers 198 43 104 226 19 108 109 59 157 158   # L=795.8102307302
route 14 depot 249 customers 122 117 2 15 242   # L=228.1578114380
route 15 depot 249 customers 124 113 147 25 8 152 247 120   # L=377.8104974611
route 16 depot 250 customers 127 142 13 97 239 116   # L=348.3874145648
route 17 depot 250 customers 151 143 191 183 217 244 93 150 85 148   # L=627.1096976460
route 18 depot 250 customers 155 238 34 118   # L=234.4962201147
route 19 depot 250 customers 159 3 114 243 107 154   # L=437.3120632761
route 20 depot 249 customers 162 156 224 241 55 65 167 46 54 16   # L=620.5675306538
route 21 depot 249 customers 169 229 188 105   # L=229.2172100726
route 22 depot 249 customers 176 236 101 14 218 74 58 66 50   # L=568.6693274848
route 23 depot 250 customers 179 62 215 45 90 76 49 87 246   # L=454.1982924474
route 24 depot 249 customers 189 7 111 212   # L=154.4815034259
route 25 depot 249 customers 194 216 82 205 64 227   # L=319.4035888656
route 26 depot 250 customers 221 84 131 96 28 133   # L=463.0141599434
route 27 depot 250 customers 199 178 160 92 186 44 211   # L=277.2977378535
route 28 depot 249 customers 202 56 213 130 237 41   # L=317.9319744142
route 29 depot 249 customers 203 29 190 4 132 210 89 60 220   # L=616.1383681926
route 30 depot 250 customers 207 80 144 98 69 231 201 138   # L=689.7194281069
route 31 depot 249 customers 223 81 234 240 10 9 196 193 79 112 102   # L=615.9869794224
route 32 depot 250 customers 235 110 91 177 209 40   # L=409.5251514380
route 33 depot 250 customers 245 139 171 20 137 233 70   # L=485.9678245638
route 34 depot 249 customers 248 42 222 37 174 23 39 126   # L=572.7957502550
end
