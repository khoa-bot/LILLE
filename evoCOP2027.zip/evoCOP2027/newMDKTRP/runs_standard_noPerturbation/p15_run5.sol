# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..159, depots 160..163
format mdktrp-sol-1
instance p15
instance_file ../dat/p15
paper_id p15
n 160
m 4
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 5794.1125496954
cost_reported 5794.1125496954
cost_recomputed 5794.1125496954
seed_cost 6779.7660083239
time_seconds 1.659
cycles 74749
cycle_segments 37253|37496
accepted 227
epochs 22
perturbations 1
crossovers_used 74
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 160 customers 1 9 17 25 33   # L=150.0000000000
route 1 depot 160 customers 3 11 19 27 35   # L=150.0000000000
route 2 depot 160 customers 4 12 20 28 36   # L=150.0000000000
route 3 depot 160 customers 6 14 22 30 38   # L=150.0000000000
route 4 depot 160 customers 0 8 16 24 32   # L=212.1320343560
route 5 depot 160 customers 2 10 26   # L=98.9949493661
route 6 depot 160 customers 5 13 21 29 37   # L=212.1320343560
route 7 depot 160 customers 7 15 23 31 39   # L=212.1320343560
route 8 depot 162 customers 83 99 107 115   # L=130.0000000000
route 9 depot 163 customers 127 135 143 151 159   # L=212.1320343560
route 10 depot 160 customers 18 34   # L=113.1370849898
route 11 depot 161 customers 42 50 58 66 74   # L=212.1320343560
route 12 depot 161 customers 43 51 59 67 75   # L=150.0000000000
route 13 depot 161 customers 44 52 60 68 76   # L=150.0000000000
route 14 depot 161 customers 46 54 62 70 78   # L=150.0000000000
route 15 depot 161 customers 40 48 56 64 72   # L=212.1320343560
route 16 depot 161 customers 41 49 57 65 73   # L=150.0000000000
route 17 depot 161 customers 45 53 61 69 77   # L=212.1320343560
route 18 depot 161 customers 47 55 63 71 79   # L=212.1320343560
route 19 depot 163 customers 124 132 140 148   # L=100.0000000000
route 20 depot 162 customers 81 89 97 105 113   # L=150.0000000000
route 21 depot 162 customers 91   # L=20.0000000000
route 22 depot 162 customers 84 92 100 108 116   # L=150.0000000000
route 23 depot 162 customers 86 94 102 110 118   # L=150.0000000000
route 24 depot 162 customers 80 88 96 104 112   # L=212.1320343560
route 25 depot 162 customers 82 90 98 106 114   # L=212.1320343560
route 26 depot 162 customers 85 93 101 109 117   # L=212.1320343560
route 27 depot 162 customers 87 95 103 111 119   # L=212.1320343560
route 28 depot 163 customers 121 129 137 145 153   # L=150.0000000000
route 29 depot 163 customers 123 131 139 147 155   # L=150.0000000000
route 30 depot 163 customers 156   # L=50.0000000000
route 31 depot 163 customers 126 134 142 150 158   # L=150.0000000000
route 32 depot 163 customers 120 128 136 144 152   # L=212.1320343560
route 33 depot 163 customers 122 130 138 146 154   # L=212.1320343560
route 34 depot 163 customers 125 133 141 149 157   # L=212.1320343560
end
