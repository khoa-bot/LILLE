# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..143, depots 144..147
format mdktrp-sol-1
instance pr03
instance_file ../dat/pr03
paper_id pr03
n 144
m 4
k 35
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 4462.4975640443
cost_reported 4462.4975640443
cost_recomputed 4462.4975640443
seed_cost 6071.6119936536
time_seconds 2.023
cycles 103912
cycle_segments 49789|54123
accepted 1122
epochs 27
perturbations 1
crossovers_used 103
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 146 customers 1 63 136 76   # L=119.0886688404
route 1 depot 145 customers 3 5 53 97 48   # L=237.6182180888
route 2 depot 145 customers 7 55 124 60 35 56   # L=282.0794531537
route 3 depot 144 customers 13 126 87 51   # L=146.3364641646
route 4 depot 147 customers 15 64 92 75 115   # L=228.5678143193
route 5 depot 144 customers 16 79 2 120 39   # L=131.7222477496
route 6 depot 147 customers 17 122 127 32 119   # L=142.2939462256
route 7 depot 147 customers 20 65 89 6   # L=122.4605089966
route 8 depot 146 customers 22 121 80 31   # L=84.1993907448
route 9 depot 145 customers 23 18 140 73 71   # L=202.7570413997
route 10 depot 144 customers 25 94 0 12 109   # L=114.2197653112
route 11 depot 145 customers 36 107   # L=33.4790926925
route 12 depot 144 customers 38 70 26 113   # L=126.1326764972
route 13 depot 146 customers 41 30   # L=63.6556735668
route 14 depot 147 customers 42 103 21 57 24 125   # L=140.7190405745
route 15 depot 146 customers 43 37 19 102   # L=142.5950030939
route 16 depot 145 customers 50 45 67   # L=66.3042710661
route 17 depot 144 customers 61 138 131 118 68   # L=158.1226250723
route 18 depot 147 customers 62 27 4   # L=62.2520864214
route 19 depot 145 customers 69 78 99   # L=98.3469028993
route 20 depot 145 customers 74 54   # L=76.9859046214
route 21 depot 145 customers 82 33 110   # L=114.4085790800
route 22 depot 147 customers 85 28 81 58   # L=122.5797060241
route 23 depot 144 customers 90 44 86 77   # L=50.5831289650
route 24 depot 147 customers 91 142 14 40 83   # L=79.9860030313
route 25 depot 146 customers 93 101 47 96 133 29   # L=159.0093920975
route 26 depot 147 customers 105 137 95 52   # L=115.5697016219
route 27 depot 144 customers 108 106 10 34   # L=72.5646268938
route 28 depot 145 customers 116 66 84   # L=125.4251553383
route 29 depot 146 customers 123 112 135 59 46 139 88   # L=323.3536102229
route 30 depot 144 customers 128 11 111   # L=83.9259279664
route 31 depot 146 customers 129 98 143 117   # L=88.5110971296
route 32 depot 144 customers 132 72 9 49   # L=118.0816179691
route 33 depot 145 customers 134 104 114 100   # L=101.8237930878
route 34 depot 146 customers 141 130 8   # L=126.7384291171
end
