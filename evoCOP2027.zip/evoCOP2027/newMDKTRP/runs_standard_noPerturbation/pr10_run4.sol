# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..287, depots 288..293
format mdktrp-sol-1
instance pr10
instance_file ../dat/pr10
paper_id pr10
n 288
m 6
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 9151.8794789779
cost_reported 9151.8794789779
cost_recomputed 9151.8794789779
seed_cost 13018.1958743299
time_seconds 5.147
cycles 86511
cycle_segments 62505|24006
accepted 1705
epochs 65
perturbations 1
crossovers_used 86
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 292 customers 5 15 221 6 58 173 88 104   # L=274.2930369280
route 1 depot 293 customers 8 265 47 278 280 237 277 208 115 18 181   # L=419.8256646055
route 2 depot 289 customers 9 156 16 250 191 21 165 17 36 148   # L=290.7598362322
route 3 depot 291 customers 24 113 212 283 268 167 224 286 175   # L=257.4454565918
route 4 depot 292 customers 26 109 229 77 40 110 131 101   # L=389.3566503293
route 5 depot 290 customers 28 144 41 33 133 150 0 20 155   # L=182.1872978257
route 6 depot 292 customers 37 43 87 168 120 236 147   # L=223.9964864238
route 7 depot 290 customers 42 140 19 27 48 204 231 130 45 180   # L=227.1782547468
route 8 depot 288 customers 46 51 163 54 25 153 235 95 56   # L=266.8382840739
route 9 depot 288 customers 61 53 122 137 279 69   # L=147.1369511901
route 10 depot 292 customers 71 154 241 70 67 55 100 149 249 80 254 73   # L=539.7182517473
route 11 depot 292 customers 78 184 114 108 75 201 252   # L=134.3813272031
route 12 depot 288 customers 79 94 23 29 196 186 57 209 106   # L=411.7646282062
route 13 depot 288 customers 82 145 287 12 22 239 35   # L=198.1372538445
route 14 depot 293 customers 83 170 143 172 164 187 3   # L=221.3427826280
route 15 depot 291 customers 96 266 65 220 60 270 171 136   # L=172.9173844436
route 16 depot 288 customers 103 233 66 271 216 255 52   # L=416.2010557029
route 17 depot 290 customers 105 169 177 210 190 240 38 10 203 219   # L=331.0747656115
route 18 depot 293 customers 111 264 74 76 183 64 102 188 59   # L=220.2587610073
route 19 depot 291 customers 126 158 282 132 11 72 44 4 197 193 119   # L=391.0052119981
route 20 depot 290 customers 138 198 211 90 195 14 244 223 161   # L=335.3791293219
route 21 depot 292 customers 157 151 127 202 242 89 62 98   # L=267.6551304088
route 22 depot 289 customers 159 117 262 121 243 97 39 275   # L=120.3235276993
route 23 depot 289 customers 178 99 107 125 85 34 248   # L=178.5932740498
route 24 depot 288 customers 205 63 49 32 81   # L=209.0680406806
route 25 depot 291 customers 213 30 215 269 230 124   # L=203.1190905002
route 26 depot 291 customers 217 185 226 272 135 2 251 182   # L=309.8373346004
route 27 depot 291 customers 218 263 225 258 118 179 152 123   # L=211.4960969948
route 28 depot 289 customers 232 273 276 128 200 91 31 139   # L=227.6710710255
route 29 depot 288 customers 245 13 174 234 228 134 112 194   # L=249.1455726863
route 30 depot 291 customers 256 162 246 7 227 166   # L=151.6930341401
route 31 depot 292 customers 257 1 247 207 285 214 199 284 281   # L=238.7413360619
route 32 depot 293 customers 259 92 206 176 192 189 142 260 116 84 222   # L=355.0482758420
route 33 depot 290 customers 261 141 146 129 253 238   # L=202.0493013170
route 34 depot 290 customers 274 68 86 93 160 267 50   # L=176.2399223095
end
