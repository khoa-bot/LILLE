# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..143, depots 144..149
format mdktrp-sol-1
instance pr08
instance_file ../dat/pr08
paper_id pr08
n 144
m 6
k 35
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 4005.3394986471
cost_reported 4005.3394986471
cost_recomputed 4005.3394986471
seed_cost 5349.1592369027
time_seconds 2.173
cycles 110174
cycle_segments 56649|53525
accepted 1225
epochs 29
perturbations 1
crossovers_used 101
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 145 customers 7 37 15 21 60 109   # L=176.3603990394
route 1 depot 147 customers 18 2 4 138 133   # L=100.0414225651
route 2 depot 148 customers 20 99 29 30   # L=110.2801455597
route 3 depot 145 customers 22 112 102 3 17   # L=213.3637803483
route 4 depot 144 customers 27 101 100 95   # L=71.5504388508
route 5 depot 146 customers 32 36 87 125   # L=177.3140546063
route 6 depot 147 customers 131 64 76   # L=47.7249313163
route 7 depot 145 customers 49 127 50 117   # L=165.1126385632
route 8 depot 148 customers 35 123 57 59 93   # L=107.4383418374
route 9 depot 144 customers 39 38 92 140 81 115   # L=262.5791883565
route 10 depot 144 customers 52 46 65 10 77   # L=126.1436913222
route 11 depot 146 customers 44 118 48   # L=157.3556064516
route 12 depot 148 customers 51 94 85 88   # L=107.6991481220
route 13 depot 149 customers 53 58 14 124   # L=64.2274333841
route 14 depot 145 customers 89 25 119   # L=128.0603144430
route 15 depot 146 customers 67 107 120   # L=91.9215146025
route 16 depot 147 customers 68 142   # L=133.0288166172
route 17 depot 149 customers 71 143 42 80 54   # L=112.0299799974
route 18 depot 144 customers 72 83 26 79   # L=145.4136543317
route 19 depot 149 customers 74 97   # L=51.6015383888
route 20 depot 148 customers 82 63 84 0 75 5   # L=98.5153623777
route 21 depot 144 customers 128 139   # L=24.9793189236
route 22 depot 146 customers 90 31 61 86   # L=80.7639383701
route 23 depot 149 customers 98 70 16 110 129 19   # L=153.2514754258
route 24 depot 145 customers 103 9 34 41   # L=78.3928146418
route 25 depot 148 customers 106 47 1 130 136   # L=186.6213590584
route 26 depot 148 customers 111 66 69   # L=86.4463761145
route 27 depot 144 customers 121 6 28 56   # L=114.9377668031
route 28 depot 149 customers 122 43 114 12 113   # L=88.4099989528
route 29 depot 144 customers 33 108 62 24   # L=96.5691629020
route 30 depot 146 customers 135 40 91   # L=66.1943505166
route 31 depot 145 customers 132 105 73 96 126   # L=70.4703537176
route 32 depot 146 customers 55 134 45 23   # L=58.3269161570
route 33 depot 148 customers 137 13 104 78 116   # L=112.9137436269
route 34 depot 147 customers 141 11 8   # L=139.2995223555
end
