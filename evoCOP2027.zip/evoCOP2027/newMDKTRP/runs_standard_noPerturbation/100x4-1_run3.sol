# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance 100x4-1
instance_file ../LallaRuizVoss_Instances/100x4-1.txt
paper_id lr13
n 100
m 4
k 25
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 8288.4286608989
cost_reported 8288.4286608989
cost_recomputed 8288.4286608989
seed_cost 10544.5113530457
time_seconds 2.283
cycles 212937
cycle_segments 96479|116458
accepted 1963
epochs 31
perturbations 1
crossovers_used 212
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 1 32   # L=158.1024967591
route 1 depot 102 customers 93 45 11 29 96 10   # L=551.7083414327
route 2 depot 103 customers 5 13 60 43   # L=501.6518489244
route 3 depot 100 customers 89 35   # L=121.2310562562
route 4 depot 103 customers 14 31 97   # L=262.0937271230
route 5 depot 103 customers 21 57 74 16 3 38 88   # L=541.2310562562
route 6 depot 102 customers 72 4 56 99 19 68 94   # L=547.7269903475
route 7 depot 101 customers 2 70 52   # L=178.8772163826
route 8 depot 103 customers 8 73   # L=100.3952967567
route 9 depot 102 customers 15 85 0 98   # L=678.3269276857
route 10 depot 102 customers 46 90 65 82 87   # L=639.1834959267
route 11 depot 103 customers 49 39 23 54 30 71   # L=533.6108686856
route 12 depot 103 customers 50 41   # L=83.2455532034
route 13 depot 103 customers 58 6 86   # L=350.0282653277
route 14 depot 100 customers 59 67 53 78   # L=278.8854382000
route 15 depot 101 customers 61 69 18   # L=115.3663105725
route 16 depot 101 customers 22 83 26   # L=122.6240552496
route 17 depot 100 customers 25 66 84 12   # L=223.5731457317
route 18 depot 102 customers 76 80 42 48 62   # L=628.8634951737
route 19 depot 100 customers 63 47 24   # L=101.6227766017
route 20 depot 101 customers 77 33 7   # L=121.2241749487
route 21 depot 100 customers 79 40 37 75 55   # L=338.2517641644
route 22 depot 100 customers 91 51 64 20 95 81   # L=386.5028504834
route 23 depot 102 customers 92 9 27   # L=84.1421356237
route 24 depot 102 customers 34 44 28 36 17   # L=639.9593730821
end
