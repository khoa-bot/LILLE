# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..251
format mdktrp-sol-1
instance p09
instance_file ../dat/p09
paper_id p09
n 249
m 3
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 13062.4531158358
cost_reported 13062.4531158358
cost_recomputed 13062.4531158358
seed_cost 19935.8334565004
time_seconds 4.526
cycles 100897
cycle_segments 66037|34860
accepted 1495
epochs 58
perturbations 1
crossovers_used 100
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 250 customers 1 216 82 205 227 52   # L=278.9311053358
route 1 depot 249 customers 22 178 160 45 143 191 183 217 118 238   # L=697.6689019640
route 2 depot 251 customers 32 78 4 132 11 48 123   # L=327.1606852954
route 3 depot 249 customers 36 115 125 214   # L=239.0599098182
route 4 depot 250 customers 63 223 162 68 176 189 7   # L=324.9237609779
route 5 depot 251 customers 141 67 230 201 138 0   # L=248.0925311339
route 6 depot 251 customers 71 184 18 165 206 53   # L=302.6522087417
route 7 depot 250 customers 234 42 222 121 37 38   # L=323.7775931131
route 8 depot 249 customers 84 168 51 218 14 101 232 175   # L=482.2863399402
route 9 depot 249 customers 91 177 209 40 109 59 157 133 158   # L=452.3021233244
route 10 depot 251 customers 98 69 231 154   # L=126.0560174967
route 11 depot 251 customers 99 80 3 163 6 159   # L=294.9532200710
route 12 depot 250 customers 100 202 56 213 130 9 65 167 46 54 16   # L=611.5817040250
route 13 depot 249 customers 104 131 96 66 31 77 200 23 39   # L=603.7241314964
route 14 depot 249 customers 108 19 226 28 50 146 126   # L=444.7027307472
route 15 depot 249 customers 110 43 198 207 245 24   # L=294.7402896566
route 16 depot 250 customers 113 147 25 8 152 247 120 188 105   # L=258.0347686324
route 17 depot 249 customers 116 239 97 106 211 246   # L=337.4048485816
route 18 depot 250 customers 124 203 197 72 95 111 212   # L=405.1274339408
route 19 depot 251 customers 137 20 185 171 139 73 103 140   # L=397.1137156305
route 20 depot 250 customers 169 57 182 149 35 219 64   # L=245.5253677396
route 21 depot 249 customers 170 180 161 74 58 135 225   # L=409.1946160173
route 22 depot 249 customers 173 142 13 44 76 87 150 85 148   # L=569.6086517924
route 23 depot 250 customers 192 10 240 224 241 55 174   # L=328.9315124479
route 24 depot 250 customers 194 26 172 136 17 29 190   # L=385.0039528569
route 25 depot 249 customers 195 47 127 186 92 90 49 244 93   # L=473.6902171210
route 26 depot 251 customers 208 144 114 187 94 181 27 34   # L=436.7168275904
route 27 depot 251 customers 210 89 60 128 220 129   # L=330.7432480913
route 28 depot 249 customers 221 164 5 242 15 2 117 122   # L=461.9140372206
route 29 depot 250 customers 81 156 248 61 236 145 134 83   # L=400.6903478074
route 30 depot 250 customers 229 88 166 12   # L=154.6826030836
route 31 depot 251 customers 233 204 30 70 228   # L=214.8344857762
route 32 depot 249 customers 235 119 21 199 62 215 179 151 155   # L=440.9237565937
route 33 depot 250 customers 237 41 196 193 79 112 102   # L=465.2727548156
route 34 depot 251 customers 243 107 75 153 86 33   # L=294.4267169590
end
