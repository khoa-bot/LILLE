# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance 50x4-1
instance_file ../LallaRuizVoss_Instances/50x4-1.txt
paper_id lr07
n 50
m 4
k 20
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 5424.5684790664
cost_reported 5424.5684790664
cost_recomputed 5424.5684790664
seed_cost 6241.0005170037
time_seconds 1.588
cycles 385516
cycle_segments 192175|193341
accepted 2578
epochs 22
perturbations 1
crossovers_used 385
early_stop 1
valid 1
note ok
num_routes 20
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 50 customers 14 11 47   # L=338.7435934691
route 1 depot 50 customers 26 37 43   # L=295.7484047114
route 2 depot 53 customers 18 23 10   # L=169.7056274848
route 3 depot 50 customers 4 34   # L=311.1269837221
route 4 depot 50 customers 28 40   # L=60.0000000000
route 5 depot 50 customers 29 0   # L=368.0028187932
route 6 depot 50 customers 13 46 39 45 6   # L=650.0000000000
route 7 depot 50 customers 3 1 24 25   # L=455.9145991658
route 8 depot 50 customers 9 30   # L=252.5299969454
route 9 depot 53 customers 15 19   # L=233.6067977500
route 10 depot 50 customers 20 7 41 48   # L=501.8144406875
route 11 depot 53 customers 44 5   # L=183.7010772219
route 12 depot 51 customers 49 8   # L=122.4621125124
route 13 depot 53 customers 31   # L=76.1577310586
route 14 depot 51 customers 12 38   # L=130.0000000000
route 15 depot 53 customers 35 33 27 16   # L=511.9188632816
route 16 depot 52 customers 22 42   # L=178.5656732931
route 17 depot 50 customers 2 17 21   # L=402.9145083636
route 18 depot 50 customers 36   # L=121.6552506060
route 19 depot 53 customers 32   # L=60.0000000000
end
