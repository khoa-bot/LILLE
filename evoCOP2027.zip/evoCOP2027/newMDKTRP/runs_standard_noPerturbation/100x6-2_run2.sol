# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..105
format mdktrp-sol-1
instance 100x6-2
instance_file ../LallaRuizVoss_Instances/100x6-2.txt
paper_id lr17
n 100
m 6
k 25
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 6107.3233039043
cost_reported 6107.3233039043
cost_recomputed 6107.3233039043
seed_cost 8454.9947684479
time_seconds 2.283
cycles 211956
cycle_segments 96156|115800
accepted 1941
epochs 31
perturbations 1
crossovers_used 211
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 101 customers 74 8 60 72 57   # L=504.9369815078
route 1 depot 103 customers 6 24 25   # L=160.7106781187
route 2 depot 101 customers 69 96 19   # L=148.2842712475
route 3 depot 102 customers 28 43 98 76   # L=158.8634951737
route 4 depot 101 customers 31 65 10 3 33 18   # L=622.3294456115
route 5 depot 102 customers 97 77 15 51   # L=187.7269903475
route 6 depot 101 customers 50 59 39 54   # L=189.5084461962
route 7 depot 105 customers 58 52 11   # L=247.3863375371
route 8 depot 103 customers 9 36   # L=110.0000000000
route 9 depot 103 customers 61 47 46 17   # L=259.2640090268
route 10 depot 100 customers 64 85 63   # L=165.6296860470
route 11 depot 101 customers 48 14 53 13   # L=193.1001822274
route 12 depot 103 customers 99 44 40 34   # L=207.2017845254
route 13 depot 105 customers 78 41 29   # L=150.5929451351
route 14 depot 105 customers 79 80 22   # L=181.2310562562
route 15 depot 105 customers 56 23 0 68 26   # L=323.6067977500
route 16 depot 100 customers 83 81 66 27 93 45   # L=280.4163056034
route 17 depot 105 customers 84 16 7 71 55   # L=327.4983449284
route 18 depot 102 customers 86 35 30 73 38   # L=170.7106781187
route 19 depot 101 customers 88 21 67 5 20 75   # L=324.1421356237
route 20 depot 102 customers 89 32 90   # L=111.2310562562
route 21 depot 101 customers 92 4 1 70 95   # L=442.2679756132
route 22 depot 105 customers 62 94 91 37 87   # L=354.4395525283
route 23 depot 102 customers 2 42   # L=54.1421356237
route 24 depot 101 customers 12 49 82   # L=232.1020129009
end
