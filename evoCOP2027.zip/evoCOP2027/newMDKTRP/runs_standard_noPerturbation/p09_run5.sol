# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..251
format mdktrp-sol-1
instance p09
instance_file ../dat/p09
paper_id p09
n 249
m 3
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 13083.5573287495
cost_reported 13083.5573287495
cost_recomputed 13083.5573287495
seed_cost 19935.8334565004
time_seconds 4.604
cycles 101235
cycle_segments 58203|43032
accepted 1547
epochs 59
perturbations 1
crossovers_used 101
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 250 customers 1 216 82 205 227 52   # L=278.9311053358
route 1 depot 249 customers 22 178 160 45 143 191 183 217 118   # L=589.5194645311
route 2 depot 251 customers 32 4 132 11 48 123   # L=285.4313801947
route 3 depot 249 customers 36 115 125 103 73   # L=323.5867326024
route 4 depot 251 customers 67 141 231 230 201 138   # L=237.1270406856
route 5 depot 251 customers 71 184 18 165 206 197 72 95   # L=451.2180200611
route 6 depot 251 customers 78 190 29 17 136   # L=278.4839200577
route 7 depot 250 customers 81 156 248 61 236 145 134 83   # L=400.6903478074
route 8 depot 249 customers 84 168 51 218 14 101 232 175   # L=482.2863399402
route 9 depot 249 customers 91 177 209 40 109 59 157 133 158   # L=452.3021233244
route 10 depot 251 customers 98 69 107 243 153 75 154   # L=273.9312136149
route 11 depot 251 customers 99 80 3 187 94 181 34 238   # L=482.9596437259
route 12 depot 250 customers 100 202 56 213 130 9 65 167 46 54 16   # L=611.5817040250
route 13 depot 249 customers 104 131 96 66 31 77 200 23 39   # L=603.7241314964
route 14 depot 249 customers 108 19 226 28 50 146 126   # L=444.7027307472
route 15 depot 249 customers 110 43 198 207 245 24 140   # L=383.4906595086
route 16 depot 250 customers 113 147 25 8 152 247 88 166 12   # L=248.3151463166
route 17 depot 249 customers 116 239 97 106 211 246   # L=337.4048485816
route 18 depot 250 customers 124 63 162 189 7 111 212   # L=358.9430632115
route 19 depot 251 customers 137 20 185 171 139 163 6 159   # L=374.7015521225
route 20 depot 250 customers 169 57 182 149 35 219 64   # L=245.5253677396
route 21 depot 249 customers 170 180 161 74 58 135 225   # L=409.1946160173
route 22 depot 249 customers 173 142 13 44 76 87 150 85 148   # L=569.6086517924
route 23 depot 250 customers 192 10 240 224 241 55 174   # L=328.9315124479
route 24 depot 250 customers 194 26 172 53 203   # L=238.2307791616
route 25 depot 249 customers 195 47 127 186 92 90 49 244 93   # L=473.6902171210
route 26 depot 251 customers 208 144 114 86 33 27   # L=276.0250140845
route 27 depot 251 customers 210 89 60 128 220 129   # L=330.7432480913
route 28 depot 249 customers 221 164 5 242 15   # L=211.9638634293
route 29 depot 250 customers 223 176 68 122 117 2 214   # L=414.2113475789
route 30 depot 250 customers 229 188 120 105   # L=161.5385077662
route 31 depot 251 customers 233 204 30 70 228 0   # L=294.5889311065
route 32 depot 250 customers 234 42 222 121 37 38   # L=323.7775931131
route 33 depot 249 customers 235 119 21 199 62 215 179 151 155   # L=440.9237565937
route 34 depot 250 customers 237 41 196 193 79 112 102   # L=465.2727548156
end
