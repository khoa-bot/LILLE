# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..9, depots 10..13
format mdktrp-sol-1
instance 10x4-3
instance_file ../LallaRuizVoss_Instances/10x4-3.txt
paper_id lr03
n 10
m 4
k 5
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 832.7790279508
cost_reported 832.7790279508
cost_recomputed 832.7790279508
seed_cost 1017.7792428188
time_seconds 1.562
cycles 3873266
cycle_segments 1924000|1949266
accepted 4692
epochs 22
perturbations 1
crossovers_used 1992
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 10 customers 9 7   # L=85.9524158062
route 1 depot 10 customers 2 4   # L=171.6552506060
route 2 depot 12 customers 6 5 8   # L=465.1713615387
route 3 depot 10 customers 1   # L=40.0000000000
route 4 depot 13 customers 0 3   # L=70.0000000000
end
