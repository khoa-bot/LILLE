# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance 50x4-3
instance_file ../LallaRuizVoss_Instances/50x4-3.txt
paper_id lr09
n 50
m 4
k 20
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 3802.8822982601
cost_reported 3802.8822982601
cost_recomputed 3802.8822982601
seed_cost 5140.1946908663
time_seconds 1.732
cycles 442083
cycle_segments 219286|222797
accepted 2776
epochs 24
perturbations 1
crossovers_used 442
early_stop 1
valid 1
note ok
num_routes 20
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 52 customers 34 35   # L=210.9975124224
route 1 depot 51 customers 3 27   # L=173.6155416021
route 2 depot 50 customers 26 39   # L=142.2046203724
route 3 depot 50 customers 2 42   # L=198.5330247696
route 4 depot 50 customers 31 28   # L=170.3471291419
route 5 depot 51 customers 9 0 30   # L=164.3836573087
route 6 depot 52 customers 21 43 29   # L=210.9901951359
route 7 depot 53 customers 5 40 47 8   # L=299.7925548298
route 8 depot 50 customers 1   # L=50.0000000000
route 9 depot 51 customers 24 45 25 15   # L=523.1370849898
route 10 depot 51 customers 36   # L=63.2455532034
route 11 depot 52 customers 44 48 20   # L=184.8090296724
route 12 depot 51 customers 14 4 16   # L=307.4024154458
route 13 depot 52 customers 13 37 33   # L=235.2943384388
route 14 depot 53 customers 11 18 10   # L=184.1640786500
route 15 depot 52 customers 7 41   # L=142.2046203724
route 16 depot 52 customers 6 19 32   # L=182.6745506515
route 17 depot 52 customers 38 22   # L=80.7768723046
route 18 depot 51 customers 17 23 46   # L=200.0000000000
route 19 depot 53 customers 12 49   # L=78.3095189485
end
