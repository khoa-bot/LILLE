# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..239, depots 240..245
format mdktrp-sol-1
instance p18
instance_file ../dat/p18
paper_id p18
n 240
m 6
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 11449.8247632573
cost_reported 11449.8247632573
cost_recomputed 11449.8247632573
seed_cost 14080.9622334736
time_seconds 2.955
cycles 70405
cycle_segments 40725|29680
accepted 657
epochs 38
perturbations 1
crossovers_used 49
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 240 customers 0 8 16 24 32 237 229   # L=387.6955262170
route 1 depot 240 customers 1 9 17 25 33 238 230 222 213   # L=462.3606797750
route 2 depot 240 customers 2 10 18 26 34 239   # L=292.8427124746
route 3 depot 240 customers 3 11 19 27 35   # L=150.0000000000
route 4 depot 240 customers 4 12 20 28 36 155 147 139 131   # L=450.0000000000
route 5 depot 240 customers 5 13 21 29 37 72 64   # L=387.6955262170
route 6 depot 240 customers 6 14 7 15 23 31   # L=251.4213562373
route 7 depot 241 customers 40 51 59 67 75 48 56   # L=390.1009242415
route 8 depot 241 customers 41 49 57 65 73 38 30 22   # L=360.0000000000
route 9 depot 241 customers 43 45 53 61 69 77   # L=251.4213562373
route 10 depot 241 customers 44 42 50 58 66 74 39   # L=337.9898987322
route 11 depot 241 customers 46 54 62 70 78   # L=150.0000000000
route 12 depot 241 customers 47 55 63 71 79 117 109   # L=387.6955262170
route 13 depot 242 customers 81 82 89 80 88 96 104   # L=342.1320343560
route 14 depot 242 customers 83 91 99 107 115 76 68 60 52   # L=450.0000000000
route 15 depot 242 customers 84 92 100 108 116 98 90   # L=336.2531611330
route 16 depot 242 customers 85 94 102 110 118 101 93   # L=390.1009242415
route 17 depot 242 customers 86 87 95 103 111 119   # L=251.4213562373
route 18 depot 243 customers 121 122 129 120 128 136 144   # L=342.1320343560
route 19 depot 243 customers 123 125 133 141 149 157 112   # L=337.9898987322
route 20 depot 243 customers 124 132 140 148 156 138 130   # L=336.2531611330
route 21 depot 243 customers 126 134 142 150 158 113 105 97   # L=360.0000000000
route 22 depot 243 customers 127 135 143 151 159 114 106   # L=387.6955262170
route 23 depot 244 customers 163 171 160 168 176 184   # L=251.4213562373
route 24 depot 244 customers 161 162 169 177 185 193 170   # L=326.7661908733
route 25 depot 244 customers 165 173 181 189 197 152   # L=292.8427124746
route 26 depot 244 customers 164 172 180 188 196 178 186 194   # L=450.5929451351
route 27 depot 244 customers 166 174 182 190 198 153 145 137   # L=360.0000000000
route 28 depot 244 customers 167 175 183 191 199 154 146   # L=387.6955262170
route 29 depot 245 customers 201 209 217 225 233   # L=150.0000000000
route 30 depot 245 customers 202 210 218 226 234 192   # L=292.8427124746
route 31 depot 245 customers 203 200 208 216 224 232   # L=251.4213562373
route 32 depot 245 customers 204 212 220 228 236 195 187 179   # L=360.0000000000
route 33 depot 245 customers 205 211 219 227 235 221   # L=281.6190046157
route 34 depot 245 customers 206 214 207 215 223 231   # L=251.4213562373
end
