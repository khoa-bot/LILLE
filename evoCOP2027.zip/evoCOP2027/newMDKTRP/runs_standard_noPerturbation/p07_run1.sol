# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance p07
instance_file ../dat/p07
paper_id p07
n 100
m 4
k 35
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 1520.5668921888
cost_reported 1520.5668921888
cost_recomputed 1520.5668921888
seed_cost 1831.4744540231
time_seconds 2.136
cycles 187419
cycle_segments 102651|84768
accepted 2116
epochs 29
perturbations 1
crossovers_used 187
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 103 customers 0 49   # L=18.4900803809
route 1 depot 102 customers 1 56 14 42   # L=51.3331853524
route 2 depot 100 customers 4 92 84 90   # L=48.9437437072
route 3 depot 103 customers 9 89 62   # L=52.1552912412
route 4 depot 101 customers 11 25   # L=17.0710678119
route 5 depot 102 customers 12 93 5   # L=33.3197530058
route 6 depot 103 customers 51   # L=10.6301458127
route 7 depot 102 customers 21 40   # L=32.5269119346
route 8 depot 101 customers 23   # L=10.0000000000
route 9 depot 103 customers 30 61 10 63   # L=74.6716926885
route 10 depot 103 customers 69 31   # L=25.8020570786
route 11 depot 102 customers 39 20   # L=21.2132034356
route 12 depot 100 customers 44 45   # L=29.7439955753
route 13 depot 103 customers 50 8 70   # L=69.2688683817
route 14 depot 101 customers 53 3 38   # L=46.8467360077
route 15 depot 101 customers 54 24 66   # L=65.6104638069
route 16 depot 102 customers 57 52   # L=17.2645445742
route 17 depot 100 customers 17 88   # L=21.9523852996
route 18 depot 100 customers 60 15 43 37   # L=82.0056037560
route 19 depot 101 customers 67 2 78 77 34   # L=80.2298870126
route 20 depot 103 customers 68 26 27   # L=32.0850775375
route 21 depot 103 customers 29 19 65 64   # L=97.4245773143
route 22 depot 102 customers 72 71 55   # L=41.9961568128
route 23 depot 102 customers 73 74 22   # L=54.8115983564
route 24 depot 101 customers 75   # L=9.2195444573
route 25 depot 101 customers 76 32 80   # L=45.5670608785
route 26 depot 101 customers 79 28 33   # L=38.6145710070
route 27 depot 100 customers 81 47 48   # L=64.2345788108
route 28 depot 100 customers 82 7 46 35   # L=64.0945749896
route 29 depot 100 customers 83 16 85   # L=41.1776823879
route 30 depot 102 customers 86 41 13   # L=45.4820792270
route 31 depot 103 customers 87 6 18   # L=51.4880839001
route 32 depot 100 customers 59 95 94   # L=28.1554951537
route 33 depot 102 customers 96 91 36 99   # L=58.1716168392
route 34 depot 100 customers 98 58 97   # L=38.9645776534
end
