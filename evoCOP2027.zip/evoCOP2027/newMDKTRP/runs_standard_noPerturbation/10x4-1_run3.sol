# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..9, depots 10..13
format mdktrp-sol-1
instance 10x4-1
instance_file ../LallaRuizVoss_Instances/10x4-1.txt
paper_id lr01
n 10
m 4
k 5
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 545.6907121038
cost_reported 545.6907121038
cost_recomputed 545.6907121038
seed_cost 683.7616536825
time_seconds 1.562
cycles 3774588
cycle_segments 1871055|1903533
accepted 5087
epochs 22
perturbations 1
crossovers_used 1878
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 10 customers 0   # L=128.0624847487
route 1 depot 13 customers 6 2 5   # L=112.4264068712
route 2 depot 11 customers 4 3 8   # L=99.5153275036
route 3 depot 13 customers 9 7   # L=141.6552506060
route 4 depot 10 customers 1   # L=64.0312423743
end
