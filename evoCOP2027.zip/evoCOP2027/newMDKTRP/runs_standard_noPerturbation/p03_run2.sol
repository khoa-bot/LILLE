# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..74, depots 75..79
format mdktrp-sol-1
instance p03
instance_file ../dat/p03
paper_id p03
n 75
m 5
k 35
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 950.2503549944
cost_reported 950.2503549944
cost_recomputed 950.2503549944
seed_cost 1162.2076764880
time_seconds 2.479
cycles 323722
cycle_segments 209245|114477
accepted 2542
epochs 34
perturbations 1
crossovers_used 323
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 79 customers 0 72 32   # L=24.3546305021
route 1 depot 78 customers 2 23   # L=22.1421356237
route 2 depot 75 customers 3 51   # L=23.6289686042
route 3 depot 76 customers 4 36 19 69   # L=60.9193877247
route 4 depot 77 customers 6   # L=7.0710678119
route 5 depot 78 customers 39 71   # L=25.3224755112
route 6 depot 77 customers 57 9   # L=37.6227766017
route 7 depot 77 customers 13 58   # L=25.1903655913
route 8 depot 76 customers 14 56   # L=28.5736908083
route 9 depot 78 customers 15 48   # L=28.9172600609
route 10 depot 77 customers 18 53   # L=28.4013151403
route 11 depot 78 customers 8 38 30   # L=66.3844373360
route 12 depot 76 customers 20   # L=10.8166538264
route 13 depot 79 customers 21 60   # L=30.6456445303
route 14 depot 79 customers 22 55   # L=29.9141410524
route 15 depot 75 customers 25 11   # L=19.9757747365
route 16 depot 76 customers 28 12   # L=22.3978959571
route 17 depot 76 customers 29 1   # L=23.1245154966
route 18 depot 78 customers 31 24 54   # L=59.0176476404
route 19 depot 77 customers 34 7   # L=15.0000000000
route 20 depot 76 customers 35 70 59   # L=57.1884870593
route 21 depot 77 customers 37 64   # L=32.2029410175
route 22 depot 78 customers 50   # L=7.2111025509
route 23 depot 79 customers 41 63   # L=24.6204993518
route 24 depot 79 customers 42 40   # L=12.7183472062
route 25 depot 78 customers 43 49 17   # L=41.0000000000
route 26 depot 76 customers 44 26   # L=22.4031242374
route 27 depot 76 customers 46 68   # L=25.0000000000
route 28 depot 76 customers 47 73   # L=12.5343937033
route 29 depot 78 customers 16   # L=8.0622577483
route 30 depot 77 customers 52 10 65   # L=29.2801098893
route 31 depot 79 customers 61 27   # L=26.4031242374
route 32 depot 79 customers 62   # L=10.0000000000
route 33 depot 75 customers 66 33 45   # L=29.1618920132
route 34 depot 75 customers 74 67 5   # L=23.0432914236
end
