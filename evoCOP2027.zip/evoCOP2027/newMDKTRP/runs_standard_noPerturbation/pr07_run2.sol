# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..71, depots 72..77
format mdktrp-sol-1
instance pr07
instance_file ../dat/pr07
paper_id pr07
n 72
m 6
k 35
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 1723.6267754559
cost_reported 1723.6267754559
cost_recomputed 1723.6267754559
seed_cost 2138.7368851757
time_seconds 2.476
cycles 326086
cycle_segments 143756|182330
accepted 2965
epochs 34
perturbations 1
crossovers_used 326
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 75 customers 3 54   # L=33.7569987766
route 1 depot 74 customers 7 2 15   # L=74.7598865522
route 2 depot 73 customers 11 46 63   # L=67.4063407949
route 3 depot 75 customers 12   # L=19.6307489923
route 4 depot 76 customers 13 66   # L=21.1432363437
route 5 depot 73 customers 16 40 49   # L=99.7472752737
route 6 depot 72 customers 17   # L=17.3993780636
route 7 depot 76 customers 18 41   # L=33.0932719050
route 8 depot 72 customers 19 64   # L=57.8827225021
route 9 depot 75 customers 23 56   # L=152.0147109174
route 10 depot 77 customers 24   # L=17.2631698132
route 11 depot 73 customers 25   # L=23.7750580231
route 12 depot 72 customers 26   # L=15.4787001069
route 13 depot 75 customers 27 62   # L=68.1953642191
route 14 depot 75 customers 28   # L=6.4553206737
route 15 depot 76 customers 29 8 10 5   # L=98.4435904279
route 16 depot 72 customers 30 9 32   # L=110.4579730039
route 17 depot 77 customers 31   # L=22.4573029770
route 18 depot 74 customers 33 53 55   # L=59.3738356845
route 19 depot 77 customers 34 1 37 38   # L=115.7855825632
route 20 depot 72 customers 35 70   # L=32.3125515341
route 21 depot 73 customers 42 6   # L=19.4966587466
route 22 depot 74 customers 43 21   # L=31.6345914394
route 23 depot 74 customers 44 14   # L=64.7540118162
route 24 depot 76 customers 47 20   # L=29.0134151981
route 25 depot 73 customers 48 36   # L=39.0980014914
route 26 depot 73 customers 50 58   # L=36.0892733009
route 27 depot 75 customers 51 45 4   # L=60.1933443678
route 28 depot 75 customers 52 71   # L=53.5589594761
route 29 depot 73 customers 60   # L=17.5623456862
route 30 depot 74 customers 61   # L=15.8596610935
route 31 depot 76 customers 65 57   # L=37.9708835277
route 32 depot 73 customers 67 22 0   # L=107.3154490533
route 33 depot 74 customers 68 39   # L=31.8241008557
route 34 depot 76 customers 69 59   # L=32.4230602548
end
