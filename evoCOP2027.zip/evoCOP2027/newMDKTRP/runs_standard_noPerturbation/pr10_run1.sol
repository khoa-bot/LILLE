# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..287, depots 288..293
format mdktrp-sol-1
instance pr10
instance_file ../dat/pr10
paper_id pr10
n 288
m 6
k 35
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 9131.6635770239
cost_reported 9131.6635770239
cost_recomputed 9131.6635770239
seed_cost 13018.1958743299
time_seconds 4.592
cycles 78267
cycle_segments 63356|14911
accepted 1320
epochs 58
perturbations 1
crossovers_used 78
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 292 customers 5 15 221 6 58 173 88 104   # L=274.2930369280
route 1 depot 293 customers 8 47 278 280 237 277 208 115 18 181   # L=375.8756219842
route 2 depot 289 customers 9 156 16 250 191 21 165 17 36 148   # L=290.7598362322
route 3 depot 291 customers 24 113 212 283 268 167 224 286 175   # L=257.4454565918
route 4 depot 292 customers 26 109 229 77 40 110 131 101   # L=389.3566503293
route 5 depot 290 customers 28 144 211 90 195 14 244 223   # L=259.9895484752
route 6 depot 292 customers 37 43 87 168 120 236 147   # L=223.9964864238
route 7 depot 288 customers 39 82 145 287 12 22   # L=147.1103243633
route 8 depot 290 customers 42 133 33 41 150 0 20 155   # L=154.1454686637
route 9 depot 290 customers 140 19 27 48 204 231 130 45   # L=167.4143914191
route 10 depot 288 customers 46 51 163 25 54 103 233 52   # L=266.1804465159
route 11 depot 288 customers 61 53 122 64 102 137 279 69   # L=222.1086480128
route 12 depot 292 customers 71 154 241 70 67 55 100 149 249 80 254 73   # L=539.7182517473
route 13 depot 292 customers 78 184 114 252 132 11 72 44 197   # L=259.3846949307
route 14 depot 288 customers 79 94 23 29 196 186 66 271 216 255   # L=409.2527625162
route 15 depot 293 customers 83 170 143 172 164 187 3   # L=221.3427826280
route 16 depot 291 customers 218 263 225 258 118 179 152 123   # L=211.4960969948
route 17 depot 290 customers 105 169 177 210 190 240 38 10 219 161   # L=347.8592704972
route 18 depot 293 customers 111 264 74 183 76 265 188 59   # L=189.7137142986
route 19 depot 291 customers 126 158 282 270 171 136 4 193 119   # L=297.2893113656
route 20 depot 290 customers 138 198 141 146 129 253 203 238   # L=269.1128924771
route 21 depot 292 customers 157 151 127 202 242 89 62 98   # L=267.6551304088
route 22 depot 289 customers 159 117 262 121 243 97 275 50   # L=121.1743412370
route 23 depot 289 customers 178 99 107 125 85 34 248   # L=178.5932740498
route 24 depot 288 customers 205 63 49 81 209 57 106   # L=412.4797697383
route 25 depot 291 customers 213 30 215 269 230 124   # L=203.1190905002
route 26 depot 291 customers 217 185 226 272 135 2 251 182   # L=309.8373346004
route 27 depot 289 customers 232 273 276 128 200 91 31 139   # L=227.6710710255
route 28 depot 288 customers 245 13 174 234 228 134 112 194 32   # L=330.6229185951
route 29 depot 291 customers 256 162 246 7 227 166   # L=151.6930341401
route 30 depot 292 customers 257 1 247 207 285 214 199 284 281   # L=238.7413360619
route 31 depot 293 customers 259 92 206 176 192 189 142 260 116 84 222   # L=355.0482758420
route 32 depot 290 customers 261 239 35 153 235 95 56   # L=234.3724436768
route 33 depot 291 customers 96 266 65 220 60 201 108 75 180   # L=192.9509426249
route 34 depot 290 customers 274 68 86 93 160 267   # L=133.8589211282
end
