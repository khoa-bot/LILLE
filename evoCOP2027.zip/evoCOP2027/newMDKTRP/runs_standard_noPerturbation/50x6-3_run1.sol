# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..55
format mdktrp-sol-1
instance 50x6-3
instance_file ../LallaRuizVoss_Instances/50x6-3.txt
paper_id lr12
n 50
m 6
k 25
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 3090.3814349554
cost_reported 3090.3814349554
cost_recomputed 3090.3814349554
seed_cost 3904.6667919809
time_seconds 1.732
cycles 384439
cycle_segments 206432|178007
accepted 2627
epochs 24
perturbations 1
crossovers_used 384
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 54 customers 4 1   # L=77.3876888271
route 1 depot 50 customers 20 2   # L=98.9949493661
route 2 depot 50 customers 6 47   # L=120.9083264970
route 3 depot 55 customers 7 39 38   # L=297.7522380484
route 4 depot 51 customers 10 22   # L=159.7443334093
route 5 depot 50 customers 11 13 5   # L=72.3606797750
route 6 depot 50 customers 12   # L=50.0000000000
route 7 depot 55 customers 14 36   # L=69.5153275036
route 8 depot 51 customers 16 17 42   # L=164.1640786500
route 9 depot 55 customers 18 3   # L=123.1012206452
route 10 depot 51 customers 19 45   # L=215.9126028197
route 11 depot 55 customers 35 43   # L=135.7973862297
route 12 depot 54 customers 21   # L=10.0000000000
route 13 depot 51 customers 26   # L=63.2455532034
route 14 depot 52 customers 49 23   # L=209.3919740102
route 15 depot 52 customers 29   # L=40.0000000000
route 16 depot 51 customers 31 37 9 28   # L=196.5685424949
route 17 depot 53 customers 32 30 0   # L=305.3952411005
route 18 depot 55 customers 33 24   # L=114.2357483393
route 19 depot 55 customers 34 8   # L=148.3062142737
route 20 depot 51 customers 40   # L=70.7106781187
route 21 depot 50 customers 15 46   # L=94.1421356237
route 22 depot 52 customers 44 25   # L=102.4621125124
route 23 depot 52 customers 27   # L=64.0312423743
route 24 depot 50 customers 48 41   # L=86.2531611330
end
