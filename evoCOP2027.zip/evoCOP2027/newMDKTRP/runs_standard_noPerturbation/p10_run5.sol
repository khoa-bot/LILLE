# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..252
format mdktrp-sol-1
instance p10
instance_file ../dat/p10
paper_id p10
n 249
m 4
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 12037.5487355519
cost_reported 12037.5487355519
cost_recomputed 12037.5487355519
seed_cost 18327.0084923222
time_seconds 4.292
cycles 95768
cycle_segments 68062|27706
accepted 1299
epochs 55
perturbations 1
crossovers_used 94
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 252 customers 3 80 185 20 137 32 233   # L=308.6386980300
route 1 depot 250 customers 9 237 12 166 88 247 120 105   # L=520.2511287217
route 2 depot 250 customers 10 240 234 81 223 162 63 124   # L=336.6289865125
route 3 depot 251 customers 11 60 89 210 204 30 70 228 0   # L=543.9176250601
route 4 depot 251 customers 17 29 206 165 212 214   # L=217.3225811325
route 5 depot 252 customers 27 155 143 191 183 217 244 93 150 85   # L=635.6295036304
route 6 depot 251 customers 53 203 197 72 95 111 7   # L=297.0324570743
route 7 depot 250 customers 55 175 135 225 31 77 200   # L=319.4140521255
route 8 depot 250 customers 65 167 46 54 16 23 39 126   # L=387.0052115304
route 9 depot 251 customers 82 35 219 149 182 57 188   # L=424.7438322795
route 10 depot 249 customers 84 221 164 5 36   # L=212.4372037161
route 11 depot 249 customers 91 177 209 40 109 59 157 133 158   # L=418.6870649106
route 12 depot 252 customers 94 33 181 34 238 118 148   # L=312.7702264961
route 13 depot 249 customers 104 131 96 50 146   # L=252.6005595402
route 14 depot 249 customers 108 19 226 28 66   # L=234.6545603309
route 15 depot 249 customers 110 43 198 207 151   # L=243.7021594583
route 16 depot 252 customers 114 144 99 208 141 67   # L=287.0554825410
route 17 depot 249 customers 116 239 97 106 211   # L=206.9177651362
route 18 depot 251 customers 123 48 129 128 220   # L=148.6526444447
route 19 depot 250 customers 130 213 56 202 192 100 113 147 25 8 152   # L=565.4754772625
route 20 depot 251 customers 136 172 26 194 1 169 229   # L=299.6897255504
route 21 depot 252 customers 159 6 245 24 140   # L=246.7558638756
route 22 depot 252 customers 163 139 73 103 125 115   # L=328.9700975209
route 23 depot 249 customers 173 142 13 44 76 87 246   # L=365.5354888352
route 24 depot 252 customers 187 86 153 75 154 201   # L=247.5573069640
route 25 depot 251 customers 190 4 132 78 18 184 71 171   # L=360.7638908142
route 26 depot 249 customers 195 47 127 178 160 186 92 90 49   # L=419.2024134739
route 27 depot 250 customers 196 41 193 79 112 102 174   # L=259.9977127529
route 28 depot 250 customers 222 42 121 145 83 134 117 122 2   # L=455.7462974233
route 29 depot 250 customers 224 156 248 61 236 176 68 189   # L=336.7228983523
route 30 depot 251 customers 227 52 64 205 216   # L=241.7261256800
route 31 depot 250 customers 232 74 161 58 180 170 168   # L=396.8517594567
route 32 depot 249 customers 235 22 119 21 199 62 179 215 45   # L=400.8482079055
route 33 depot 250 customers 241 37 38 101 14 218 51 242 15   # L=390.9353023943
route 34 depot 252 customers 243 107 69 98 231 230 138   # L=412.7084246192
end
