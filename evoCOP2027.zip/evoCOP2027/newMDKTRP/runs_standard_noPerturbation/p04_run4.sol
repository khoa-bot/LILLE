# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..101
format mdktrp-sol-1
instance p04
instance_file ../dat/p04
paper_id p04
n 100
m 2
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 1955.3134290463
cost_reported 1955.3134290463
cost_recomputed 1955.3134290463
seed_cost 2413.5673606438
time_seconds 2.209
cycles 192882
cycle_segments 70421|122461
accepted 2080
epochs 30
perturbations 1
crossovers_used 192
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 21 22   # L=39.4646111350
route 1 depot 101 customers 51 17 82 44   # L=86.8465681818
route 2 depot 101 customers 6 47 45   # L=71.2649196893
route 3 depot 101 customers 9 89 62   # L=52.1552912412
route 4 depot 100 customers 12 93 5 59   # L=56.9695063428
route 5 depot 100 customers 20 3 54 24   # L=90.6935587661
route 6 depot 100 customers 53 23   # L=57.5394572960
route 7 depot 100 customers 41 13 37   # L=70.4238403283
route 8 depot 100 customers 1 40   # L=18.2065556157
route 9 depot 100 customers 95 4 83   # L=63.6491210180
route 10 depot 101 customers 70 64   # L=67.1463117552
route 11 depot 100 customers 72 71 55 38   # L=68.8563700044
route 12 depot 101 customers 0 78 77   # L=55.9675809241
route 13 depot 101 customers 50 8 34   # L=70.4566382625
route 14 depot 101 customers 87 46 35   # L=71.7479137520
route 15 depot 101 customers 68 27   # L=17.9814321652
route 16 depot 100 customers 86 99 43   # L=49.9025874161
route 17 depot 101 customers 75 79   # L=40.8513562602
route 18 depot 100 customers 57 52   # L=17.2645445742
route 19 depot 101 customers 30 18 48   # L=61.2350900838
route 20 depot 101 customers 32 80 33   # L=70.0390406994
route 21 depot 101 customers 31   # L=19.0000000000
route 22 depot 101 customers 61 10 63   # L=69.9289270228
route 23 depot 101 customers 69 29 19 65   # L=63.3846288151
route 24 depot 100 customers 36 90 15 85   # L=91.8196528883
route 25 depot 100 customers 73 74 66   # L=65.2999829432
route 26 depot 101 customers 49 2 28   # L=63.0872061135
route 27 depot 101 customers 81 7   # L=46.8506210697
route 28 depot 100 customers 96 91 97 84   # L=59.1731684455
route 29 depot 100 customers 56 14 42   # L=47.4723409038
route 30 depot 101 customers 26 88   # L=30.2956301410
route 31 depot 100 customers 39 25 11   # L=42.4264068712
route 32 depot 100 customers 94 98 16   # L=58.6054931533
route 33 depot 101 customers 76 67   # L=43.6264158317
route 34 depot 100 customers 58 92 60   # L=55.6806593357
end
