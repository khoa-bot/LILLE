# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..9, depots 10..13
format mdktrp-sol-1
instance 10x4-2
instance_file ../LallaRuizVoss_Instances/10x4-2.txt
paper_id lr02
n 10
m 4
k 5
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 832.6870199449
cost_reported 832.6870199449
cost_recomputed 832.6870199449
seed_cost 970.9315281030
time_seconds 1.562
cycles 3905739
cycle_segments 1945675|1960064
accepted 4743
epochs 22
perturbations 1
crossovers_used 1917
early_stop 1
valid 1
note ok
num_routes 5
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 10 customers 8   # L=36.0555127546
route 1 depot 11 customers 4 9   # L=153.2780272076
route 2 depot 12 customers 0   # L=90.5538513814
route 3 depot 13 customers 6 3 7   # L=283.9156239890
route 4 depot 13 customers 2 5 1   # L=268.8840046122
end
