# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..239, depots 240..243
format mdktrp-sol-1
instance pr05
instance_file ../dat/pr05
paper_id pr05
n 240
m 4
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 7143.0568131775
cost_reported 7143.0568131775
cost_recomputed 7143.0568131775
seed_cost 9712.2490054647
time_seconds 5.833
cycles 133693
cycle_segments 103416|30277
accepted 1914
epochs 75
perturbations 1
crossovers_used 133
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 242 customers 2 110 137 170 235 168   # L=196.5499348187
route 1 depot 242 customers 4 165 36 82 180 194   # L=155.5002827877
route 2 depot 242 customers 9 204 52 119 190 166   # L=261.8556694182
route 3 depot 242 customers 11 205 184 191 221 218 88 37   # L=387.9341439344
route 4 depot 243 customers 17 53 152 55 140 164 114   # L=87.2614391500
route 5 depot 243 customers 25 195 228 126 232 39 215 51   # L=286.3473186552
route 6 depot 241 customers 29 161 105 63 201 197 76 112 86   # L=125.0398149081
route 7 depot 242 customers 31 8 65 72 23 73 5 198 40 92   # L=445.8954461029
route 8 depot 243 customers 35 209 172 64 158   # L=115.9132316378
route 9 depot 243 customers 42 238 33 231 1 146 67 75 97   # L=316.6136233522
route 10 depot 243 customers 66 91 57 219 85 227   # L=263.2798435391
route 11 depot 240 customers 74 193 179 18 199 0 15 116   # L=344.7817587378
route 12 depot 240 customers 80 216 101 132 60   # L=86.9318106947
route 13 depot 241 customers 84 220 239 6   # L=90.7847943210
route 14 depot 240 customers 192 83 159 20 47 183 167   # L=255.3980226671
route 15 depot 242 customers 106 12 155 41 151 125   # L=214.7302497769
route 16 depot 242 customers 111 102 185 30   # L=179.9476967310
route 17 depot 242 customers 117 145 61 135 138 96   # L=131.2441515835
route 18 depot 240 customers 90 32 130 56 113   # L=129.8526928008
route 19 depot 241 customers 131 78 226 104 147 58 230 213 124   # L=170.3826840117
route 20 depot 240 customers 141 19 79 234 186 28 150   # L=106.4660231995
route 21 depot 243 customers 142 71 122 200 203 13 133 129 94   # L=225.9703359086
route 22 depot 243 customers 143 162 118 70 49 87 163 154   # L=205.0197014681
route 23 depot 242 customers 144 107 174 139 24 233   # L=160.7542169680
route 24 depot 240 customers 156 153 50 38 93 222 208   # L=229.5605383959
route 25 depot 240 customers 157 210 14 3 128 89 21   # L=173.9040028199
route 26 depot 240 customers 160 149 148 43   # L=121.5853125812
route 27 depot 242 customers 169 189 171 81 7 44 77   # L=344.6329940501
route 28 depot 241 customers 181 136 173 48 207 127 68   # L=190.7981858443
route 29 depot 240 customers 10 123 188 59 223 95 103   # L=207.6484636332
route 30 depot 240 customers 202 54 176 196 134 27 229 115 225   # L=235.8214210364
route 31 depot 241 customers 211 212 187 182   # L=55.8041674693
route 32 depot 241 customers 224 206 120 99 100 34   # L=75.6738975918
route 33 depot 243 customers 236 98 178 217 121 26 214 46 109   # L=262.6726588734
route 34 depot 243 customers 237 22 16 62 177 175 108 69 45   # L=300.5002837091
end
