# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance p07
instance_file ../dat/p07
paper_id p07
n 100
m 4
k 35
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 1520.4908041073
cost_reported 1520.4908041073
cost_recomputed 1520.4908041073
seed_cost 1831.4744540231
time_seconds 2.357
cycles 205311
cycle_segments 114998|90313
accepted 2256
epochs 32
perturbations 1
crossovers_used 205
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 59 88   # L=13.5275210931
route 1 depot 102 customers 1 56 14 42   # L=51.3331853524
route 2 depot 100 customers 4 92 84 90   # L=48.9437437072
route 3 depot 103 customers 9 89 62   # L=52.1552912412
route 4 depot 101 customers 11 25   # L=17.0710678119
route 5 depot 102 customers 12 93 5   # L=33.3197530058
route 6 depot 100 customers 17 6   # L=24.1421356237
route 7 depot 102 customers 21 40   # L=32.5269119346
route 8 depot 103 customers 30 61 10 63   # L=74.6716926885
route 9 depot 103 customers 31   # L=19.0000000000
route 10 depot 102 customers 39 20   # L=21.2132034356
route 11 depot 100 customers 44 45   # L=29.7439955753
route 12 depot 103 customers 0 8 34   # L=63.2912563525
route 13 depot 103 customers 51   # L=10.6301458127
route 14 depot 101 customers 53 3 38   # L=46.8467360077
route 15 depot 101 customers 54 24 66   # L=65.6104638069
route 16 depot 102 customers 57 52   # L=17.2645445742
route 17 depot 100 customers 95 94   # L=25.5029323126
route 18 depot 100 customers 60 15 43 37   # L=82.0056037560
route 19 depot 101 customers 79 67 2 78 77 33   # L=74.8778203116
route 20 depot 103 customers 68 26 27   # L=32.0850775375
route 21 depot 103 customers 69 29 19 65   # L=63.3846288151
route 22 depot 103 customers 50 70 64   # L=84.2816735805
route 23 depot 102 customers 72 71 55   # L=41.9961568128
route 24 depot 102 customers 73 74 22   # L=54.8115983564
route 25 depot 101 customers 75 49   # L=23.8242537217
route 26 depot 101 customers 76 32 80   # L=45.5670608785
route 27 depot 101 customers 23 28   # L=27.0710678119
route 28 depot 100 customers 81 47 46   # L=53.1734538517
route 29 depot 100 customers 82 7 35   # L=39.9187032624
route 30 depot 100 customers 83 16 85   # L=41.1776823879
route 31 depot 102 customers 86 41 13   # L=45.4820792270
route 32 depot 103 customers 87 18 48   # L=66.9031689681
route 33 depot 102 customers 96 91 36 99   # L=58.1716168392
route 34 depot 100 customers 98 58 97   # L=38.9645776534
end
