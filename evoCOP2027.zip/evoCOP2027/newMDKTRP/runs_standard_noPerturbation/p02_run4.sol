# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..53
format mdktrp-sol-1
instance p02
instance_file ../dat/p02
paper_id p02
n 50
m 4
k 35
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 712.4945265285
cost_reported 712.4945265285
cost_recomputed 712.4945265285
seed_cost 801.2718543366
time_seconds 2.237
cycles 517743
cycle_segments 267474|250269
accepted 4179
epochs 31
perturbations 1
crossovers_used 517
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 52 customers 4   # L=10.0000000000
route 1 depot 50 customers 14   # L=16.4924225025
route 2 depot 53 customers 21   # L=19.3132079158
route 3 depot 51 customers 5 23   # L=36.7318967792
route 4 depot 53 customers 19 2   # L=24.8982571665
route 5 depot 51 customers 0   # L=13.8924439894
route 6 depot 50 customers 16 36   # L=20.3305657253
route 7 depot 53 customers 20   # L=8.2462112512
route 8 depot 50 customers 24   # L=22.2036033112
route 9 depot 51 customers 26 7   # L=30.0356688476
route 10 depot 50 customers 18 39   # L=30.4291356860
route 11 depot 51 customers 45 10   # L=14.6701749822
route 12 depot 51 customers 31   # L=10.0000000000
route 13 depot 50 customers 3 17   # L=19.6157731059
route 14 depot 52 customers 33   # L=11.4017542510
route 15 depot 51 customers 25   # L=28.1602556807
route 16 depot 52 customers 15   # L=11.1803398875
route 17 depot 51 customers 22 42   # L=57.0838359015
route 18 depot 52 customers 38   # L=17.4928556845
route 19 depot 51 customers 47 6   # L=42.9364851007
route 20 depot 51 customers 13   # L=18.1107702763
route 21 depot 53 customers 27 30   # L=54.4078164410
route 22 depot 52 customers 48 32   # L=23.7676245258
route 23 depot 50 customers 43 44   # L=32.6563099160
route 24 depot 52 customers 37   # L=7.0710678119
route 25 depot 50 customers 41   # L=10.0498756211
route 26 depot 53 customers 34 35   # L=32.3886554062
route 27 depot 52 customers 8 49   # L=12.8679568004
route 28 depot 50 customers 12   # L=15.8113883008
route 29 depot 50 customers 40   # L=10.4403065089
route 30 depot 52 customers 29   # L=8.5440037453
route 31 depot 51 customers 46   # L=9.4339811321
route 32 depot 51 customers 11   # L=8.0622577483
route 33 depot 52 customers 9   # L=9.0553851381
route 34 depot 53 customers 28 1   # L=14.7122393876
end
