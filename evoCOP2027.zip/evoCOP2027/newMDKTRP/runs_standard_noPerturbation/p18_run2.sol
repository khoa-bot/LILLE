# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..239, depots 240..245
format mdktrp-sol-1
instance p18
instance_file ../dat/p18
paper_id p18
n 240
m 6
k 35
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 11510.8508227378
cost_reported 11510.8508227378
cost_recomputed 11510.8508227378
seed_cost 14080.9622334736
time_seconds 2.644
cycles 62853
cycle_segments 38744|24109
accepted 857
epochs 34
perturbations 1
crossovers_used 62
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 240 customers 0 8 16 24 32 237 229   # L=387.6955262170
route 1 depot 240 customers 1 9 2 10 18 26   # L=251.4213562373
route 2 depot 240 customers 3 11 19 27 35   # L=150.0000000000
route 3 depot 240 customers 4 12 20 28 36 155 147 139 131   # L=450.0000000000
route 4 depot 240 customers 5 13 21 29 37 72 64   # L=387.6955262170
route 5 depot 240 customers 6 14 7 15 23 31   # L=251.4213562373
route 6 depot 241 customers 41 49 57 65 73 38 30 22   # L=360.0000000000
route 7 depot 241 customers 42 50 58 66 74 39   # L=292.8427124746
route 8 depot 241 customers 40 51 59 67 75 56 48   # L=390.1009242415
route 9 depot 241 customers 44 52 60 68 76 115 107 99   # L=360.0000000000
route 10 depot 241 customers 46 54 62 70 78   # L=150.0000000000
route 11 depot 241 customers 43 45 53 61 69 77   # L=251.4213562373
route 12 depot 241 customers 47 55 63 71 79 117   # L=292.8427124746
route 13 depot 242 customers 80 88 96 104 112 157   # L=292.8427124746
route 14 depot 242 customers 81 89 97 105 113 158 150 142   # L=360.0000000000
route 15 depot 242 customers 82 90 98 106 114 159 151   # L=387.6955262170
route 16 depot 242 customers 83 91 85 93 101 109   # L=251.4213562373
route 17 depot 242 customers 84 92 100 108 116   # L=150.0000000000
route 18 depot 242 customers 86 94 102 110 118   # L=150.0000000000
route 19 depot 242 customers 87 95 103 111 119   # L=212.1320343560
route 20 depot 243 customers 121 122 130 138 146 154 199   # L=337.9898987322
route 21 depot 243 customers 123 120 128 136 144 152 34   # L=337.9898987322
route 22 depot 243 customers 124 132 140 148 156 135 143   # L=336.2531611330
route 23 depot 243 customers 126 127 134 125 133 141 149   # L=342.1320343560
route 24 depot 244 customers 160 168 176 184 192 234 226 218   # L=496.6904755831
route 25 depot 244 customers 161 162 169 177 185 193 170   # L=326.7661908733
route 26 depot 244 customers 163 171 165 167 175 183 191   # L=365.5634918610
route 27 depot 244 customers 164 172 180 188 196 178 186 194   # L=450.5929451351
route 28 depot 244 customers 166 174 182 190 198 153 145 137 129   # L=450.0000000000
route 29 depot 245 customers 201 202 209 217 225 233 210   # L=326.7661908733
route 30 depot 245 customers 203 200 208 216 224 232   # L=251.4213562373
route 31 depot 245 customers 204 212 220 228 236 195 187 179 173   # L=462.3606797750
route 32 depot 245 customers 205 211 219 227 235 221 213   # L=390.1009242415
route 33 depot 245 customers 206 214 222 230 238 33 25 17   # L=360.0000000000
route 34 depot 245 customers 207 215 223 231 239 197 189 181   # L=496.6904755831
end
