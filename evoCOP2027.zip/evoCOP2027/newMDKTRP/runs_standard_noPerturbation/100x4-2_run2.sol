# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..103
format mdktrp-sol-1
instance 100x4-2
instance_file ../LallaRuizVoss_Instances/100x4-2.txt
paper_id lr14
n 100
m 4
k 25
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 7257.3122911925
cost_reported 7257.3122911925
cost_recomputed 7257.3122911925
seed_cost 10483.7418046717
time_seconds 1.620
cycles 147000
cycle_segments 72928|74072
accepted 1425
epochs 22
perturbations 1
crossovers_used 147
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 0 75 1 30 97 38   # L=762.0692238953
route 1 depot 100 customers 55 35 57 12 11 33   # L=265.3663105725
route 2 depot 100 customers 3 98 32 91   # L=374.7634404862
route 3 depot 100 customers 86 7 19   # L=300.4797158204
route 4 depot 100 customers 69 8 9 31 78   # L=563.5533905933
route 5 depot 100 customers 41 20 92 65   # L=383.6928909321
route 6 depot 103 customers 53 51 60   # L=153.1526010525
route 7 depot 100 customers 96 47 4 28 76   # L=404.4996147918
route 8 depot 102 customers 10 66 36   # L=212.4264068712
route 9 depot 100 customers 42 43 13 46   # L=339.0112426645
route 10 depot 103 customers 49 50 99 82   # L=206.1195756397
route 11 depot 101 customers 54 73 70 39   # L=163.7163089161
route 12 depot 103 customers 18 87 14   # L=331.8560236078
route 13 depot 102 customers 71 63 48   # L=141.8033988750
route 14 depot 101 customers 72 84 27 74   # L=242.6155097310
route 15 depot 102 customers 64 22   # L=88.1913190966
route 16 depot 102 customers 34 95 24 29   # L=184.1421356237
route 17 depot 102 customers 52 56 81 40   # L=155.5634918610
route 18 depot 102 customers 58 15 67 25   # L=189.7056274848
route 19 depot 102 customers 23 37 80 44   # L=234.2220510186
route 20 depot 102 customers 59 79 89 85 88   # L=228.3719413699
route 21 depot 100 customers 5 68 90 61 45 62   # L=669.5598986862
route 22 depot 103 customers 2 77   # L=91.5298244508
route 23 depot 103 customers 94 6 16 26   # L=366.1249694973
route 24 depot 103 customers 83 17 21 93   # L=204.7753776542
end
