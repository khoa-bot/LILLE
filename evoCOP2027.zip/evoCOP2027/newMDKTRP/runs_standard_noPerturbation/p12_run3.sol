# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..79, depots 80..81
format mdktrp-sol-1
instance p12
instance_file ../dat/p12
paper_id p12
n 80
m 2
k 35
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 2897.0562748477
cost_reported 2897.0562748477
cost_recomputed 2897.0562748477
seed_cost 3256.2149336856
time_seconds 1.607
cycles 129663
cycle_segments 64666|64997
accepted 61
epochs 22
perturbations 1
crossovers_used 65
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 80 customers 24 32   # L=127.2792206136
route 1 depot 80 customers 3 11 35   # L=80.0000000000
route 2 depot 80 customers 4 12 28 36   # L=120.0000000000
route 3 depot 80 customers 6 22 30 38   # L=130.0000000000
route 4 depot 80 customers 33   # L=50.0000000000
route 5 depot 80 customers 2 10 18 26   # L=141.4213562373
route 6 depot 81 customers 40 48 72   # L=113.1370849898
route 7 depot 80 customers 7 15 23 31 39   # L=212.1320343560
route 8 depot 80 customers 1 9 25   # L=70.0000000000
route 9 depot 81 customers 44 52 60 68   # L=100.0000000000
route 10 depot 81 customers 50 58 66 74   # L=197.9898987322
route 11 depot 80 customers 14   # L=20.0000000000
route 12 depot 80 customers 8   # L=28.2842712475
route 13 depot 81 customers 47 55 63 79   # L=155.5634918610
route 14 depot 81 customers 53 61 77   # L=141.4213562373
route 15 depot 80 customers 5 13 21 29 37   # L=212.1320343560
route 16 depot 80 customers 34   # L=70.7106781187
route 17 depot 81 customers 46 54   # L=30.0000000000
route 18 depot 80 customers 20   # L=30.0000000000
route 19 depot 81 customers 70   # L=40.0000000000
route 20 depot 80 customers 17   # L=30.0000000000
route 21 depot 80 customers 19 27   # L=70.0000000000
route 22 depot 81 customers 41 49 57 65 73   # L=150.0000000000
route 23 depot 81 customers 43 59 75   # L=90.0000000000
route 24 depot 81 customers 76   # L=50.0000000000
route 25 depot 81 customers 62 78   # L=80.0000000000
route 26 depot 81 customers 56   # L=42.4264068712
route 27 depot 81 customers 42   # L=14.1421356237
route 28 depot 81 customers 45   # L=14.1421356237
route 29 depot 81 customers 69   # L=56.5685424949
route 30 depot 80 customers 0   # L=14.1421356237
route 31 depot 81 customers 51 67   # L=60.0000000000
route 32 depot 81 customers 71   # L=56.5685424949
route 33 depot 80 customers 16   # L=42.4264068712
route 34 depot 81 customers 64   # L=56.5685424949
end
