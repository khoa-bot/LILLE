# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..55
format mdktrp-sol-1
instance 50x6-2
instance_file ../LallaRuizVoss_Instances/50x6-2.txt
paper_id lr11
n 50
m 6
k 25
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 2978.7824804194
cost_reported 2978.7824804194
cost_recomputed 2978.7824804194
seed_cost 3854.6306211913
time_seconds 1.877
cycles 438404
cycle_segments 235998|202406
accepted 3305
epochs 26
perturbations 1
crossovers_used 438
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 54 customers 33 38   # L=77.3876888271
route 1 depot 53 customers 20   # L=31.6227766017
route 2 depot 53 customers 32 21   # L=82.3606797750
route 3 depot 52 customers 42   # L=64.0312423743
route 4 depot 52 customers 9 14 48   # L=321.6615541441
route 5 depot 52 customers 13   # L=50.0000000000
route 6 depot 54 customers 39 0   # L=70.0000000000
route 7 depot 50 customers 16 22   # L=73.2455532034
route 8 depot 52 customers 34 36   # L=118.8381226288
route 9 depot 53 customers 29 27   # L=147.7522380484
route 10 depot 52 customers 41 46 3   # L=231.2461179750
route 11 depot 51 customers 40   # L=41.2310562562
route 12 depot 51 customers 43 5   # L=77.3876888271
route 13 depot 51 customers 45 47 15   # L=170.6449510225
route 14 depot 53 customers 2   # L=50.0000000000
route 15 depot 52 customers 17 18   # L=73.0056307975
route 16 depot 54 customers 4 31   # L=76.0555127546
route 17 depot 55 customers 1 8   # L=196.6621938446
route 18 depot 50 customers 49 11 30   # L=256.6875679259
route 19 depot 54 customers 35 25   # L=103.5848547237
route 20 depot 51 customers 12 44   # L=77.3876888271
route 21 depot 52 customers 6 7   # L=179.0663606484
route 22 depot 53 customers 37 28 10   # L=207.6919449578
route 23 depot 54 customers 26 19 23   # L=160.0000000000
route 24 depot 52 customers 24   # L=41.2310562562
end
