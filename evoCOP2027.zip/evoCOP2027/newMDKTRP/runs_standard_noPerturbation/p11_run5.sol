# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..253
format mdktrp-sol-1
instance p11
instance_file ../dat/p11
paper_id p11
n 249
m 5
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 11975.5889256559
cost_reported 11975.5889256559
cost_recomputed 11975.5889256559
seed_cost 17582.4724689232
time_seconds 4.916
cycles 108372
cycle_segments 63452|44920
accepted 1926
epochs 63
perturbations 1
crossovers_used 108
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 253 customers 4 132 11 48 123 227 52   # L=203.8936853743
route 1 depot 250 customers 16 23 39 126 146   # L=207.0480968028
route 2 depot 253 customers 20 99 144 114 243 107 154   # L=457.9514651247
route 3 depot 252 customers 26 1 169 147 25 8 152 88 166 12   # L=511.5465828224
route 4 depot 251 customers 27 94 187 3 80 185   # L=316.8520456089
route 5 depot 251 customers 34 181 33 86 153 75   # L=305.6220936163
route 6 depot 250 customers 54 46 167 102 112 193 41 237   # L=307.7410538161
route 7 depot 250 customers 55 241 224 240 10 234   # L=330.5543752941
route 8 depot 250 customers 77 31 200 66 50 133 158   # L=310.3987215055
route 9 depot 253 customers 32 233 141 67 230 201 138   # L=440.6084236692
route 10 depot 249 customers 84 221 164 5 242 15   # L=254.4026840747
route 11 depot 249 customers 91 177 209 40 108 19 109 59 157   # L=402.4458325239
route 12 depot 249 customers 104 131 96 28 226   # L=211.2077967713
route 13 depot 249 customers 110 235 22 119 21 43 198 36   # L=284.7157582947
route 14 depot 250 customers 135 218 14 101 83 134 145   # L=375.6958796653
route 15 depot 253 customers 18 184 71 137 208 98 69 231   # L=386.9637073795
route 16 depot 251 customers 143 179 62 215 45 199   # L=245.6072019557
route 17 depot 251 customers 151 207 245 24 140 103 73   # L=460.0265817096
route 18 depot 251 customers 155 159 6 163 139 171   # L=327.3602145394
route 19 depot 252 customers 162 223 81 156 248 61 236 176 68   # L=525.2280030052
route 20 depot 252 customers 172 82 205 64 219 35   # L=260.1573362378
route 21 depot 249 customers 173 142 13 97 239 116 106   # L=292.7047507828
route 22 depot 250 customers 174 65 79 196 9 130 213 56 202   # L=486.9615134611
route 23 depot 250 customers 175 232 38 121 42 222 37   # L=373.7952941440
route 24 depot 253 customers 190 29 17 136 53 189   # L=205.6281220843
route 25 depot 251 customers 191 183 217 244 49 90 76 87   # L=310.5275280562
route 26 depot 252 customers 194 124 63 192 100 113 229   # L=360.9519866662
route 27 depot 249 customers 195 47 127 178 160 92 186 44 211   # L=407.8385356202
route 28 depot 252 customers 203 197 72 95 111 7 122 117 2   # L=390.5230882166
route 29 depot 253 customers 78 204 30 70 228 0   # L=354.0804294834
route 30 depot 253 customers 206 165 212 214 125 115   # L=315.9365211650
route 31 depot 253 customers 210 89 60 128 220 129   # L=217.3440420771
route 32 depot 252 customers 216 182 57 149 188 247 120 105   # L=454.3946502933
route 33 depot 250 customers 225 58 74 161 180 170 168 51   # L=387.7111179932
route 34 depot 251 customers 238 118 93 150 85 148 246   # L=291.1638058208
end
