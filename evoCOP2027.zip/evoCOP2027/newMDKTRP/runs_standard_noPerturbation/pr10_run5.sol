# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..287, depots 288..293
format mdktrp-sol-1
instance pr10
instance_file ../dat/pr10
paper_id pr10
n 288
m 6
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 9134.5984582153
cost_reported 9134.5984582153
cost_recomputed 9134.5984582153
seed_cost 13018.1958743299
time_seconds 4.909
cycles 82276
cycle_segments 55895|26381
accepted 1437
epochs 62
perturbations 1
crossovers_used 82
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 292 customers 5 15 221 6 58 173 88 104   # L=274.2930369280
route 1 depot 293 customers 8 47 278 280 237 277 208 115 181   # L=302.2321046154
route 2 depot 289 customers 9 156 16 250 191 21 165 17 36 148   # L=290.7598362322
route 3 depot 291 customers 24 113 212 283 268 167 224 286 175   # L=257.4454565918
route 4 depot 292 customers 26 109 229 77 40 110 131 101   # L=389.3566503293
route 5 depot 290 customers 28 144 211 90 195 14 244 223   # L=259.9895484752
route 6 depot 292 customers 37 43 87 168 120 236 147   # L=223.9964864238
route 7 depot 288 customers 39 50 267 160 287   # L=110.8820758536
route 8 depot 290 customers 42 133 33 41 150 0 20 155   # L=154.1454686637
route 9 depot 288 customers 46 82 51 163 145 25 54 103 233   # L=242.7445843904
route 10 depot 288 customers 61 53 122 137 279 69   # L=147.1369511901
route 11 depot 292 customers 71 154 241 70 67 55 100 149 249 80 254 73   # L=539.7182517473
route 12 depot 293 customers 76 183 64 102 188 18   # L=149.3564041206
route 13 depot 292 customers 78 184 114 108 75 201 252   # L=134.3813272031
route 14 depot 288 customers 79 94 23 29 196 186 66 271 216 255 52   # L=502.5045294743
route 15 depot 293 customers 83 170 143 172 164 187 3   # L=221.3427826280
route 16 depot 291 customers 96 266 65 220 60 270 132 11 72 44   # L=251.0691429485
route 17 depot 290 customers 105 169 177 210 190 240 38 10 219 161   # L=347.8592704972
route 18 depot 293 customers 111 264 74 265 59   # L=91.4831087370
route 19 depot 291 customers 126 158 282 171 136 4 197 193 119 182   # L=398.4827505067
route 20 depot 290 customers 138 198 141 146 129 253 203 238   # L=269.1128924771
route 21 depot 290 customers 140 19 27 48 204 231 130 45 180   # L=218.8520761633
route 22 depot 292 customers 157 151 127 202 242 89 62 98   # L=267.6551304088
route 23 depot 289 customers 159 117 262 121 243 97 275   # L=81.8638189004
route 24 depot 289 customers 178 99 107 125 85 34 248   # L=178.5932740498
route 25 depot 288 customers 205 63 49 81 209 57 106   # L=412.4797697383
route 26 depot 291 customers 217 213 185 226 272 135 2 251 124   # L=340.6138518474
route 27 depot 291 customers 218 263 225 258 118 179 152 123   # L=211.4960969948
route 28 depot 289 customers 232 273 276 128 200 91 31 139   # L=227.6710710255
route 29 depot 288 customers 245 13 174 234 228 134 112 194 32   # L=330.6229185951
route 30 depot 291 customers 256 162 246 7 227 215 30 269 230 166   # L=340.9509509155
route 31 depot 292 customers 257 1 247 207 285 214 199 284 281   # L=238.7413360619
route 32 depot 293 customers 259 92 206 176 192 189 142 260 116 84 222   # L=355.0482758420
route 33 depot 290 customers 261 239 35 153 235 95 56   # L=234.3724436768
route 34 depot 290 customers 274 68 86 93 12 22   # L=137.3447839624
end
