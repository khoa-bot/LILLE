# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..24, depots 25..28
format mdktrp-sol-1
instance 25x4-3
instance_file ../LallaRuizVoss_Instances/25x4-3.txt
paper_id lr06
n 25
m 4
k 10
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 1786.9535090766
cost_reported 1786.9535090766
cost_recomputed 1786.9535090766
seed_cost 2169.4497317546
time_seconds 1.643
cycles 1229157
cycle_segments 587036|642121
accepted 2962
epochs 23
perturbations 1
crossovers_used 637
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 26 customers 5 2 15   # L=335.2356817377
route 1 depot 25 customers 1 23 3   # L=335.6864929803
route 2 depot 25 customers 20 8   # L=134.8683298051
route 3 depot 26 customers 21   # L=84.8528137424
route 4 depot 28 customers 18 13 17   # L=141.6227766017
route 5 depot 26 customers 12 4 11   # L=179.7486815232
route 6 depot 27 customers 10 7   # L=207.7032961427
route 7 depot 26 customers 24 9 22   # L=147.0820393250
route 8 depot 28 customers 16 19 14   # L=109.4427191000
route 9 depot 28 customers 6 0   # L=110.7106781187
end
