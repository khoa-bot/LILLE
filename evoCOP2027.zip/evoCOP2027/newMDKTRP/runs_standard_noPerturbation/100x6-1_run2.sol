# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..105
format mdktrp-sol-1
instance 100x6-1
instance_file ../LallaRuizVoss_Instances/100x6-1.txt
paper_id lr16
n 100
m 6
k 25
fleet standard
run 2
seed 9256
metric raw
depot_mode relocate
strict_cluster 0
cost 5265.3047479264
cost_reported 5265.3047479264
cost_recomputed 5265.3047479264
seed_cost 7552.8818271161
time_seconds 2.357
cycles 222952
cycle_segments 125046|97906
accepted 3140
epochs 32
perturbations 1
crossovers_used 222
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 100 customers 2 88 70 3   # L=160.2260056223
route 1 depot 104 customers 4 74 47 80   # L=315.5634918610
route 2 depot 105 customers 6 9 66 86 5   # L=290.9298024335
route 3 depot 104 customers 8 98 76 93 17   # L=277.8064386525
route 4 depot 103 customers 10 32 65 99 91   # L=285.5634918610
route 5 depot 104 customers 92 96 67 51   # L=296.2141270696
route 6 depot 100 customers 14 27 20 40   # L=233.5731457317
route 7 depot 103 customers 95 46   # L=94.1421356237
route 8 depot 102 customers 24 39 53 97   # L=243.2170003847
route 9 depot 101 customers 25 68   # L=64.3397840021
route 10 depot 103 customers 26 22 55 71 82   # L=230.0000000000
route 11 depot 105 customers 28 0 41   # L=141.6227766017
route 12 depot 101 customers 37 73 64   # L=210.8409351897
route 13 depot 105 customers 38 50 19 36   # L=308.9949493661
route 14 depot 100 customers 34 56   # L=99.3010659580
route 15 depot 102 customers 48 33 78 72 35   # L=265.5634918610
route 16 depot 104 customers 54 7 44 23   # L=145.4320376687
route 17 depot 105 customers 57 45 13 85   # L=206.4911064067
route 18 depot 102 customers 59 52 63   # L=84.7213595500
route 19 depot 103 customers 61 87 29 89   # L=220.0000000000
route 20 depot 102 customers 62 21 43 69 1   # L=191.4213562373
route 21 depot 101 customers 79 90 60 16 75   # L=227.9898987322
route 22 depot 102 customers 83 58 11 15 49 12   # L=284.1640786500
route 23 depot 102 customers 84 81 77 30 42   # L=214.1421356237
route 24 depot 103 customers 18 31 94   # L=173.0441328390
end
