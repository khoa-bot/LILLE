# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..49, depots 50..55
format mdktrp-sol-1
instance 50x6-1
instance_file ../LallaRuizVoss_Instances/50x6-1.txt
paper_id lr10
n 50
m 6
k 25
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 2866.7279512701
cost_reported 2866.7279512701
cost_recomputed 2866.7279512701
seed_cost 3551.3951622589
time_seconds 1.660
cycles 386807
cycle_segments 184606|202201
accepted 2878
epochs 23
perturbations 1
crossovers_used 386
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 51 customers 45   # L=50.9901951359
route 1 depot 55 customers 9 42 24 12   # L=140.0000000000
route 2 depot 50 customers 20 10 22   # L=111.2310562562
route 3 depot 50 customers 7 29   # L=140.0000000000
route 4 depot 50 customers 28 16   # L=127.2767955777
route 5 depot 52 customers 15 30   # L=257.2654338214
route 6 depot 52 customers 40 32 4   # L=282.2216873711
route 7 depot 52 customers 49 23   # L=78.3095189485
route 8 depot 53 customers 38   # L=30.0000000000
route 9 depot 51 customers 25   # L=28.2842712475
route 10 depot 55 customers 43 27   # L=50.6449510225
route 11 depot 55 customers 41 2   # L=114.7213595500
route 12 depot 52 customers 46 1 36 26   # L=257.3591360084
route 13 depot 54 customers 47   # L=10.0000000000
route 14 depot 50 customers 5 13   # L=88.2842712475
route 15 depot 52 customers 18 8   # L=141.2310562562
route 16 depot 53 customers 48 3 11   # L=178.4145283185
route 17 depot 52 customers 37   # L=50.9901951359
route 18 depot 52 customers 17 19   # L=87.1477664212
route 19 depot 50 customers 33   # L=50.0000000000
route 20 depot 51 customers 6 35   # L=111.9803902719
route 21 depot 55 customers 44 34   # L=122.1110255093
route 22 depot 54 customers 21 0   # L=58.8634951737
route 23 depot 55 customers 31 39   # L=213.9607805437
route 24 depot 50 customers 14   # L=85.4400374532
end
