# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..47, depots 48..51
format mdktrp-sol-1
instance pr01
instance_file ../dat/pr01
paper_id pr01
n 48
m 4
k 35
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 1261.5253471281
cost_reported 1261.5253471281
cost_recomputed 1261.5253471281
seed_cost 1397.7448040659
time_seconds 1.659
cycles 410512
cycle_segments 195193|215319
accepted 3457
epochs 23
perturbations 1
crossovers_used 410
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 48 customers 34 8   # L=24.1428025580
route 1 depot 50 customers 27 13   # L=32.7989278324
route 2 depot 50 customers 17   # L=34.6069823157
route 3 depot 51 customers 46   # L=22.8616475347
route 4 depot 48 customers 41   # L=39.2573542155
route 5 depot 50 customers 35   # L=21.8464738574
route 6 depot 50 customers 3 18   # L=103.1330672181
route 7 depot 48 customers 31 43   # L=32.0717097130
route 8 depot 51 customers 37   # L=30.4069665866
route 9 depot 50 customers 15 4   # L=42.4397230165
route 10 depot 51 customers 42   # L=26.9253096732
route 11 depot 48 customers 30   # L=21.7785180396
route 12 depot 48 customers 40   # L=22.0701918660
route 13 depot 50 customers 25   # L=20.5363884361
route 14 depot 49 customers 21   # L=12.2121613157
route 15 depot 51 customers 11   # L=28.9702696743
route 16 depot 51 customers 1   # L=5.2555069213
route 17 depot 50 customers 28 12   # L=96.3360887439
route 18 depot 51 customers 24   # L=27.4687568885
route 19 depot 51 customers 22   # L=23.4241918751
route 20 depot 51 customers 23 20   # L=59.7055748701
route 21 depot 51 customers 29 39   # L=52.4901435746
route 22 depot 48 customers 36 6   # L=9.9107248300
route 23 depot 49 customers 33   # L=9.3386931099
route 24 depot 50 customers 16   # L=59.8253099114
route 25 depot 49 customers 9 10   # L=17.3019771212
route 26 depot 49 customers 44 47   # L=39.7159040239
route 27 depot 49 customers 5 2   # L=62.0003437038
route 28 depot 50 customers 19 32   # L=84.6951825184
route 29 depot 49 customers 26   # L=36.6379909111
route 30 depot 51 customers 38   # L=13.0769195532
route 31 depot 50 customers 7   # L=40.3233955043
route 32 depot 50 customers 0   # L=16.3394634245
route 33 depot 51 customers 14   # L=21.7788077727
route 34 depot 48 customers 45   # L=69.8418780174
end
