# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..24, depots 25..28
format mdktrp-sol-1
instance 25x4-1
instance_file ../LallaRuizVoss_Instances/25x4-1.txt
paper_id lr04
n 25
m 4
k 10
fleet standard
run 5
seed 33013
metric raw
depot_mode relocate
strict_cluster 0
cost 2082.2765799286
cost_reported 2082.2765799286
cost_recomputed 2082.2765799286
seed_cost 2684.2525246435
time_seconds 1.572
cycles 1154901
cycle_segments 577548|577353
accepted 4848
epochs 22
perturbations 1
crossovers_used 1154
early_stop 1
valid 1
note ok
num_routes 10
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 25 customers 0 23   # L=92.8010988928
route 1 depot 25 customers 8 14   # L=277.9594353438
route 2 depot 25 customers 6 10 7   # L=414.6488184674
route 3 depot 25 customers 2 12 15 13   # L=344.1944025494
route 4 depot 27 customers 18 4   # L=167.0221526668
route 5 depot 25 customers 11 24   # L=100.6225774830
route 6 depot 27 customers 16 9   # L=42.4264068712
route 7 depot 26 customers 22 3 21   # L=228.8854382000
route 8 depot 28 customers 19 17 20   # L=231.1132816993
route 9 depot 28 customers 5 1   # L=182.6029677548
end
