# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..253
format mdktrp-sol-1
instance p11
instance_file ../dat/p11
paper_id p11
n 249
m 5
k 35
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 12110.1427181601
cost_reported 12110.1427181601
cost_recomputed 12110.1427181601
seed_cost 17582.4724689232
time_seconds 2.419
cycles 53103
cycle_segments 25632|27471
accepted 805
epochs 31
perturbations 1
crossovers_used 53
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 253 customers 4 132 11 48 129 128 220   # L=195.5809996402
route 1 depot 250 customers 16 23 39 126 146   # L=207.0480968028
route 2 depot 253 customers 20 99 144 114 243 107 154   # L=457.9514651247
route 3 depot 252 customers 26 216 182 149 57 229 113 100 192   # L=447.1146220446
route 4 depot 251 customers 27 94 187 3 80 185   # L=316.8520456089
route 5 depot 251 customers 34 181 33 86 153 75   # L=305.6220936163
route 6 depot 249 customers 36 115 125 103 73   # L=323.5867326024
route 7 depot 250 customers 37 121 222 42 156 81   # L=357.3064715789
route 8 depot 252 customers 53 206 165 212 214   # L=198.9538970191
route 9 depot 250 customers 54 46 167 102 112 193 41 237   # L=307.7410538161
route 10 depot 250 customers 55 241 224 240 10 234   # L=330.5543752941
route 11 depot 250 customers 77 31 200 66 50 133 158   # L=310.3987215055
route 12 depot 253 customers 78 32 233 141 67 230 201 138   # L=450.1117043407
route 13 depot 249 customers 84 168 180 170 161 74 58   # L=336.4987892358
route 14 depot 249 customers 91 177 209 40 108 19 109 59 157   # L=402.4458325239
route 15 depot 249 customers 104 131 96 28 226   # L=211.2077967713
route 16 depot 249 customers 110 43 198 24 140   # L=222.4080213657
route 17 depot 252 customers 124 63 223 162 68 176 236 61 248   # L=531.5689062720
route 18 depot 253 customers 18 184 71 137 208 98 69 231   # L=386.9637073795
route 19 depot 251 customers 143 45 215 62 179 151   # L=246.1768854965
route 20 depot 251 customers 155 159 6 163 139 171   # L=327.3602145394
route 21 depot 252 customers 172 82 205 35 219 188 120 105   # L=456.5557638328
route 22 depot 249 customers 173 142 13 97 239 116 106   # L=292.7047507828
route 23 depot 250 customers 174 65 79 196 9 130 213 56 202   # L=486.9615134611
route 24 depot 250 customers 175 232 38 145 134 83   # L=307.2005849915
route 25 depot 253 customers 190 29 17 136 123 227 52 64   # L=350.3865224655
route 26 depot 251 customers 191 183 217 244 49 90 76 87   # L=310.5275280562
route 27 depot 252 customers 194 1 169 147 25 8 152 247 88 166 12   # L=631.2196030814
route 28 depot 249 customers 195 47 127 178 160 92 186 44 211   # L=407.8385356202
route 29 depot 252 customers 203 197 72 95 111 7 122 117 2 189   # L=478.1303041529
route 30 depot 253 customers 210 89 60 204 30 70 228 0   # L=471.0332685782
route 31 depot 249 customers 221 164 5 242 15   # L=211.9638634293
route 32 depot 250 customers 225 135 218 14 101 51   # L=256.2551120640
route 33 depot 249 customers 235 22 119 21 199 207 245   # L=284.7491292449
route 34 depot 251 customers 238 118 93 150 85 148 246   # L=291.1638058208
end
