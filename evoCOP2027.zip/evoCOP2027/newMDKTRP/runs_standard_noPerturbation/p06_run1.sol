# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..102
format mdktrp-sol-1
instance p06
instance_file ../dat/p06
paper_id p06
n 100
m 3
k 35
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 1551.6840383102
cost_reported 1551.6840383102
cost_recomputed 1551.6840383102
seed_cost 2086.9281196273
time_seconds 3.167
cycles 278113
cycle_segments 168441|109672
accepted 2825
epochs 43
perturbations 1
crossovers_used 278
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 102 customers 0 49 76 2   # L=70.1654236846
route 1 depot 101 customers 3 54 24   # L=35.6935587661
route 2 depot 100 customers 4 59 82 7   # L=69.1127917902
route 3 depot 102 customers 9 10 48   # L=57.8917042739
route 4 depot 101 customers 11 75   # L=37.0710678119
route 5 depot 100 customers 15 85   # L=16.3245553203
route 6 depot 101 customers 20 39 57 52   # L=54.5584342004
route 7 depot 101 customers 25 27   # L=30.4229375233
route 8 depot 102 customers 29 19 65   # L=44.2996109693
route 9 depot 102 customers 30 51 17   # L=42.3134887095
route 10 depot 102 customers 31   # L=14.0000000000
route 11 depot 102 customers 32 78   # L=42.1534294313
route 12 depot 100 customers 36 96 86   # L=29.4406797143
route 13 depot 101 customers 38 66   # L=35.5119918863
route 14 depot 100 customers 43 37   # L=25.2388589282
route 15 depot 102 customers 50 8 34   # L=65.0365549626
route 16 depot 101 customers 53 23 28   # L=61.2763305648
route 17 depot 101 customers 55 22   # L=24.3681173799
route 18 depot 100 customers 58 93   # L=20.2531569967
route 19 depot 100 customers 60 16   # L=19.2195444573
route 20 depot 102 customers 61 18 46 35   # L=96.6012684234
route 21 depot 102 customers 68 26   # L=23.7725323918
route 22 depot 102 customers 69 70 64   # L=63.6514492322
route 23 depot 101 customers 71 73 21 40   # L=40.0540289880
route 24 depot 101 customers 72 1 56   # L=43.9555636923
route 25 depot 101 customers 74   # L=9.0553851381
route 26 depot 101 customers 79 67   # L=38.0555127546
route 27 depot 102 customers 80 77 33   # L=77.7240638242
route 28 depot 100 customers 83 44 45   # L=63.0890798805
route 29 depot 100 customers 84 92 98 95 5 88   # L=59.1647568080
route 30 depot 102 customers 87 6 81 47   # L=73.9680664799
route 31 depot 102 customers 89 62 63   # L=61.3138089339
route 32 depot 100 customers 90 13 42   # L=31.6301458127
route 33 depot 100 customers 97 91 94 12   # L=38.2893775475
route 34 depot 100 customers 99 41 14   # L=37.0067610322
end
