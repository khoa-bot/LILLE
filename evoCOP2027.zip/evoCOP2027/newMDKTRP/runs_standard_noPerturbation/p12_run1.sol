# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..79, depots 80..81
format mdktrp-sol-1
instance p12
instance_file ../dat/p12
paper_id p12
n 80
m 2
k 35
fleet standard
run 1
seed 1337
metric raw
depot_mode relocate
strict_cluster 0
cost 2897.0562748477
cost_reported 2897.0562748477
cost_recomputed 2897.0562748477
seed_cost 3256.2149336856
time_seconds 1.607
cycles 125579
cycle_segments 62574|63005
accepted 61
epochs 22
perturbations 1
crossovers_used 70
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 80 customers 16 24   # L=98.9949493661
route 1 depot 80 customers 5 21   # L=56.5685424949
route 2 depot 80 customers 4 12 20 28 36   # L=150.0000000000
route 3 depot 80 customers 6 22 30 38   # L=130.0000000000
route 4 depot 80 customers 0   # L=14.1421356237
route 5 depot 80 customers 15 23 31   # L=127.2792206136
route 6 depot 81 customers 53 69 77   # L=155.5634918610
route 7 depot 80 customers 7   # L=14.1421356237
route 8 depot 80 customers 2 18 26   # L=113.1370849898
route 9 depot 80 customers 3 11 27 35   # L=120.0000000000
route 10 depot 81 customers 43 51   # L=30.0000000000
route 11 depot 80 customers 14   # L=20.0000000000
route 12 depot 80 customers 8 32   # L=98.9949493661
route 13 depot 80 customers 10   # L=28.2842712475
route 14 depot 80 customers 13 29 37   # L=155.5634918610
route 15 depot 81 customers 46 54 62 70   # L=100.0000000000
route 16 depot 80 customers 34   # L=70.7106781187
route 17 depot 80 customers 39   # L=70.7106781187
route 18 depot 81 customers 44 60 76   # L=90.0000000000
route 19 depot 81 customers 61   # L=42.4264068712
route 20 depot 80 customers 9 17 25 33   # L=140.0000000000
route 21 depot 81 customers 40 56 64   # L=113.1370849898
route 22 depot 81 customers 41 49 57 65 73   # L=150.0000000000
route 23 depot 81 customers 59 75   # L=80.0000000000
route 24 depot 81 customers 63 71 79   # L=169.7056274848
route 25 depot 81 customers 78   # L=50.0000000000
route 26 depot 81 customers 72   # L=70.7106781187
route 27 depot 81 customers 42 50 58 66 74   # L=212.1320343560
route 28 depot 81 customers 45   # L=14.1421356237
route 29 depot 81 customers 47 55   # L=42.4264068712
route 30 depot 80 customers 19   # L=30.0000000000
route 31 depot 81 customers 67   # L=40.0000000000
route 32 depot 81 customers 52 68   # L=60.0000000000
route 33 depot 80 customers 1   # L=10.0000000000
route 34 depot 81 customers 48   # L=28.2842712475
end
