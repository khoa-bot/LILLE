# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..99, depots 100..105
format mdktrp-sol-1
instance 100x6-3
instance_file ../LallaRuizVoss_Instances/100x6-3.txt
paper_id lr18
n 100
m 6
k 25
fleet standard
run 4
seed 25094
metric raw
depot_mode relocate
strict_cluster 0
cost 5788.7314035389
cost_reported 5788.7314035389
cost_recomputed 5788.7314035389
seed_cost 7902.2854268776
time_seconds 1.988
cycles 180407
cycle_segments 107103|73304
accepted 1679
epochs 27
perturbations 1
crossovers_used 180
early_stop 1
valid 1
note ok
num_routes 25
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 102 customers 82 87 75 24   # L=232.4483498974
route 1 depot 101 customers 3 57 73   # L=276.7574644234
route 2 depot 101 customers 19 42 83 81   # L=141.2899020449
route 3 depot 102 customers 25 22 58 47 56 99 77   # L=440.0000000000
route 4 depot 103 customers 27 97 13 15 41 29   # L=297.2134935174
route 5 depot 104 customers 28 68   # L=77.3876888271
route 6 depot 100 customers 30 18 65 8   # L=180.0000000000
route 7 depot 104 customers 32 89 80 62 26 51 96   # L=371.3556291411
route 8 depot 101 customers 34 31 4 10 64   # L=219.4427191000
route 9 depot 102 customers 38 76 43   # L=137.2947366762
route 10 depot 100 customers 66 45 39 14   # L=417.1477664212
route 11 depot 102 customers 49 59 20 33 98   # L=170.7106781187
route 12 depot 103 customers 0 12   # L=175.3951349062
route 13 depot 102 customers 53 72 67 86   # L=457.3386227288
route 14 depot 100 customers 54 23 16 6   # L=226.5247584250
route 15 depot 100 customers 55 60 50   # L=148.2842712475
route 16 depot 101 customers 52 61 7 5   # L=308.8634951737
route 17 depot 102 customers 63 79 91   # L=256.4335111251
route 18 depot 104 customers 46 85 2   # L=167.8739606025
route 19 depot 100 customers 93 35 21 94   # L=264.2220510186
route 20 depot 103 customers 88 70 17   # L=103.0056307975
route 21 depot 101 customers 84 74 11   # L=121.2310562562
route 22 depot 100 customers 78 36 90 48   # L=149.2744663834
route 23 depot 103 customers 92 71 69   # L=97.0820393250
route 24 depot 101 customers 95 44 9 40 1 37   # L=352.1539773822
end
