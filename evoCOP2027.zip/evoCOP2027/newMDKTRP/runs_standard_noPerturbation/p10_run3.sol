# MDk-TRP solution file -- written by ROARMDkTRP (GA/perturbation build)
# objective: depot-exclusive cumulative latency, open routes
#   Z = sum over routes of sum_{t=1..p} A(R[t]),  A(R[t]) = sum_{s<=t} c(R[s-1],R[s])
# node ids: customers 0..248, depots 249..252
format mdktrp-sol-1
instance p10
instance_file ../dat/p10
paper_id p10
n 249
m 4
k 35
fleet standard
run 3
seed 17175
metric raw
depot_mode relocate
strict_cluster 0
cost 12146.5434144504
cost_reported 12146.5434144504
cost_recomputed 12146.5434144504
seed_cost 18327.0084923222
time_seconds 2.497
cycles 55909
cycle_segments 34855|21054
accepted 916
epochs 32
perturbations 1
crossovers_used 55
early_stop 1
valid 1
note ok
num_routes 35
# route <r> depot <depotNodeId> customers <visiting order>
route 0 depot 252 customers 3 80 185 20 137 32 233   # L=308.6386980300
route 1 depot 250 customers 9 237 12 166 88 120 105   # L=430.9408048079
route 2 depot 250 customers 240 234 63 124 1 169   # L=290.8512695523
route 3 depot 251 customers 11 60 89 210 204 30 70 228 0   # L=543.9176250601
route 4 depot 251 customers 17 29 206 165 212 214   # L=217.3225811325
route 5 depot 252 customers 27 155 143 191 183 217 244 93 150 85   # L=635.6295036304
route 6 depot 250 customers 55 175 135 225 31 77 200 146   # L=411.1325055166
route 7 depot 250 customers 65 167 46 54 16 23 39 126   # L=387.0052115304
route 8 depot 249 customers 84 221 164 36 5 168   # L=297.8097568964
route 9 depot 249 customers 91 177 209 40 109 59 157 133 158   # L=418.6870649106
route 10 depot 252 customers 94 33 181 34 238 118 148   # L=312.7702264961
route 11 depot 249 customers 104 170 180 161 74 58 232   # L=381.0860302570
route 12 depot 249 customers 108 19 226 28 96 131 66 50   # L=456.0387479856
route 13 depot 249 customers 110 43 198 207 151   # L=243.7021594583
route 14 depot 252 customers 114 144 99 208 141 67   # L=287.0554825410
route 15 depot 249 customers 116 239 97 106 211   # L=206.9177651362
route 16 depot 250 customers 121 145 83 134 117 122 2   # L=374.0127202312
route 17 depot 251 customers 123 48 129 128 220   # L=148.6526444447
route 18 depot 250 customers 130 213 56 202 8 152 247   # L=333.2492896548
route 19 depot 251 customers 136 53 203 197 72 95 111 7   # L=311.4519841878
route 20 depot 252 customers 159 6 245 24 140   # L=246.7558638756
route 21 depot 252 customers 163 139 73 103 125 115   # L=328.9700975209
route 22 depot 251 customers 172 26 216 182 57 149 35 219   # L=450.5030510575
route 23 depot 249 customers 173 142 13 44 76 87 246   # L=365.5354888352
route 24 depot 252 customers 187 86 153 75 154 201   # L=247.5573069640
route 25 depot 251 customers 190 4 132 78 18 184 71 171   # L=360.7638908142
route 26 depot 249 customers 195 47 127 178 160 186 92 90 49   # L=419.2024134739
route 27 depot 250 customers 196 41 193 79 112 102 174   # L=259.9977127529
route 28 depot 250 customers 10 192 100 113 147 25 229 188   # L=459.2269616201
route 29 depot 250 customers 222 42 248 61 236 176 68 189   # L=321.4949663874
route 30 depot 250 customers 224 156 81 223 162 194   # L=254.6227488690
route 31 depot 251 customers 227 52 64 205 82   # L=230.5489059009
route 32 depot 249 customers 235 22 119 21 199 62 179 215 45   # L=400.8482079055
route 33 depot 250 customers 241 37 38 101 14 218 51 242 15   # L=390.9353023943
route 34 depot 252 customers 243 107 69 98 231 230 138   # L=412.7084246192
end
